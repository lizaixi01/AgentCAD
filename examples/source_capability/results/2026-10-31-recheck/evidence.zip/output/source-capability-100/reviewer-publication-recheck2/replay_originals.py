from pathlib import Path
import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET

import ezdxf
import pypdf
import agentcad
from agentcad.dimension_display import read_display
from agentcad.policy import Policy
from agentcad.service import Runtime
from agentcad.viewer import Workspace

REPO=Path(r'D:\Projects\AgentCAD-wt\review-pr44-publication-recheck2')
OUT=Path(r'D:\Projects\AgentCAD-output\source-capability-100\reviewer-publication-recheck2')
EVIDENCE=Path(r'D:\Projects\AgentCAD-output\source-capability-100')
HEAD='290ced3033f85e1fc97611cf1c920d922524bc3a'
assert Path(agentcad.__file__).resolve().is_relative_to(REPO)
assert subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'],text=True).strip()==HEAD

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
sources={
    'transparent':EVIDENCE/'reviewer-publication-final/code-behavior/transparency-probe/mechanical.dxf',
    'scientific':EVIDENCE/'reviewer-publication-final/code-behavior/scientific-probe/scientific.dxf',
    'inheritance':EVIDENCE/'reviewer-publication-recheck/code-behavior/inheritance-probe/inheritance.dxf',
    'zero':EVIDENCE/'scientific-zero-probe/zero.dxf',
}
originals=[p for folder in {p.parent for p in sources.values()} for p in folder.rglob('*') if p.is_file()]
before={p.as_posix():sha(p) for p in originals}
results=[]
errors=[]

cases=[
    ('transparent_original','transparent',None,False),
    ('transparent_opaque_control','transparent',0.0,True),
    ('transparent_partial_control','transparent',0.5,True),
    ('scientific_original','scientific',None,False),
    ('scientific_correct_control','scientific','%%c6.50E-03',True),
    ('scientific_zero_text','scientific','%%c0.00E+00',False),
    ('scientific_false_exponent','scientific','%%c1.00E+03',False),
    ('scientific_physical_zero_original','zero',None,False),
    ('scientific_physical_zero_control','zero','0.00E+00',True),
    ('inheritance_original','inheritance',None,True),
]
for name,kind,change,expected in cases:
    root=OUT/'cases'/name
    root.mkdir(parents=True,exist_ok=True)
    source_path=sources[kind]
    dest=root/source_path.name
    dest.write_bytes(source_path.read_bytes())
    doc=ezdxf.readfile(dest)
    mechanical=kind in {'transparent','inheritance'}
    handle='E3' if mechanical else '8B'
    dim=doc.entitydb[handle]
    text=doc.blocks[dim.dxf.geometry].query('MTEXT').first
    if change is not None:
        if kind=='transparent':text.transparency=change
        else:text.text=change
        doc.saveas(dest)
    input_hash=sha(dest)
    runtime=Runtime(Policy(root=root))
    checked=runtime.validate_drawing(dest.name,detail=True)
    delivery=runtime.deliver_drawing(dest.name,'delivered',formats=['dxf','svg'])
    actual={'validation_passed':checked['validation']['passed'],'delivery_ok':delivery['ok']}
    engineering=verified=None
    if kind!='zero':
        verified=runtime.verify_dimensions(dest.name,[{'id':'nominal','handle':handle,'value':17 if mechanical else .0065}])
        actual['dimensions_accepted']=verified['accepted']
    if mechanical:
        engineering=runtime.read_engineering(dest.name,'mechanical')
        actual['manufacturing_passed']=all(r['passed'] for r in engineering['manufacturing'])
        actual['critique_clear']=not engineering['critique']
    if any(value is not expected for value in actual.values()):errors.append(name+': unexpected acceptance '+str(actual))
    if sha(dest)!=input_hash:errors.append(name+': checked input was changed')
    if change is None and input_hash!=before[source_path.as_posix()]:errors.append(name+': original bytes not retained')
    if not expected and delivery.get('error',{}).get('code')!='DELIVERY_REJECTED':errors.append(name+': wrong delivery error')
    display=read_display(ezdxf.readfile(dest).entitydb[handle])
    if kind in {'scientific','zero'} and display['resolution']!=(1e-5 if kind=='scientific' else 0):errors.append(name+': scientific resolution '+str(display['resolution']))
    result={'case':name,'expected_acceptance':expected,'actual':actual,'source':str(source_path),'original_sha256':before[source_path.as_posix()],'case_sha256':input_hash,'unchanged_after_readback':sha(dest)==input_hash,'display':display,'validation':checked,'verification':verified,'delivery':delivery,'engineering':engineering}
    (root/'result.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf-8')
    results.append({k:v for k,v in result.items() if k not in ['validation','verification','delivery','engineering']})

# Independently exercise the real three export paths using the saved inheritance
# counterexample. A color-only marker copy identifies its numeral's output path.
root=OUT/'actual-output-inheritance'
root.mkdir(parents=True,exist_ok=True)
runtime=Runtime(Policy(root=root))
doc=ezdxf.readfile(sources['inheritance'])
text=doc.blocks[doc.entitydb['E3'].dxf.geometry].query('MTEXT').first
text.rgb=(255,0,255)
doc.saveas(root/'marked.dxf')
outputs=[]
for fmt in ['svg','pdf']:
    result=runtime.export_drawing('marked.dxf','marked.'+fmt,fmt)
    if not result['ok']:errors.append('actual '+fmt+' failed: '+str(result))
viewer=Workspace(runtime.policy,root/'viewer-cache').svg('marked.dxf',None)
(root/'viewer.svg').write_text(viewer,encoding='utf-8')
for fmt in ['marked.svg','viewer.svg']:
    tree=ET.fromstring((root/fmt).read_text(encoding='utf-8'))
    ns='{http://www.w3.org/2000/svg}'
    classes={}
    for style in tree.iter(ns+'style'):
        match=re.search(r'\.(\w+)\s*\{(.*?)\}',style.text or '')
        if match and 'fill: #ff00ff;' in match[2]:
            classes[match[1]]=float(re.search(r'fill-opacity:\s*([\d.]+)',match[2])[1])
    alpha=[classes[e.get('class')] for e in tree.iter(ns+'path') if e.get('class') in classes]
    if not alpha or any(a!=1 for a in alpha):errors.append('actual '+fmt+' numeral not visible: '+str(alpha))
    outputs.append({'output':fmt,'marked_numeral_alpha':alpha})
pdf=pypdf.PdfReader(root/'marked.pdf')
contents=pdf.pages[0].get_contents().get_data().decode('latin-1')
if '1 0 1 rg' not in contents:errors.append('actual PDF numeral missing')
outputs.append({'output':'marked.pdf','marked_numeral_fill_present':'1 0 1 rg' in contents,'pages':len(pdf.pages)})
after={p.as_posix():sha(p) for p in originals}
if before!=after:errors.append('previous evidence changed')
report={'head':HEAD,'imported_from':agentcad.__file__,'ezdxf':ezdxf.__version__,'cases':results,'actual_output_inheritance':outputs,'previous_evidence_files':len(before),'previous_evidence_unchanged':before==after,'previous_evidence_hashes':before,'errors':errors}
(OUT/'original-replay-results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps({'head':HEAD,'cases':[{'case':r['case'],'actual':r['actual'],'display_status':r['display']['status'],'resolution':r['display']['resolution']} for r in results],'actual_output_inheritance':outputs,'previous_evidence_unchanged':before==after,'errors':errors},indent=2))
raise SystemExit(bool(errors))
