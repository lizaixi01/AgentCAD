from pathlib import Path
import hashlib,json,shutil
import ezdxf
from agentcad.policy import Policy
from agentcad.service import Runtime
base=Path(r'D:/Projects/AgentCAD-output/source-capability-100/reviewer-publication-final/code-behavior')
root=Path(r'D:/Projects/AgentCAD-output/source-capability-100/reviewer-publication-recheck/code-behavior/original-replay')
root.mkdir(parents=True,exist_ok=True)
sources={'transparent':base/'transparency-probe/mechanical.dxf','scientific':base/'scientific-probe/scientific.dxf'}
before={k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in sources.items()}
rt=Runtime(Policy(root=root));results={}
for name,path in sources.items():
    shutil.copyfile(path,root/(name+'.dxf'))
    bad=rt.deliver_drawing(name+'.dxf',name+'-bad',formats=['dxf','svg'])
    validation=rt.validate_drawing(name+'.dxf',detail=True)
    doc=ezdxf.readfile(root/(name+'.dxf'))
    if name=='transparent':
        report=rt.read_engineering(name+'.dxf','mechanical')
        handle=next(a['handle'] for a in report['manufacturing'][0]['annotations'] if a['kind']=='length.0')
        dim=doc.entitydb[handle]
        doc.blocks[dim.dxf.geometry].query('MTEXT').first.transparency=0
    else:
        dim=doc.modelspace().query('DIMENSION').first
        doc.blocks[dim.dxf.geometry].query('MTEXT').first.text='%%c6.50E-03'
    doc.saveas(root/(name+'-good.dxf'))
    good=rt.deliver_drawing(name+'-good.dxf',name+'-good',formats=['dxf','svg'])
    results[name]={'bad':bad,'bad_validation':validation,'good':good}
after={k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in sources.items()}
result={'source_hashes_before':before,'source_hashes_after':after,'sources_unchanged':before==after,'cases':results}
(root/'result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps({'sources_unchanged':before==after,'cases':{k:{'bad_error':v['bad'].get('error',{}).get('code'),'good_ok':v['good']['ok'],'good_error':v['good'].get('error',{}).get('code')} for k,v in results.items()}}))
