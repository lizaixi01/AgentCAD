from pathlib import Path
import json
import ezdxf
from ezdxf.addons.drawing import RenderContext
from agentcad.policy import Policy
from agentcad.service import Runtime
from agentcad.dimension_display import read_display
root=Path(r'D:/Projects/AgentCAD-output/source-capability-100/reviewer-publication-recheck/code-behavior/inheritance-probe')
root.mkdir(parents=True,exist_ok=True)
rt=Runtime(Policy(root=root))
assert rt.create_drawing('inheritance.dxf',units='mm')['ok']
spec={'parts':[{'name':'shaft','at':[135,195], 'segments':[{'length':17,'d_outer':40}]}]}
created=rt.apply_operations('inheritance.dxf',[{'op':'draw_mechanical_assembly','spec':spec}]);assert created['ok'],created
initial=rt.read_engineering('inheritance.dxf','mechanical');assert not initial['critique'],initial
handle=next(a['handle'] for a in initial['manufacturing'][0]['annotations'] if a['kind']=='length.0')
doc=ezdxf.readfile(root/'inheritance.dxf');dim=doc.entitydb[handle]
text=doc.blocks[dim.dxf.geometry].query('MTEXT').first
text.dxf.layer='0';text.dxf.discard('transparency')
doc.layers.get('0').transparency=1.0
context=RenderContext(doc)
actual_color=context.resolve_all(text).color
context.push_state(context.resolve_all(dim))
simulated_color=context.resolve_all(text).color
context.pop_state()
doc.saveas(root/'inheritance.dxf')
engineering=rt.read_engineering('inheritance.dxf','mechanical')
verified=rt.verify_dimensions('inheritance.dxf',[{'id':'length','handle':handle,'value':17}])
validation=rt.validate_drawing('inheritance.dxf',detail=True)
delivery=rt.deliver_drawing('inheritance.dxf','delivered',formats=['dxf','svg'])
result={'mutation':{'dim_layer':dim.dxf.layer,'text_layer':text.dxf.layer,'layer_0_transparency':doc.layers.get('0').transparency,'text_transparency_explicit':text.dxf.get('transparency'),'actual_svg_color':actual_color,'simulated_pushed_parent_color':simulated_color},'display':read_display(dim),'engineering':engineering,'verified':verified,'validation':validation,'delivery':delivery}
(root/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'mutation':result['mutation'],'display':result['display'],'critique':engineering.get('critique'),'manufacturing_passed':engineering['manufacturing'][0]['passed'],'accepted':verified['accepted'],'validation_passed':validation['validation']['passed'],'delivery_ok':delivery['ok'],'delivery_error':delivery.get('error')}))
