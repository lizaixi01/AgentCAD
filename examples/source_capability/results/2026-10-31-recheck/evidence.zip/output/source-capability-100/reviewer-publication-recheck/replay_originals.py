from pathlib import Path
import hashlib
import json
import subprocess

import ezdxf
import agentcad
from agentcad.dimension_display import read_display
from agentcad.policy import Policy
from agentcad.service import Runtime

REPO=Path(r'D:\Projects\AgentCAD-wt\review-pr44-publication-recheck')
OUT=Path(r'D:\Projects\AgentCAD-output\source-capability-100\reviewer-publication-recheck')
OLD=Path(r'D:\Projects\AgentCAD-output\source-capability-100\reviewer-publication-final\code-behavior')
HEAD='f1eb29885b12bc9438169b1839efe04486dccdb4'
assert Path(agentcad.__file__).resolve().is_relative_to(REPO)
assert subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'],text=True).strip()==HEAD

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
originals=[p for folder in ['transparency-probe','scientific-probe'] for p in (OLD/folder).rglob('*') if p.is_file()]
before={p.relative_to(OLD).as_posix():sha(p) for p in originals}
results=[]
errors=[]

cases=[
    ('transparent_original','transparency-probe/mechanical.dxf',None,False),
    ('transparent_opaque_control','transparency-probe/mechanical.dxf',0.0,True),
    ('transparent_partial_control','transparency-probe/mechanical.dxf',0.5,True),
    ('scientific_original','scientific-probe/scientific.dxf',None,False),
    ('scientific_correct_control','scientific-probe/scientific.dxf','%%c6.50E-03',True),
    ('scientific_zero_counterexample','scientific-probe/scientific.dxf','%%c0.00E+00',False),
    ('scientific_false_exponent','scientific-probe/scientific.dxf','%%c1.00E+03',False),
]
for name,source,change,expected in cases:
    root=OUT/'cases'/name
    root.mkdir(parents=True,exist_ok=True)
    source_path=OLD/source
    dest=root/source_path.name
    dest.write_bytes(source_path.read_bytes())
    doc=ezdxf.readfile(dest)
    is_mechanical=name.startswith('transparent')
    handle='E3' if is_mechanical else '8B'
    dim=doc.entitydb[handle]
    text=doc.blocks[dim.dxf.geometry].query('MTEXT').first
    if change is not None:
        if is_mechanical:text.transparency=change
        else:text.text=change
        doc.saveas(dest)
    input_hash=sha(dest)
    runtime=Runtime(Policy(root=root))
    checked=runtime.validate_drawing(dest.name,detail=True)
    verified=runtime.verify_dimensions(dest.name,[{'id':'nominal','handle':handle,'value':17 if is_mechanical else .0065}])
    delivery=runtime.deliver_drawing(dest.name,'delivered',formats=['dxf','svg'])
    actual={
        'validation_passed':checked['validation']['passed'],
        'dimensions_accepted':verified['accepted'],
        'delivery_ok':delivery['ok'],
    }
    engineering=None
    if is_mechanical:
        engineering=runtime.read_engineering(dest.name,'mechanical')
        actual['manufacturing_passed']=all(r['passed'] for r in engineering['manufacturing'])
        actual['critique_clear']=not engineering['critique']
    if any(value is not expected for value in actual.values()):errors.append(name+': unexpected acceptance '+str(actual))
    if sha(dest)!=input_hash:errors.append(name+': checked input was changed')
    if change is None and input_hash!=before[source]:errors.append(name+': original bytes not retained')
    if not expected and delivery.get('error',{}).get('code')!='DELIVERY_REJECTED':errors.append(name+': wrong delivery error')
    display=read_display(ezdxf.readfile(dest).entitydb[handle])
    if not is_mechanical and display['resolution']!=1e-5:errors.append(name+': scientific resolution '+str(display['resolution']))
    result={'case':name,'expected_acceptance':expected,'actual':actual,'source':str(source_path),'original_sha256':before[source],'case_sha256':input_hash,'unchanged_after_readback':sha(dest)==input_hash,'display':display,'validation':checked,'verification':verified,'delivery':delivery,'engineering':engineering}
    (root/'result.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf-8')
    results.append({k:v for k,v in result.items() if k not in ['validation','verification','delivery','engineering']})
after={p.relative_to(OLD).as_posix():sha(p) for p in originals}
if before!=after:errors.append('previous evidence changed')
report={'head':HEAD,'imported_from':agentcad.__file__,'ezdxf':ezdxf.__version__,'cases':results,'previous_evidence_files':len(before),'previous_evidence_unchanged':before==after,'previous_evidence_hashes':before,'errors':errors}
(OUT/'original-replay-results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps({'head':HEAD,'cases':[{'case':r['case'],'actual':r['actual'],'display_status':r['display']['status'],'resolution':r['display']['resolution']} for r in results],'previous_evidence_unchanged':before==after,'errors':errors},indent=2))
raise SystemExit(bool(errors))
