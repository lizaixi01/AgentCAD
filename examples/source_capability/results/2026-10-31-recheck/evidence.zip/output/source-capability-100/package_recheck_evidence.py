"""Publish the repaired source assessment without rewriting prior evidence."""
import hashlib,json,shutil,sys,zipfile
from pathlib import Path

root=Path('D:/Projects/AgentCAD-output/source-capability-100')
repo=Path('D:/Projects/AgentCAD-wt/source-capability-100')
sha='290ced3033f85e1fc97611cf1c920d922524bc3a';short=sha[:7]
target=repo/'examples/source_capability/results/2026-10-31-recheck'
old=target.parent/'2026-10-31'
older=target.parent/'2026-10-30'
prefix='output/source-capability-100/'
def read(p):return json.loads(p.read_text('utf-8-sig'))
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assessment=read(root/'reviewer-rubric-recheck/assessment.json')
assert assessment['status']=='final_local_recheck'
assert assessment['products'][0]['product_sha']==sha
for product in assessment['products']:
    assert len(product['items'])==20
    assert sum(c['score'] for c in product['categories'])==product['total_score']
    assert sum(i['score'] for i in product['items'])==product['total_score']
assert read(root/f'verification-summary-{short}.json')['all_test_ids_equal']
assert read(root/f'ci-source-parity-{short}.json')['passed']
assert read(root/f'ci-tree-parity-{short}.json')['entire_repository_tree_equal']
assert read(root/f'ci-artifact-integrity-{short}.json')['all_passed']
env=read(root/f'windows-native-{short}.environment.json')
assert env['exit_code']==0 and env['source_unchanged']
showcase=read(root/f'showcase-{short}/report.json')
assert showcase['source_commit']==sha and all(v=='passed' for v in showcase['checks'].values())
performance=read(root/f'performance-{short}/report.json')
assert performance['snapshots']['candidate']['commit']==sha and performance['correctness_passed']
assert read(root/f'v8-{short}/report.json')['adapter_metadata']['product_sha']==sha
assert digest(old/'evidence.zip')=='32762eea5694ac57e236964da41ee55803ebaabf817624a37c9a1cec9793ed5a'
assert digest(older/'evidence.zip')=='1d2889cf18d66faf3c3a4633ef5e49ae0d5ed29a22aa3a7f1d4834683165de3e'

mapping={
 'assessment.json':root/'reviewer-rubric-recheck/assessment.json',
 'assessment-review.md':root/'reviewer-rubric-recheck/FINAL-REVIEW.md',
 'verification-summary.json':root/f'verification-summary-{short}.json',
 'v8-report.json':root/f'v8-{short}/report.json',
 'performance.json':root/f'performance-{short}/report.json',
 'showcase-report.json':root/f'showcase-{short}/report.json',
 'visual-review.md':root/f'visual-review-{short}.md',
}
assert len(list((root/f'previews-{short}').glob('*.png')))==7
for p in mapping.values():assert p.is_file(),p

old_members={row['path']:row for row in read(old/'manifest.json')['members']}
files={p for p in root.iterdir() if p.is_file() and p.suffix in {'.json','.xml','.log','.py','.md','.txt'}}
trees=[
 'reviewer-rubric-recheck','reviewer-publication-final','reviewer-publication-recheck','reviewer-publication-recheck2',
 f'ci-{short}',f'ci-raw-{short}',f'v8-{short}',f'showcase-{short}',f'performance-{short}',f'previews-{short}',
 'v8-f1eb298','scientific-native-style-probe','scientific-zero-probe',
 'test-actual-appearance','test-actual-appearance-v2','test-required-opacity','test-visibility-scientific',
 'test-visibility-scientific-native','test-scientific-native-style-fixed',
]
excluded_parts={'__pycache__','.venv','.git','baseline','candidate'}
def eligible(p):
    parts=p.relative_to(root).parts
    return not any(x.startswith('snapshot-') or x in excluded_parts for x in parts)
for name in trees:
    directory=root/name
    assert directory.is_dir(),directory
    files.update(p for p in directory.rglob('*') if p.is_file() and eligible(p))
regression=root/f'test-windows-native-{short}'
for d in regression.iterdir():
    if d.is_dir() and d.name.startswith(('test_partial_block_transparenc','test_small_scientific_dimensio')):
        files.update(p for p in d.rglob('*') if p.is_file() and eligible(p))
current_index={row['path']:row for row in assessment['evidence_index']}
for path,row in current_index.items():
    p=root/path
    assert p.is_file() and eligible(p),path
    assert p.stat().st_size==row['bytes'] and digest(p)==row['sha256'],path
    assert prefix+path not in old_members,('Current evidence must have a fresh path; historical data uses inherited_evidence',path)
    files.add(p)
# Historical paths are supplied only by the byte-sealed companion archive. This
# prevents extraction from overwriting old records with later reusable scripts.
files={p for p in files if prefix+p.relative_to(root).as_posix() not in old_members}
assert all(not p.relative_to(root).as_posix().startswith('standards/') for p in files)

target.mkdir(parents=True,exist_ok=False)
for name,p in mapping.items():shutil.copyfile(p,target/name)
shutil.copytree(root/f'previews-{short}',target/'previews')
members=[];archive=target/'evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6,strict_timestamps=False) as z:
    for p in sorted(files):
        name=prefix+p.relative_to(root).as_posix()
        z.write(p,name)
        members.append({'path':name,'bytes':p.stat().st_size,'sha256':digest(p)})
manifest={'schema_version':2,'product_commit':sha,
 'archive':{'path':'evidence.zip','bytes':archive.stat().st_size,'sha256':digest(archive)},
 'members':members,
 'standalone':[{'path':p.relative_to(target).as_posix(),'bytes':p.stat().st_size,'sha256':digest(p)}
               for p in sorted(target.rglob('*')) if p.is_file() and p!=archive],
 'companion_archives':[
  {'assessment_key':'historical_local_review','path':'../2026-10-30/evidence.zip','sha256':digest(older/'evidence.zip'),
   'scope':'Original 98/96 review; historical unchanged-boundary evidence only.'},
  {'assessment_key':'superseded_local_review','path':'../2026-10-31/evidence.zip','sha256':digest(old/'evidence.zip'),
   'scope':'Original measured evidence from the superseded 6699109 assessment; invalidated score is not reused.'}],
 'exclusions':['Standards PDFs/page images and Autodesk sample drawings','Source snapshots, environments and benchmark source extracts',
  'Unrelated complete-test fixture corpus','Files already present in the sealed 2026-10-31 companion archive'],
 'manifest_excludes_itself_and_navigation_readme':True}
(target/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n','utf-8')
print(json.dumps({'archive':manifest['archive'],'members':len(members),'standalone':len(manifest['standalone'])}))
