"""Validate all evidence bytes, score sums and publication links."""
import hashlib,json,re,zipfile
from pathlib import Path
from urllib.parse import unquote
repo=Path('D:/Projects/AgentCAD-wt/source-capability-100')
out=Path('D:/Projects/AgentCAD-output/source-capability-100')
result=repo/'examples/source_capability/results/2026-10-31-recheck'
def read(p):return json.loads(p.read_text('utf-8-sig'))
def sha(data):return hashlib.sha256(data).hexdigest()
def check(data,row):
    assert len(data)==row['bytes'],row['path']
    assert sha(data)==row['sha256'],row['path']
m=read(result/'manifest.json');a=read(result/'assessment.json')
assert a['status']=='final_local_recheck'
assert (result/'assessment.json').read_bytes()==(out/'reviewer-rubric-recheck/assessment.json').read_bytes()
assert (result/'assessment-review.md').read_bytes()==(out/'reviewer-rubric-recheck/FINAL-REVIEW.md').read_bytes()
check((result/m['archive']['path']).read_bytes(),m['archive'])
paths=[row['path'] for row in m['members']]
assert len(paths)==len(set(paths))
with zipfile.ZipFile(result/'evidence.zip') as z:
    assert set(z.namelist())==set(paths)
    for row in m['members']:
        check(z.read(row['path']),row)
        assert '/standards/' not in row['path']
        assert not any(x.startswith('snapshot-') or x in {'.git','.venv','__pycache__','baseline','candidate'} for x in row['path'].split('/'))
    current={row['path']:row for row in a['evidence_index']}
    assert len(current)==len(a['evidence_index'])
    for row in current.values():check(z.read(a['evidence_path_base']+row['path']),row)
for row in m['standalone']:check((result/row['path']).read_bytes(),row)

old_sets={};old_hashes={}
for companion in m['companion_archives']:
    key=companion['assessment_key'];archive=(result/companion['path']).resolve()
    metadata=a[key]
    assert sha(archive.read_bytes())==companion['sha256']==metadata['evidence_zip_sha256']
    assert sha(archive.with_name('assessment.json').read_bytes())==metadata['assessment_sha256']
    inherited_rows=[row for row in a['inherited_evidence_index'] if row['archive']==key]
    indexed={row['path']:row for row in inherited_rows}
    assert len(indexed)==len(inherited_rows)
    with zipfile.ZipFile(archive) as z:
        assert set(paths).isdisjoint(z.namelist()),'New archive must not overwrite historical members'
        for row in indexed.values():check(z.read(metadata['evidence_path_base']+row['path']),row)
    old_sets[key]=indexed;old_hashes[key]=companion['sha256']
assert set(old_sets)=={row['archive'] for row in a['inherited_evidence_index']}
for product in a['products']:
    assert len(product['items'])==20
    assert sum(row['score'] for row in product['categories'])==product['total_score']
    assert sum(row['score'] for row in product['items'])==product['total_score']
    for item in product['items']:
        assert 0<=item['score']<=5
        for path in item['evidence_paths']:assert path in current,path
        for row in item['inherited_evidence']:assert row['path'] in old_sets[row['archive']],row

links=[]
for name in ['README.md','docs/benchmarks.md','docs/source-capability-recheck.md',
 'docs/source-capability-manufacturing-review.md','docs/decision-record.md',
 'examples/source_capability/README.md','examples/source_capability/results/2026-10-31/README.md',
 'examples/source_capability/results/2026-10-31-recheck/README.md']:
    file=repo/name
    for link in re.findall(r'\]\(([^)]+)\)',file.read_text('utf-8')):
        if re.match(r'[a-zA-Z]+:',link) or link.startswith('#'):continue
        path=unquote(link.split('#',1)[0]).strip('<>')
        if not path:continue
        target=(repo/path[1:] if path.startswith('/') else file.parent/path).resolve()
        assert target.exists(),(name,link)
        links.append((name,link))
summary={'passed':True,'product_commit':m['product_commit'],
 'scores':{p['name']:p['total_score'] for p in a['products']},
 'archive_members':len(paths),'current_indexed_evidence':len(current),
 'historical_index_counts':{k:len(v) for k,v in old_sets.items()},
 'standalone_files':len(m['standalone']),'local_links':len(links),
 'archive_sha256':m['archive']['sha256'],'historical_archives_unchanged':old_hashes,
 'no_extraction_path_collisions':True}
(out/'publication-validation-290ced3.json').write_text(json.dumps(summary,indent=2)+'\n','utf-8')
print(json.dumps(summary,indent=2))
