"""Run the relevant saved-behavior regressions from fixed Git in an isolated snapshot."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET

BASE = Path(r"D:\Projects\AgentCAD-output\source-capability-100")
OUT = BASE / "reviewer-rubric-recheck"
REPO = Path(r"D:\Projects\AgentCAD")
SHA = sys.argv[1]
SHORT = SHA[:7]
SNAPSHOT = OUT / ("snapshot-" + SHORT)
names = ["tests/conftest.py", "tests/test_dimension_appearance.py", "tests/test_dimension_display.py", "tests/test_mechanical_annotations.py", "tests/test_q_setup_gui.py"]
hashes = []
for name in names:
    raw = subprocess.check_output(["git", "-C", str(REPO), "show", f"{SHA}:{name}"])
    path = SNAPSHOT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == raw
    else:
        path.write_bytes(raw)
    hashes.append({"path": name, "git_content_sha256": hashlib.sha256(raw).hexdigest()})
env = dict(os.environ)
env["PYTHONPATH"] = str(SNAPSHOT / "src")
env["AGENTCAD_VIEWER"] = "0"
env.pop("AGENTCAD_NATIVE_TESTS", None)
env.pop("AGENTCAD_FREECAD_TESTS", None)
xml = OUT / ("headless-" + SHORT + ".xml")
cmd = [sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", "--basetemp=" + str(OUT / ("test-headless-" + SHORT)), "--junitxml=" + str(xml), *names[1:]]
result = subprocess.run(cmd, cwd=SNAPSHOT, env=env, capture_output=True, text=True, encoding="utf-8", errors="replace")
log = OUT / ("headless-" + SHORT + ".log")
log.write_text(result.stdout + result.stderr, encoding="utf-8")
tree = ET.parse(xml)
cases = list(tree.iter("testcase"))
counts = {"passed": 0, "skipped": 0, "failed": 0, "error": 0}
for case in cases:
    state = "failed" if case.find("failure") is not None else "error" if case.find("error") is not None else "skipped" if case.find("skipped") is not None else "passed"
    counts[state] += 1
report = {"product_sha": SHA, "source_snapshot": str(SNAPSHOT), "scope": "Headless effective appearance/scientific/parser/mechanical controls and real localhost setup/viewer tests with fake installation runners and temporary home; no native CAD/FreeCAD/Claude launch.", "command": cmd, "test_source_hashes": hashes, "exit_code": result.returncode, "counts": counts, "xml": xml.relative_to(BASE).as_posix(), "xml_sha256": hashlib.sha256(xml.read_bytes()).hexdigest(), "log": log.relative_to(BASE).as_posix(), "log_sha256": hashlib.sha256(log.read_bytes()).hexdigest()}
(OUT / ("headless-validation-" + SHORT + ".json")).write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"exit_code": result.returncode, "counts": counts, "log": str(log)}, indent=2))
raise SystemExit(result.returncode)
