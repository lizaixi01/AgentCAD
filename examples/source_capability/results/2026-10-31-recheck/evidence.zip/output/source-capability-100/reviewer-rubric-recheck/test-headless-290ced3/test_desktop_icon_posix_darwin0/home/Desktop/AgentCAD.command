#!/bin/sh
exec D:/Apps/hermes/bin/uvx.EXE --from git+https://github.com/lizaixi01/AgentCAD agentcad --root 'D:\Projects\AgentCAD-output\source-capability-100\reviewer-rubric-recheck\test-headless-290ced3\test_desktop_icon_posix_darwin0\home\AgentCAD' viewer --open
