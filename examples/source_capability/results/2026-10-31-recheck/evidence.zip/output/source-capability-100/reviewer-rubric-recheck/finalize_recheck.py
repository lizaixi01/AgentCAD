"""Build the new review only after explicit scoring decisions and completed evidence."""
from __future__ import annotations

import copy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

BASE = Path(r"D:\Projects\AgentCAD-output\source-capability-100")
OUT = BASE / "reviewer-rubric-recheck"
REPO = Path(r"D:\Projects\AgentCAD")
SHA = "290ced3033f85e1fc97611cf1c920d922524bc3a"
OLD = "66991092973496b148da45b1f847ddb1a8b4999d"
PRO = "58a05ddfc34a9832c626e82cd88ecdce8e16a62a"
ARCHIVE = "85ddde3b5e94307a70dc2897e08c0600190af10e"
OLD_SCORE_HASH = "836fbcf8dbf07d2b85eb42e78f11dffd779b2283b220caaaa3d178475df177d8"


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def git(*args):
    return subprocess.check_output(["git", "-C", str(REPO), *args])


decision_path = OUT / "scoring-decision-290ced3.json"
decisions = load(decision_path)
assert decisions["product_sha"] == SHA and decisions["pro_sha"] == PRO
assert decisions["final_evidence_review_completed"] is True
required = [
    "independent-validation-290ced3.json",
    "final-run-validation-290ced3.json",
    "native-angles-ci-artifacts-290ced3.json",
    "showcase-performance-validation-290ced3.json",
    "visual-review-290ced3.json",
]
evidence = {name: load(OUT / name) for name in required}
assert all(r["product_sha"] == SHA and r["passed"] is True for r in evidence.values())
raw = (BASE / "reviewer-rubric/assessment.json").read_bytes()
assert digest(raw) == OLD_SCORE_HASH
doc = json.loads(raw)
prior = copy.deepcopy(doc)
boundary = load(OUT / "boundary-trace-290ced3.json")
assert boundary["candidate_product_sha"] == SHA and boundary["rubric_unchanged"] is True
rubric = git("show", SHA + ":docs/source-capability-rubric.md")
assert digest(rubric) == doc["method"]["frozen_rubric_sha256"]

doc["status"] = "final_local_recheck"
doc["reviewed_at"] = "2026-10-31"
doc["finalized_at_utc"] = datetime.now(timezone.utc).isoformat()
doc["review_timezone"] = "Asia/Shanghai"
doc["pending_evidence"] = []
doc["method"]["frozen_rubric_sha256_basis"] = "SHA256 of the LF repository blob returned by git show " + SHA + ":docs/source-capability-rubric.md; not the CRLF working-tree bytes."
doc["publication_boundary"]["assessed_revision_only"] = "AgentCAD " + SHA + " and Pro " + PRO + ". Later merges, integration or publication commits are not relabeled as these measured products."
doc["source_recheck_inheritance"] = {
    "report": "reviewer-rubric-recheck/boundary-trace-290ced3.json",
    "prior_source": OLD,
    "changed_or_added_source_files": len(boundary["source_tree"]["changed"]),
    "unchanged_source_files": len(boundary["source_tree"]["unchanged"]),
    "rule": "No superseded score is inherited. Each unchanged implementation/data boundary is traced; changed shared appearance/display/rendering paths have current independent saved-byte, actual-output, native and complete-run evidence.",
}
doc["superseded_local_review"] = {
    "agentcad_score": 100,
    "pro_score": 93,
    "agentcad_sha": OLD,
    "pro_sha": PRO,
    "status": "AgentCAD total invalidated by later demonstrated false success; original files retained byte-for-byte",
    "assessment_url": "https://github.com/lizaixi01/AgentCAD/blob/" + ARCHIVE + "/examples/source_capability/results/2026-10-31/assessment.json",
    "assessment_sha256": OLD_SCORE_HASH,
    "evidence_zip_url": "https://github.com/lizaixi01/AgentCAD/blob/" + ARCHIVE + "/examples/source_capability/results/2026-10-31/evidence.zip",
    "evidence_zip_sha256": "32762eea5694ac57e236964da41ee55803ebaabf817624a37c9a1cec9793ed5a",
    "evidence_path_base": "output/source-capability-100/",
    "reason": "Actual fully transparent cached dimension text was accepted as visible, and scientific small-value display precision could admit a wrong value. Initial repair f1 left renderer inheritance and scientific-zero counterexamples. All four saved originals and controls were independently replayed after repair at the new fixed source.",
    "interpretation": "Recorded tests/drawings/performance remain historical facts. They do not certify the changed source or preserve the invalidated100 conclusion. Pro remains at the identical assessed source; its local93 is separate from upstream historical self-review93.",
}
doc["inherited_evidence_index"] = [dict(row, archive="historical_local_review") for row in prior["inherited_evidence_index"]]
doc["inherited_evidence_index"] += [dict(row, archive="superseded_local_review") for row in prior["evidence_index"]]
core = ["reviewer-rubric-recheck/boundary-trace-290ced3.json", "reviewer-rubric-recheck/independent-validation-290ced3.json", "reviewer-rubric-recheck/final-run-validation-290ced3.json"]
new_paths = set(core)

for product in doc["products"]:
    product_decisions = decisions["agentcad" if product["name"] == "AgentCAD" else "pro"]
    assert set(product_decisions) == {i["id"] for i in product["items"]}
    is_agent = product["name"] == "AgentCAD"
    product["status"] = "final_local_recheck"
    if is_agent:
        product["product_sha"] = SHA
        product["source_url"] = "https://github.com/lizaixi01/AgentCAD/tree/" + SHA
    for item in product["items"]:
        choice = product_decisions[item["id"]]
        assert type(choice["score"]) is int and 0 <= choice["score"] <= 5
        item["superseded_review_score"] = item["score"]
        item["score"] = choice["score"]
        item["deduction"] = {"points": 5 - choice["score"], "reason": choice["deduction_reason"]}
        item["inherited_evidence"] += [{"archive": "superseded_local_review", "path": p} for p in item["evidence_paths"]]
        item["evidence_paths"] = []
        if is_agent:
            item["basis"] = choice["basis"]
            if "scope_and_limits" in choice:
                item["scope_and_limits"] = choice["scope_and_limits"]
            item["evidence_paths"] = sorted(set(core + choice["evidence_paths"]))
            for source in item["source"]:
                path = source["path"]
                old_content = git("show", OLD + ":" + path)
                new_content = git("show", SHA + ":" + path)
                source["url"] = source["url"].replace(OLD, SHA)
                if old_content != new_content:
                    source["url"] = source["url"].split("#", 1)[0]
                    source.pop("line", None)
            for source in choice.get("additional_sources", []):
                entry = {"path": source["path"], "url": "https://github.com/lizaixi01/AgentCAD/blob/" + SHA + "/" + source["path"]}
                content = git("show", SHA + ":" + source["path"]).decode("utf-8")
                if source.get("anchor"):
                    lines = [n for n, line in enumerate(content.splitlines(), 1) if source["anchor"] in line]
                    assert len(lines) == 1, source
                    entry["line"] = lines[0]
                    entry["url"] += "#L" + str(lines[0])
                item["source"].append(entry)
            item["historical_evidence_use"] = "Implementation/data facts may be inherited only through the explicit boundary trace. Current evidence_paths verify changed consumers. Inherited files resolve through their named companion archive; their old score is not adopted."
        else:
            assert product["product_sha"] == PRO
            item["historical_evidence_use"] = "The pinned Pro source and frozen rubric are unchanged. This row was reassessed against the same archived independent counterexamples and source/native/CI facts; the same-byte AgentCAD controls were rerun at290. No new Pro native execution is claimed and no old Pro score is rewritten."
            if item["id"] == "C2":
                item["evidence_paths"] = ["reviewer-rubric-recheck/agent-generic-initial-precision-290ced3.json"]
        new_paths.update(item["evidence_paths"])
    scores = {i["id"]: i["score"] for i in product["items"]}
    for category in product["categories"]:
        category["score"] = sum(scores[k] for k in category["item_ids"])
        assert category["score"] <= category["weight"]
    product["total_score"] = sum(c["score"] for c in product["categories"])

doc["evidence_summary"] = decisions["evidence_summary"]
doc["consistency_notes"] = prior["consistency_notes"] + [
    "The later transparent-display and scientific-precision counterexamples invalidated AgentCAD669's100. They were assigned to responsible C2 under the same cap, and not mechanically deducted again from every downstream consumer.",
    "The original f1 repair was insufficient; raw inherited-layer SVG and scientific-zero failures remain preserved. The final decision follows current same-byte controls, actual output checks and completed fixed-source workflows, not merely a patch or target score.",
    "Initial independent169-test run had168 passes and a test_demo_icon path-sensitive assertion failure because 'reviewer' contains 'viewer'. Only that unchanged case was rerun under a neutral temporary root and passed; both records are retained. This is not described as a first-run all-green result.",
]
doc["review_limitations"] = prior["review_limitations"] + [
    "Effective alpha zero is rejected for required visible text. Nonzero alpha is checked for visible output; exact intermediate transparency intensity is not certified across every format.",
    "A final local maximum, if assigned, is conditional on the bounded reviewed contract and recorded evidence. The superseded prior maximum itself demonstrates that later counterexamples can change the judgment; no universal-correctness inference is permitted.",
]
doc["archive_requirements"] = {
    "primary_current_files": "All evidence_index entries are relative to output/source-capability-100/ and must be retained byte-for-byte in the new recheck ZIP.",
    "inherited_files": "Resolve inherited_evidence and inherited_evidence_index through the named historical_local_review or superseded_local_review companion ZIP, each with its recorded evidence_path_base. Neither archive nor original assessment is rewritten.",
    "extraction": "Extract all three ZIPs side by side preserving output/source-capability/ and output/source-capability-100/. The new archive uses new names and reviewer-rubric-recheck; it does not overwrite reviewer-rubric from either companion.",
    "raw_replays": "Retain new original-input copies, controls, result JSON, SVG/PDF, logs, current source snapshots and native witness copies in the recheck directory; retained f1 failures/interruption are historical, not current successes.",
    "external_current_path_dependencies": [],
}
new_paths.update(decisions["additional_evidence_paths"])
new_paths.update("reviewer-rubric-recheck/" + name for name in required)
new_paths.add("reviewer-rubric-recheck/scoring-decision-290ced3.json")
new_paths.add("reviewer-rubric-recheck/RECHECK-STATUS.md")
doc["evidence_index"] = []
for path in sorted(new_paths):
    assert not path.startswith("reviewer-rubric/"), path
    assert path not in {r["path"] for r in prior["evidence_index"]}, path
    absolute = (BASE / path).resolve()
    assert absolute.is_relative_to(BASE.resolve())
    raw = absolute.read_bytes()
    doc["evidence_index"].append({"path": path, "bytes": len(raw), "sha256": digest(raw)})

target = OUT / "assessment.json"
target.write_text(json.dumps(doc, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"status": doc["status"], "totals": {p["name"]: p["total_score"] for p in doc["products"]}, "current_evidence_files": len(doc["evidence_index"]), "output": str(target)}))
