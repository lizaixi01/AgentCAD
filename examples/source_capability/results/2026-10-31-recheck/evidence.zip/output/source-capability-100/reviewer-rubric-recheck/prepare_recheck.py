"""Trace all twenty boundaries without assigning scores or rewriting old records."""
from __future__ import annotations
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys

REPO = Path(r"D:\Projects\AgentCAD")
BASE = Path(r"D:\Projects\AgentCAD-output\source-capability-100")
OUT = BASE / "reviewer-rubric-recheck"
OLD = "66991092973496b148da45b1f847ddb1a8b4999d"
NEW = sys.argv[1]
ARCHIVE = "85ddde3b5e94307a70dc2897e08c0600190af10e"
OLD_PREFIX = "examples/source_capability/results/2026-10-31/"

def git(*args):
    return subprocess.check_output(["git", "-C", str(REPO), *args])

def sha(data):
    return hashlib.sha256(data).hexdigest()

def tree(commit):
    return {line.split("\t", 1)[1]: line.split()[2] for line in git("ls-tree", "-r", commit, "--", "src").decode().splitlines()}

prior_raw = (BASE / "reviewer-rubric/assessment.json").read_bytes()
assert sha(prior_raw) == "836fbcf8dbf07d2b85eb42e78f11dffd779b2283b220caaaa3d178475df177d8"
assert git("show", ARCHIVE + ":" + OLD_PREFIX + "assessment.json") == prior_raw
prior = json.loads(prior_raw)
rubric = git("show", NEW + ":docs/source-capability-rubric.md")
assert sha(rubric) == prior["method"]["frozen_rubric_sha256"]
old_tree, new_tree = tree(OLD), tree(NEW)
changed = sorted(p for p in set(old_tree) | set(new_tree) if old_tree.get(p) != new_tree.get(p))
rules = {
    "F1": "Geometry/model/measurement implementation is unchanged from669. Scientific resolution consumes measurement, so new display controls and final regression are still required; historical geometry/native evidence can corroborate the unchanged algorithms.",
    "F2": "Editing/engine/store and geometric identity code is unchanged. CLI/demo additions need their own safe-boundary review; do not silently extend the inherited editing contract to demo folder reset behavior.",
    "F3": "Dimension parsing now imports effective appearance and computes scientific resolution from physical magnitude. Actual saved text plus real rendered SVG/PDF and native regenerated controls are required; original transparency/scientific repairs alone do not close the follow-up inheritance/zero findings.",
    "F4": "Layouts/blocks/DXF/DWG implementation is unchanged, but the actual drawing renderer is implicated by parent inheritance. Any renderer fix will invalidate old visual-output equivalence until saved and rendered outputs are checked.",
    "F5": "P&ID, architecture and plant source code is unchanged; mechanical annotation appearance is changed. Traced old domain evidence may support unchanged semantics, with fresh representative final drawings required for the shared rendering path.",
    "C1": "Transaction/store/OS-lock implementations are unchanged. Negative new display/delivery cases must preserve source and existing targets. New demo reset/setup effects are not automatically covered by the old transaction evidence.",
    "C2": "New severe false success is established. Original transparent/scientific bytes are repaired in f1, but zero physical scientific values still accept a false0.004 display. Actual SVG inheritance also disagrees with the verifier. Responsible C2 cap remains2 until repairs and independent same-input positive/negative retests; no total assigned.",
    "C3": "DXF parity and publication logic is unchanged, but strict gates consume changed generic/manufacturing appearance checks and rendered artifacts. Recheck rejection/no-write, owned-XRECORD parity and explicit per-format scope. Do not count the same primary C2 false success again merely because delivery consumes it.",
    "C4": "Foreign-input/unsupported-feature paths are mostly unchanged. Changed visibility hidden/error classification and scientific exceptional magnitude/zero behavior require new abnormal-input controls; preserve explicit unknown/refusal rather than numeric inference.",
    "B1": "AutoCAD/FreeCAD backend implementations are unchanged, but setup/install/discovery-facing entry points changed in the merged main. Record missing-dependency/config safeguards separately; final native evidence still binds the new product.",
    "B2": "Native binary DXF backend is unchanged. Require current real native transparency inheritance and scientific regeneration checks plus normal drawing roundtrips; inspect original input without caches and actual native output. Standard-style missing-text failure remains in the record.",
    "B3": "No result from669 or interruptedf1 may be relabeled. Await current completed Windows/Linux/macOS CI, actual checkout SHA/source equality, same test-ID sets and explicit skip reasons, with enabled local native execution distinguished.",
    "E1": "Fits/standard-library tables and provenance are unchanged. The independently verified M14 and prior bounded standards sources may be inherited after exact blob tracing. This inherits source facts, not the superseded100 total.",
    "E2": "Mechanical annotation visibility changed and actual renderer inheritance is defective in f1. Require fresh final normal and tampered saved drawing cases, non-benchmark variants, required roles/owner/settings/source spans, and independent visual inspection of actual final artifacts. No assumed full mark.",
    "E3": "Domain geometry/connection/quantity algorithms are unchanged; retain old negative ARC/chord/missing-tag evidence through that boundary. Changed mechanical appearance must not accept invisible required notes/leaders/source geometry; final cross-domain showcase corroborates shared output.",
    "T1": "Read behavioral tests added for opacity/scientific display and merged setup/viewer code. Existing green counts did not cover newly found cases. Await complete fixed-version runs and independent counterexamples; no count-based points.",
    "T2": "Lockfile/dependency metadata is unchanged. Current product/evaluator/source/module hashes, raw failures/controls and output provenance must be rebuilt. Keep both old archives byte-identical and explicitly mark669 final conclusion superseded.",
    "T3": "Await final completed CI and unchanged upstream v8 gate plus exact-final-version same-host correctness/performance comparison. Interrupted f1 stages and earlier669 observations stay historical; no numeric performance extrapolation.",
    "S1": "Core HTTP/policy/guards are unchanged, but setup_gui/viewer/CLI/install/static UI changed in merged main. Read new routes, root/Host/origin/token/scope behavior and real no-write HTTP tests before inheriting this item. Desktop shortcuts are opt-in effects and cannot be confused with CAD script sandboxing.",
    "S2": "Core legacy fail-closed and OS-lock/cancellation/FreeCAD progress boundaries are unchanged. New demo/viewer startup and setup progress behavior need scoped review and current process/interface checks. No native/Claude launch by this reviewer.",
}
if NEW.startswith("290ced3"):
    rules.update({
        "F3": "Current same-byte transparency and scientific nonzero/zero controls pass. Shared DrawingFrontend now supplies DIMENSION property inheritance in actual Runtime SVG/PDF and viewer Workspace.svg. The original inherited-layer case matches its normal control in actual SVG bytes, viewer SVG bytes, PDF content streams and rendered pixels. Final native and formal showcase evidence remains pending.",
        "F4": "Layouts/blocks/DXF/DWG algorithms remain unchanged. Renderer routing changed in service/plot/viewer, so old visual-output equivalence is not blindly inherited. Current actual three-route inheritance controls pass; fresh complete final drawing workflows are still required.",
        "C2": "All four saved original transparency/scientific nonzero/inherited-layer/scientific-zero cases and paired controls were independently replayed at290ced3. Known false-success cases now reject or produce correct visible output; normal controls remain accepted. Eleven earlier generic/parser/angle/mechanical/source-span/XRECORD probes also pass. These specific serious-defect caps can be lifted after verified repair, but no final score is assigned until complete current evidence is assessed.",
        "C3": "Strict rejection consumes fixed visibility/scientific checks and succeeds on normal controls. Source bytes remain unchanged. Actual SVG/PDF/viewer output matches correct inheritance; fresh owned-XRECORD corruption replay still rejects. Per-format structural checks are not promoted into universal semantic parity. Final native/current showcase workflow remains pending.",
        "E2": "Fresh independent prior mechanical roles/owner/settings/fine-geometry/coordinate/all-view controls pass under the changed appearance/readback code. The inherited-layer output defect is repaired in actual SVG/PDF/viewer and the PDF was independently rendered/visually inspected. Final non-benchmark native showcase variants and formal visual review remain required; no full mark is presumed.",
        "S1": "Core HTTP/policy/guards are unchanged. Read the merged setup doctor/shortcut, viewer open/reuse, demo and quoting changes; tests use actual localhost HTTP and temporary homes with fake client/desktop runners. Current headless and final complete test results must confirm the new boundary, with native CAD/Claude never launched by this reviewer.",
    })
boundary = {
    "prior_product_sha": OLD, "candidate_product_sha": NEW,
    "frozen_rubric_sha256_git_lf_bytes": sha(rubric), "rubric_unchanged": True,
    "source_tree": {"prior_files": len(old_tree), "candidate_files": len(new_tree), "unchanged": sorted(p for p in old_tree if old_tree[p] == new_tree.get(p)), "changed": [{"path": p, "prior_blob": old_tree.get(p), "candidate_blob": new_tree.get(p)} for p in changed]},
    "items": [{"id": k, "inheritance_and_required_evidence": v, "score": None} for k, v in rules.items()],
    "status": "pending_new_fixed_product_and_complete_evidence",
    "superseded_prior_conclusion": "669100 is invalidated by independently confirmed invisible text and scientific precision false success. Original measurement/assessment files remain unchanged, with superseded labeling outside the sealed archive.",
    "scope": "All20 boundaries traced. Untouched code is not automatically equivalent if a changed shared dependency is in its behavior path."
}
boundary_name = "boundary-trace-" + NEW[:7] + ".json"
(OUT / boundary_name).write_text(json.dumps(boundary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
assessment = copy.deepcopy(prior)
for key in ("finalized_at_utc", "evidence_index", "archive_requirements", "evidence_summary"):
    assessment.pop(key, None)
assessment["status"] = "pending_recheck_no_final_scores"
assessment["evidence_summary"] = {"status": "pending", "original_replays": ["reviewer-rubric-recheck/transparency-replay-f1eb298.json", "reviewer-rubric-recheck/scientific-replay-f1eb298.json"], "unresolved_followup_evidence": "reviewer-rubric-recheck/followup-replay-f1eb298.json"}
if NEW.startswith("290ced3"):
    assessment["evidence_summary"] = {"status": "pending_complete_final_measurements", "original_replays": ["reviewer-rubric-recheck/transparency-replay-290ced3.json", "reviewer-rubric-recheck/scientific-replay-290ced3.json"], "followup_replay": "reviewer-rubric-recheck/followup-replay-290ced3.json", "actual_output_checks": "reviewer-rubric-recheck/actual-preview-validation-290ced3.json", "prior_behavior_replay": "reviewer-rubric-recheck/prior-replay-validation-290ced3.json"}
assessment["evidence_index"] = []
assessment["superseded_669_evidence_index"] = copy.deepcopy(prior["evidence_index"])
assessment["publication_boundary"]["assessed_revision_only"] = (
    "Pending recheck of candidate " + NEW + "; no new final score assigned. "
    "The former669 conclusion is superseded. Pro remains pinned at58a05dd."
)
assessment["source_recheck_inheritance"] = {"report": "reviewer-rubric-recheck/" + boundary_name, "note": "Do not inherit the superseded669 score. Only individually traced valid evidence can be inherited; new shared display/rendering paths require current verification."}
assessment["pending_evidence"] = ["Repair/replay scientific zero and actual renderer DIMENSION inheritance", "Fixed-source complete local native regression", "Four-lane completed CI with actual checkout/source and artifact hash binding", "Unmodified upstream v8 and gate", "Final native showcase and independent artifact visual review", "Exact-final same-host version correctness/performance comparison", "Final20-item reassessment under unchanged rubric"]
if NEW.startswith("290ced3"):
    assessment["pending_evidence"].pop(0)
assessment["superseded_669_review"] = {
    "product_sha": OLD, "conclusion_valid": False, "historical_scores": {"AgentCAD": 100, "Pro": 93},
    "reason": "Subsequent independent false-success counterexamples invalidate AgentCAD's former final score; raw original outcomes are preserved.",
    "assessment_url": f"https://github.com/lizaixi01/AgentCAD/blob/{ARCHIVE}/{OLD_PREFIX}assessment.json",
    "assessment_sha256": sha(prior_raw),
    "evidence_zip_url": f"https://github.com/lizaixi01/AgentCAD/blob/{ARCHIVE}/{OLD_PREFIX}evidence.zip",
    "evidence_zip_sha256": sha(git("show", ARCHIVE + ":" + OLD_PREFIX + "evidence.zip")),
    "evidence_path_base": "output/source-capability-100/",
    "archive_preserved": True,
}
for product in assessment["products"]:
    product["status"] = "pending_recheck"
    product["previous_round_score"] = product["total_score"]
    product["total_score"] = None
    for c in product["categories"]:
        c["previous_round_score"] = c["score"]
        c["score"] = None
    for item in product["items"]:
        item["previous_round_score"] = item["score"]
        item["score"] = None
        item["previous_round_deduction"] = item["deduction"]
        item["deduction"] = None
        item["previous_round_basis"] = item["basis"]
        item["inherited_evidence"] += [{"archive": "superseded_669_review", "path": p, "use": "Historical measured output only; not the invalidated total score."} for p in item["evidence_paths"]]
        item["evidence_paths"] = []
        if product["name"] == "AgentCAD":
            item["basis"] = rules[item["id"]]
            item["evidence_paths"] = ["reviewer-rubric-recheck/" + boundary_name]
            if item["id"] in {"F3", "C2", "C3", "E2"}:
                item["evidence_paths"] += assessment["evidence_summary"]["original_replays"] + [assessment["evidence_summary"].get("unresolved_followup_evidence", assessment["evidence_summary"].get("followup_replay"))]
                if NEW.startswith("290ced3"):
                    item["evidence_paths"] += [assessment["evidence_summary"]["actual_output_checks"], assessment["evidence_summary"]["prior_behavior_replay"]]
            for source in item["source"]:
                source["url"] = source["url"].replace(OLD, NEW).split("#")[0]
                source.pop("line", None)
        else:
            item["basis"] = "Pro remains fixed at58a05dd. Previous same-rubric item evidence and deduction rationale are retained for final reconsideration; no source change and no new Pro counterexample in this recheck."
    if product["name"] == "AgentCAD":
        product["product_sha"] = NEW
        product["source_url"] = product["source_url"].replace(OLD, NEW)
pending_name = "assessment.pending-" + NEW[:7] + ".json"
(OUT / pending_name).write_text(json.dumps(assessment, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"pending": pending_name, "boundary": boundary_name, "changed_source_files": len(changed), "unchanged_source_files": len(boundary["source_tree"]["unchanged"]), "all20_scores_null": True, "prior669_zip_sha256": assessment["superseded_669_review"]["evidence_zip_sha256"]}, indent=2))
