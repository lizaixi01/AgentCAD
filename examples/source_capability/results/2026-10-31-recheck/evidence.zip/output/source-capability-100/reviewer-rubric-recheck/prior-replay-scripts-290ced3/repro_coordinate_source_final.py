"""Fixed-source headless coordinate controls and source-integrity boundary cases."""
import argparse,hashlib,io,json,math,pathlib,subprocess,sys,tarfile

parser=argparse.ArgumentParser();parser.add_argument("sha");args=parser.parse_args()
OUT=pathlib.Path(r"D:\Projects\AgentCAD-output\source-capability-100\reviewer-rubric-recheck")
REPO=pathlib.Path(r"D:\Projects\AgentCAD")
snapshot=OUT/("snapshot-"+args.sha[:7])
if not snapshot.exists():
    data=subprocess.check_output(["git","-C",str(REPO),"archive",args.sha,"src"])
    with tarfile.open(fileobj=io.BytesIO(data)) as tar:
        for member in tar.getmembers():
            if member.isfile():
                target=snapshot/member.name
                assert target.resolve().is_relative_to(snapshot.resolve())
                target.parent.mkdir(parents=True,exist_ok=True)
                target.write_bytes(tar.extractfile(member).read())
sys.path.insert(0,str(snapshot/"src"))
import agentcad,ezdxf
from agentcad.policy import Policy
from agentcad.service import Runtime

cases=["normal_6_6","normal_8_decimal","control","right_both_one_ulp","right_lower_one_ulp",
       "repeated_diameter_control","repeated_diameter_one_ulp","repeated_bore_control","repeated_bore_one_ulp"]
results=[]
for case in cases:
    root=OUT/("coordinate-integrity-"+args.sha[:7]+"-"+case)
    assert not root.exists(),str(root)
    root.mkdir()
    rt=Runtime(Policy(root=root));assert rt.create_drawing("case.dxf",units="mm")["ok"]
    if case.startswith("repeated_diameter"):
        part={"name":case,"at":[130,1e8],"segments":[
            {"length":11,"d_outer":40.00000003},{"length":14,"d_outer":30},
            {"length":13,"d_outer":40.00000003}]}
    elif case.startswith("repeated_bore"):
        part={"name":case,"at":[130,1e8],"segments":[
            {"length":11,"d_outer":40,"d_inner":10.00000003},
            {"length":14,"d_outer":30,"d_inner":8},
            {"length":13,"d_outer":40,"d_inner":10.00000003}]}
    else:
        value=6.6 if case=="normal_6_6" else 17.12345678 if case=="normal_8_decimal" else 17.12345682
        part={"name":case,"at":[1e8,190],"segments":[{"length":value,"d_outer":40}]}
    generated=rt.apply_operations("case.dxf",[{"op":"draw_mechanical_assembly","spec":{"parts":[part]}}])
    result={"case":case,"part_spec":part,"generated":generated,"expected_success":"one_ulp" not in case}
    if generated["ok"]:
        before=rt.read_engineering("case.dxf","mechanical")
        result["before_read"]=before
        doc=ezdxf.readfile(root/"case.dxf")
        body=doc.entitydb[before["parts"][0]["handle"]]
        mutation=[]
        if case.startswith("right_"):
            points=list(body.get_points("xyseb"));xmax=max(p[0] for p in points);ymin=min(p[1] for p in points)
            changed=[]
            for i,p in enumerate(points):
                if p[0]==xmax and (case=="right_both_one_ulp" or p[1]==ymin):
                    q=(math.nextafter(p[0],math.inf),*p[1:]);mutation.append({"handle":body.dxf.handle,"vertex":i,"before":p,"after":q});changed.append(q)
                else:changed.append(p)
            body.set_points(changed,format="xyseb")
        elif case=="repeated_diameter_one_ulp":
            points=list(body.get_points("xyseb"));xmax=max(p[0] for p in points);ymax=max(p[1] for p in points)
            changed=[]
            for i,p in enumerate(points):
                if p[0]==xmax and p[1]==ymax:
                    q=(p[0],math.nextafter(p[1],math.inf),*p[2:]);mutation.append({"handle":body.dxf.handle,"vertex":i,"before":p,"after":q});changed.append(q)
                else:changed.append(p)
            body.set_points(changed,format="xyseb")
        elif case=="repeated_bore_one_ulp":
            bores=[e for e in doc.modelspace() if e.dxftype()=="LWPOLYLINE" and e.dxf.layer=="HIDDEN"]
            bore=min(bores,key=lambda e:min(p[1] for p in e.get_points("xy")))
            points=list(bore.get_points("xyseb"));xmax=max(p[0] for p in points);changed=[]
            for i,p in enumerate(points):
                if p[0]==xmax:
                    q=(p[0],math.nextafter(p[1],-math.inf),*p[2:]);mutation.append({"handle":bore.dxf.handle,"vertex":i,"before":p,"after":q});changed.append(q)
                else:changed.append(p)
            bore.set_points(changed,format="xyseb")
        if "one_ulp" in case:
            assert mutation,case
            doc.saveas(root/"case.dxf")
        result["mutation"]=mutation
        result["read"]=rt.read_engineering("case.dxf","mechanical")
        result["delivery"]=rt.deliver_drawing("case.dxf","delivery",formats=["dxf"],strict=True)
        result["meets_expected_behavior"]=(bool(result["delivery"]["ok"])==result["expected_success"] and
            bool(result["read"].get("critique"))!=result["expected_success"])
        result["file_sha256"]=hashlib.sha256((root/"case.dxf").read_bytes()).hexdigest()
    else:
        result["meets_expected_behavior"]=False
    (root/"result.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    results.append(result)
report={"product_sha":args.sha,"imported_from":agentcad.__file__,"python":sys.version,"ezdxf":ezdxf.__version__,
    "scope":"Headless Runtime operations and saved DXF reread only. No CAD process launched.","cases":results,
    "all_expected_behavior":all(r["meets_expected_behavior"] for r in results)}
(OUT/("coordinate-source-counterexamples-"+args.sha[:7]+".json")).write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"product_sha":args.sha,"cases":[{"case":r["case"],"generated_ok":r["generated"]["ok"],
    "critique":r.get("read",{}).get("critique"),"delivery_ok":r.get("delivery",{}).get("ok"),
    "meets_expected_behavior":r["meets_expected_behavior"]} for r in results],"all_expected_behavior":report["all_expected_behavior"]}))
