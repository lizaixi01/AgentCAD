新复核已确认原最终结论被后续反例推翻。`reviewer-rubric/` 以及其 100/93 评分文件保持逐字节不变，作为当时的历史评审；**AgentCAD 6699109 的 100 不能继续作为有效最终结论发布**。本轮新总分保持待定，不能预设修复后的分数。

评审身份：independent AI reviewer, requested/published by AgentCAD。未修改产品源码，未启动 AutoCAD、FreeCAD 或 Claude。仍使用原冻结六类权重与 20 项累计锚点。

2026-10-31 独立复现确认：

- 对原件 `reviewer-publication-final/code-behavior/transparency-probe/mechanical.dxf` 的相同字节，在新建的固定源码快照 **66991092973496b148da45b1f847ddb1a8b4999d** 和 **85ddde3b5e94307a70dc2897e08c0600190af10e** 上分别调用公开 Runtime。
- 尺寸 E3 的实际 MTEXT FC 是 `17`，`transparency=1.0`，渲染属性颜色 `#ffffff00`。`read_display` 仍返回 `status=read,value=17`；`read_engineering` 的 manufacturing、`verify_dimensions.accepted`、严格 DXF/SVG 交付全部通过。
- 独立解析生成 SVG 的 CSS 和路径，确认有 1 个实际路径使用 `fill-opacity:0.000`，不是只依据 DXF 元数据猜测不可见。
- 不透明（0.0）和半透明（0.5）控制均通过，SVG 没有零透明度路径；三组保存源文件在读取和交付后均未被改变。
- 原始输出、控制文件、代码哈希及公开接口返回分别在 `transparency-replay-6699109.json`、`transparency-replay-85ddde3.json` 和对应原件目录。脚本为 `replay_transparency.py`。

根因锚点是两条可见性路径同时遗漏有效透明度：

- [dimension_display.py:79](https://github.com/lizaixi01/AgentCAD/blob/66991092973496b148da45b1f847ddb1a8b4999d/src/agentcad/dimension_display.py#L79) 的 `_visible` 只检查 invisible、图层关闭/冻结/打印标记；`read_display` 因而把透明文字认证为可见主值。
- [mechanical_annotations.py:35](https://github.com/lizaixi01/AgentCAD/blob/66991092973496b148da45b1f847ddb1a8b4999d/src/agentcad/engineering/mechanical_annotations.py#L35) 存在独立的同类判断，`_rendered`、所需注释和源几何沿用它。
- 这两个文件及 verification、validate/checks、validate/features、delivery 六个相关模块，从 6699109 到 85ddde3 的固定 Git 内容完全一致。新一轮分别执行也确认了继承，而不是仅凭“看起来未改”推断。

严重假通过主归 **C2，修复并用相同输入独立重验前上限为 2**。其严格交付成功和制造检查通过是同一可见性缺口的后果，不机械再扣 C3/E2；但这两项依赖新的可见性判断，修复后必须补相应行为证据。已有正常图纸的视觉观察仍是有效历史事实，不能证明未测试的透明输入正确，也不能推翻本反例。

新固定版本至少需要：

1. 相同原始透明字节通过通用绑定验证、显式尺寸要求、机械 readback 和严格交付时均明确拒绝，显示值不可由几何或原始字符串补推；不透明与部分透明正常控制继续通过，源文件/既有目标文件不被失败流程改写。
2. 对已支持的 TEXT/MTEXT、必要机械注释以及上下文的有效透明度建立边界控制：实体自身、ByLayer、ByBlock/父 DIMENSION（尤其块内 layer 0）。以实际渲染上下文和保存 SVG 的有效 alpha 交叉验证，不能只补单一 `entity.transparency` 比较。
3. 继承并重放现有数字后缀、分数/公差、默认 DIMRND、角度精度、所有视图/源几何、所属空间、遗漏角色、XRECORD 等相关反例；其他能力证据逐项追踪最终源码差异后继承，不把旧全回归和旧图纸重标新 SHA。
4. 固定新 SHA 后运行必要完整回归、实际原生保存/重开显示验证、CI、原版 v8 和版本性能记录；若某项依赖边界确实未变，写清允许继承的理由和来源。最终普通图纸须重新检查，不以新异常拒绝代替可用的正常输出。

需要根代理串行执行的原生见证规格：保留不透明正常图及原始完全透明尺寸图，经实际 AutoCAD 保存/重开，保留原始 native job、二进制 DXF 中间件、DWG 和公开 readback 返回；核实文字及透明度设置是否保存。正常图仍可接受；透明图按输出端实际透明语义明确拒绝。透明度不属于结构损坏，AUDIT 为零不能替代可见性核验。无需 reviewer 启动原生 CAD。

旧 669 的 815/8 回归、CI、31/31 v8、图纸和性能都保留为实际完成的历史测量；新的缺陷说明这些测试没有覆盖该边界。原 98/96 历史和 Pro 93 的固定版本判断不因本 AgentCAD 缺陷被偷偷改写。本轮待新版本、独立复验和完整证据到齐后重新评定。

f1eb298 的独立复验及后续反例（2026-10-31）：

- 固定 `f1eb29885b12bc9438169b1839efe04486dccdb4` 已拒绝最初完全透明原件，不透明/半透明对照通过；相同科学计数法原件的分辨率由 0.01 修正为 0.00001，实际 `9.90E-03` 拒绝、`6.50E-03` 对照通过。原始科学计数法漏洞影响普通 validation/strict delivery；显式 `verify_dimensions` 在旧 669 上本来就正确拒绝，不能夸大为所有验证接口均失败。证据为本目录两份 `*-replay-f1eb298.json`，以及新增旧版 `scientific-replay-6699109.json`。
- 发布复审随后给出的透明继承原件，已由本评审在 f1 用**相同 DXF 字节**复放：父 DIMENSION 在不透明 DIM 层，子文字在 layer 0，layer 0 完全透明；可见性 helper 按正确的父层继承判为可见，但真实 SVG 渲染没有应用同一上下文，生成 1 条零 alpha 文字路径而所有验证仍通过。不透明 layer 0 对照通过且没有该路径。这个修复必须同步实际 renderer，不能只用手动 push 的模拟 RenderContext 自证，也不应将正确的 DXF 继承规则降格迎合渲染缺陷。
- 根代理的零物理量科学格式原件也已同字节重放：物理值 0 配 `4.00E-03`，f1 仍给 resolution=0.01，普通验证与严格交付错误通过；显式绑定验证拒绝，`0.00E+00` 正常对照通过。两组完整返回及实际 SVG 路径在 `followup-replay-f1eb298.json`。C2 上限仍未解除，原先两项修复的有效证据保留。
- `boundary-trace-f1eb298.json` 已逐项说明 20 个能力边界的继承条件：669→f1 有 14 个新增/改变的源文件、65 个源码文件相同。除本次 appearance/display/checks/mechanical 修改，还包括主线带来的 CLI/demo/install/setup/viewer/UI；它们没有被静默当作旧 669 的完整测量。`assessment.pending-f1eb298.json` 的所有新分数为 null，原 100/93 仅作为已被后续反例推翻的历史判断。
- 旧 669 的证据 ZIP 在固定公开归档提交 85ddde3 下 SHA256 为 `32762eea5694ac57e236964da41ee55803ebaabf817624a37c9a1cec9793ed5a`，assessment SHA256 仍为 `836fbcf8dbf07d2b85eb42e78f11dffd779b2283b220caaaa3d178475df177d8`。新结果应同时链接旧 669 ZIP 和更早 98/96 的 ZIP；只继承逐项追踪后仍有效的原始事实，不继承失效总分。

290ced3 的独立复验（2026-10-31，仍待完整证据）：

- 固定 `290ced3033f85e1fc97611cf1c920d922524bc3a` 已重放全部四种保存原件：完全透明尺寸明确拒绝；科学非零假值和零物理量假值拒绝；正确的父 DIMENSION/子 layer 0 继承保持接受且实际渲染可见。各组正常对照继续通过，读取与交付未改变保存源字节。`transparency-replay-290ced3.json`、`scientific-replay-290ced3.json`、`followup-replay-290ced3.json` 保留完整返回。
- 新共享 DrawingFrontend 被真实 Runtime SVG/PDF 和 viewer Workspace.svg 使用。继承原件与不透明 layer 0 对照的 SVG 字节、viewer SVG 字节、PDF 内容流和 Poppler 像素均相同；本人打开生成的 PDF 预览确认目标 `17` 可见。该小型反例图有明确的打印文字过小警告，不能冒充正式制造图出图证据。详见 `actual-preview-validation-290ced3.json` 和 `visual-inheritance-290ced3.json`。部分透明控制只证明非零有效 alpha 仍有可见输出，不声称各格式中间透明强度精确一致。
- 11 组原有独立脚本已用同一固定源码重新执行，覆盖与 Pro 相同字节的初始 6.4/6 显示、显式要求语义、分数/后缀解析、默认 DIMRND、角度格式、机械所属空间/角色、舍入/单位、微小几何、坐标/重复直径、全部视图及 XRECORD 丢失。独立验证不只检查进程 exit 0，还逐项核对反例拒绝、正常控制接受与原始字节绑定。
- 四个相关测试文件首次 169 项中 168 通过、1 失败。失败的 `test_demo_icon` 在整个 desktop 文件中查找 `viewer`，临时路径 `reviewer-rubric-recheck` 因含该子串触发误报。产品和测试代码未改，只将这一例的临时根移到不含该子串的路径后重跑，1 通过。初始 JUnit/日志、单例重跑和解释均保留，不能写成首次全绿：`headless-context-correction-290ced3.json`。
- `independent-validation-290ced3.json` 的 252 项明确断言通过：全部 80 个源码/静态文件与固定 Git 和 archive 内容相符；文本仅允许 CRLF/LF 差异，分别记录原始哈希。旧封存评审的三个文件再次逐字节核实未变。669→290 的 17 个变动/新增文件、63 个相同文件以及全部 20 项继承规则见 `boundary-trace-290ced3.json`。
- 上述四个已证实缺陷的具体上限可在修复、同输入重验后解除，但这不自动产生满分。`assessment.pending-290ced3.json` 仍不赋最终分；当前完整原生、CI/v8、正式出图、同环境性能与最终视觉证据必须独立核查后才签发新评审。旧 669 的 100 仍保持已失效的历史结论。

290ced3 最终定稿（2026-10-31）：所有待核验证据已到齐并独立完成审阅。新 `assessment.json` / `FINAL-REVIEW.md` 为 AgentCAD 100、Pro 93；不是自动继承旧分数，逐项依据与相同严重缺陷上限均已写明。当前完整原生885/8、四CI同893 IDs、本机/CI原版v8均31/31、7份本人逐张检查的正式PDF以及24次同机性能观测均已核实；另行通过GitHub插件读取的四ZIP摘要也相符。旧封存文件保持不变，所有 pending 文件仍作为形成过程保留，不是新最终结论。
