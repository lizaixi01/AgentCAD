"""Check actual exported PDF/SVG and viewer SVG from the unchanged inheritance input."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET

BASE = Path(r"D:\Projects\AgentCAD-output\source-capability-100")
OUT = BASE / "reviewer-rubric-recheck"
SHA = sys.argv[1]
SNAPSHOT = OUT / ("snapshot-" + SHA[:7])
sys.path.insert(0, str(SNAPSHOT / "src"))
import agentcad.service as service_module
from agentcad.policy import Policy
from agentcad.service import Runtime
from agentcad.viewer import Workspace
import pypdf
assert Path(service_module.__file__).resolve().is_relative_to(SNAPSHOT.resolve())
PDFTOPPM = Path(r"C:\Users\HUAWEI\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\poppler\Library\bin\pdftoppm.exe")

def digest(data):
    return hashlib.sha256(data).hexdigest()

root = OUT / ("actual-previews-" + SHA[:7])
root.mkdir(exist_ok=False)
cases = []
for mode in ("same_bytes", "normal_control"):
    source = OUT / ("followup-" + SHA[:7]) / ("inheritance-" + mode) / "inheritance.dxf"
    directory = root / mode
    directory.mkdir()
    path = directory / "inheritance.dxf"
    path.write_bytes(source.read_bytes())
    before = path.read_bytes()
    runtime = Runtime(Policy(root=directory))
    exported = {fmt: runtime.export_drawing(path.name, "drawing." + fmt, fmt) for fmt in ("svg", "pdf")}
    assert all(r["ok"] for r in exported.values()), exported
    workspace = Workspace(runtime.policy, directory / "viewer-cache")
    viewer_svg = workspace.svg(path.name, None)
    (directory / "viewer.svg").write_text(viewer_svg, encoding="utf-8")
    svg = (directory / "drawing.svg").read_bytes()
    assert b"fill-opacity: 0.000" not in svg
    assert "fill-opacity: 0.000" not in viewer_svg
    reader = pypdf.PdfReader(directory / "drawing.pdf")
    streams = [page.get_contents().get_data() for page in reader.pages]
    pdf_image = directory / "drawing.png"
    subprocess.run([str(PDFTOPPM), "-png", "-singlefile", "-scale-to", "2000", str(directory / "drawing.pdf"), str(directory / "drawing")], check=True, capture_output=True)
    assert path.read_bytes() == before
    cases.append({"mode": mode, "source_input": source.relative_to(BASE).as_posix(), "input_sha256": digest(before), "exported": exported, "svg_sha256": digest(svg), "viewer_svg_sha256": digest(viewer_svg.encode()), "pdf": (directory / "drawing.pdf").relative_to(BASE).as_posix(), "pdf_sha256": digest((directory / "drawing.pdf").read_bytes()), "pdf_page_stream_hashes": [digest(x) for x in streams], "image": pdf_image.relative_to(BASE).as_posix(), "image_sha256": digest(pdf_image.read_bytes()), "source_file_unchanged": True})
checks = {
    "exported_svg_exactly_equal_to_opaque_layer0_control": cases[0]["svg_sha256"] == cases[1]["svg_sha256"],
    "viewer_svg_exactly_equal_to_opaque_layer0_control": cases[0]["viewer_svg_sha256"] == cases[1]["viewer_svg_sha256"],
    "pdf_content_streams_equal_to_opaque_layer0_control": cases[0]["pdf_page_stream_hashes"] == cases[1]["pdf_page_stream_hashes"],
    "rendered_pdf_pixels_equal_to_opaque_layer0_control": cases[0]["image_sha256"] == cases[1]["image_sha256"],
}
assert all(checks.values()), checks
report = {"product_sha": SHA, "passed": True, "scope": "Actual Runtime SVG/PDF export and actual Workspace.svg route, not manually pushed RenderContext. PDF content and Poppler raster equality against paired opaque layer0 control; source bytes unchanged. No CAD/native application launched.", "checks": checks, "cases": cases, "visual_inspection": "Record manual image inspection separately after opening the image."}
output = OUT / ("actual-preview-validation-" + SHA[:7] + ".json")
output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"report": str(output), "checks": checks, "image": str(root / "same_bytes/drawing.png")}, indent=2))
