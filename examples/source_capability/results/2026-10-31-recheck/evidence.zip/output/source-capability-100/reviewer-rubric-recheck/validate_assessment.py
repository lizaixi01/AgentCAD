"""Final report arithmetic, current/companion references and sealed-history audit."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

BASE = Path(r"D:\Projects\AgentCAD-output\source-capability-100")
OUT = BASE / "reviewer-rubric-recheck"
OLD_BASE = Path(r"D:\Projects\AgentCAD-output\source-capability")
SHA = "290ced3033f85e1fc97611cf1c920d922524bc3a"
PRO = "58a05ddfc34a9832c626e82cd88ecdce8e16a62a"


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


doc = load(OUT / "assessment.json")
assert doc["status"] == "final_local_recheck" and doc["pending_evidence"] == []
assert doc["assessor"]["display_name"] == "independent AI reviewer, requested/published by AgentCAD"
assert doc["publication_boundary"]["upstream_approved"] is False
assert doc["publication_boundary"]["external_certification"] is False
assert doc["method"]["frozen_rubric_sha256"] == "be562004ba7f25c0d131cdf690c9dc4844cd0df9dc3ede467ae2308420d1d52e"
expected_ids = {"F1", "F2", "F3", "F4", "F5", "C1", "C2", "C3", "C4", "B1", "B2", "B3", "E1", "E2", "E3", "T1", "T2", "T3", "S1", "S2"}
current = {row["path"]: row for row in doc["evidence_index"]}
assert len(current) == len(doc["evidence_index"])
prior = load(BASE / "reviewer-rubric/assessment.json")
prior_paths = {row["path"] for row in prior["evidence_index"]}
assert set(current).isdisjoint(prior_paths)
for path, row in current.items():
    assert not path.startswith("reviewer-rubric/")
    file = (BASE / path).resolve()
    assert file.is_relative_to(BASE.resolve()) and file.is_file()
    assert file.stat().st_size == row["bytes"] and digest(file) == row["sha256"], path
archives = {"historical_local_review": OLD_BASE, "superseded_local_review": BASE}
inherited = {(row["archive"], row["path"]): row for row in doc["inherited_evidence_index"]}
assert len(inherited) == len(doc["inherited_evidence_index"])
for (archive, path), row in inherited.items():
    file = (archives[archive] / path).resolve()
    assert file.is_relative_to(archives[archive].resolve()) and file.is_file()
    assert file.stat().st_size == row["bytes"] and digest(file) == row["sha256"], (archive, path)
products = []
for product in doc["products"]:
    expected_sha = SHA if product["name"] == "AgentCAD" else PRO
    assert product["product_sha"] == expected_sha
    assert {row["id"] for row in product["items"]} == expected_ids
    scores = {}
    for item in product["items"]:
        assert type(item["score"]) is int and 0 <= item["score"] <= 5
        assert item["deduction"]["points"] == 5 - item["score"]
        assert item["basis"] and item["scope_and_limits"] and item["deduction"]["reason"]
        scores[item["id"]] = item["score"]
        assert all(path in current for path in item["evidence_paths"])
        assert all((row["archive"], row["path"]) in inherited for row in item["inherited_evidence"])
        assert all(expected_sha in s["url"] for s in item["source"]), item["id"]
    assert [row["weight"] for row in product["categories"]] == [25, 20, 15, 15, 15, 10]
    for category in product["categories"]:
        assert category["score"] == sum(scores[k] for k in category["item_ids"])
    assert product["total_score"] == sum(scores.values()) == sum(row["score"] for row in product["categories"])
    products.append({"product": product["name"], "sha": expected_sha, "total": product["total_score"], "categories": [row["score"] for row in product["categories"]]})
sealed = load(OUT / "sealed-prior-integrity.json")
for row in sealed["files"]:
    assert digest(BASE / row["path"]) == row["sha256"]
assert digest(OLD_BASE / "reviewer-rubric/assessment.json") == "760521504a260f31472e3b1945a3f40bc72587d13d9ee0bc2c57f6df5f727ddf"
report = {
    "product_sha": SHA,
    "validated_at_utc": datetime.now(timezone.utc).isoformat(),
    "passed": True,
    "products": products,
    "current_evidence_files": len(current),
    "current_paths_do_not_overlap_sealed669_index": True,
    "inherited_files_checked": len(inherited),
    "companion_archive_labels": list(archives),
    "all_referenced_current_and_inherited_files_resolve_and_match_hash": True,
    "all_product_source_links_pinned_to_assessed_sha": True,
    "historical_assessments_unchanged": True,
    "final_files": [{"path": "reviewer-rubric-recheck/" + name, "bytes": (OUT / name).stat().st_size, "sha256": digest(OUT / name)} for name in ["assessment.json", "FINAL-REVIEW.md"]],
}
(OUT / "assessment-validation.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(json.dumps(report, indent=2))
