"""Repeat independently reported sum/section cases using fresh fixed-source specifications."""
import argparse,hashlib,json,math,pathlib,sys
parser=argparse.ArgumentParser();parser.add_argument("sha");args=parser.parse_args()
OUT=pathlib.Path(r"D:\Projects\AgentCAD-output\source-capability-100\reviewer-rubric-recheck")
sys.path.insert(0,str(OUT/("snapshot-"+args.sha[:7])/"src"))
import agentcad,ezdxf
from agentcad.policy import Policy
from agentcad.service import Runtime
from agentcad.engineering.records import get
cases=[("sum_50_058",50,.58),("sum_50_11",50,1.1),("sum_30_058",30,.58),("sum_50_01",50,.1),
       ("section_control",None,None),("section_bore_4_ulp",None,None)]
results=[]
for case,count,step in cases:
    root=OUT/("all-view-"+args.sha[:7]+"-"+case);assert not root.exists();root.mkdir()
    rt=Runtime(Policy(root=root));assert rt.create_drawing("case.dxf",units="mm")["ok"]
    spec={"parts":[{"name":"decimal segments","at":[130,190],"segments":[{"length":step,"d_outer":40} for _ in range(count)]}]} if count else {
        "parts":[{"name":"section control","at":[135,1e7],"views":["front","section"],
                  "segments":[{"length":20,"d_outer":40,"d_inner":17.12345678}]}]}
    generated=rt.apply_operations("case.dxf",[{"op":"draw_mechanical_assembly","spec":spec}])
    result={"case":case,"spec":spec,"generated":generated,"expected_success":case!="section_bore_4_ulp"}
    if generated["ok"]:
        before=rt.read_engineering("case.dxf","mechanical");result["before"]=before
        if case=="section_bore_4_ulp":
            doc=ezdxf.readfile(root/"case.dxf")
            sections=[e for e in doc.modelspace() if e.dxftype()=="LWPOLYLINE" and (get(e,"mech") or {}).get("role")=="section"]
            upper=max(sections,key=lambda e:max(p[1] for p in e.get_points("xy")))
            points=list(upper.get_points("xyseb"));low=min(p[1] for p in points)
            index=next(i for i,p in enumerate(points) if p[1]==low)
            original=points[index];changed=original[1]
            for _ in range(4):changed=math.nextafter(changed,math.inf)
            points[index]=(original[0],changed,*original[2:]);upper.set_points(points,format="xyseb")
            doc.saveas(root/"case.dxf")
            result["mutation"]={"handle":upper.dxf.handle,"vertex":index,"before":original,"after":points[index],"delta":changed-original[1]}
        result["read"]=rt.read_engineering("case.dxf","mechanical")
        result["delivery"]=rt.deliver_drawing("case.dxf","delivery",formats=["dxf"],strict=True)
        result["meets_expected_behavior"]=(result["delivery"]["ok"]==result["expected_success"] and
            bool(result["read"].get("critique"))!=result["expected_success"])
        if count:
            row=next(a for a in result["read"]["manufacturing"][0]["annotations"] if a["kind"]=="overall_length")
            result["nominal_overall"]=math.fsum([step]*count);result["measured_overall"]=row["measurement"]
        result["file_sha256"]=hashlib.sha256((root/"case.dxf").read_bytes()).hexdigest()
    else:result["meets_expected_behavior"]=False
    (root/"result.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8");results.append(result)
report={"product_sha":args.sha,"imported_from":agentcad.__file__,"python":sys.version,"ezdxf":ezdxf.__version__,
        "cases":results,"all_expected_behavior":all(r["meets_expected_behavior"] for r in results)}
(OUT/("all-view-source-counterexamples-"+args.sha[:7]+".json")).write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"product_sha":args.sha,"all_expected_behavior":report["all_expected_behavior"],"cases":[{
    "case":r["case"],"generated_ok":r["generated"]["ok"],"delivery_ok":r.get("delivery",{}).get("ok"),
    "critique":r.get("read",{}).get("critique"),"nominal_overall":r.get("nominal_overall"),"measured_overall":r.get("measured_overall")} for r in results]}))
