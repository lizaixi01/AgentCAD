"""Check default zero-increment rendering and later precision edits via public operations."""
import argparse,io,json,math,pathlib,subprocess,sys,tarfile
arg=argparse.ArgumentParser();arg.add_argument("sha");args=arg.parse_args()
OUT=pathlib.Path(r"D:\Projects\AgentCAD-output\source-capability-100\reviewer-rubric-recheck");label=args.sha[:7]
snapshot=OUT/("snapshot-"+label)
if not snapshot.exists():
    snapshot.mkdir()
    archive=subprocess.check_output(["git","-C",r"D:\Projects\AgentCAD","archive",args.sha,"src"])
    with tarfile.open(fileobj=io.BytesIO(archive)) as tar:tar.extractall(snapshot,filter="data")
sys.path.insert(0,str(snapshot/"src"))
import agentcad,ezdxf
from agentcad.dimension_display import read_display
from agentcad.policy import Policy
from agentcad.service import Runtime
root=OUT/("generic-default-render-"+label);root.mkdir(exist_ok=True)
runtime=Runtime(Policy(root=root));assert runtime.create_drawing("case.dxf",units="mm")["ok"]
created=runtime.apply_operations("case.dxf",[{"op":"add_linear_dim","p1":[0,0],"p2":[30,40],"orientation":"rotated","angle":30,"tag":"rotated"}])
def inspect():
    doc=ezdxf.readfile(root/"case.dxf");d=doc.modelspace().query("DIMENSION").first
    return doc,d,{"handle":d.dxf.handle,"display":read_display(d),"dimdec":d.override().get("dimdec"),"dimrnd":d.override().get("dimrnd",0)}
doc,d,before=inspect();override=d.override();override.update({"dimdec":3});override.commit();doc.saveas(root/"case.dxf")
modified=runtime.apply_operations("case.dxf",[{"op":"modify","target":d.dxf.handle,"set":{"text_height":3.0}}])
_,_,after=inspect()
physical=30*math.cos(math.radians(30))+40*math.sin(math.radians(30))
validation=runtime.validate_drawing("case.dxf",detail=True,requirements=[{"type":"dimension","kind":"linear","value":physical}])
result={"product_sha":args.sha,"imported_from":agentcad.__file__,"created":created,"modified":modified,"physical_measurement":physical,"initial":before,"after_precision_edit":after,"validation":validation,"all_expected":created.get("ok") is True and modified.get("ok") is True and before["display"]["value"]==45.98 and after["display"]["value"]==45.981 and before["dimrnd"]==after["dimrnd"]==0 and validation.get("validation",{}).get("passed") is True,"scope":"Saved generic rotated DIM created with native DIMRND=0 and DIMDEC2; later DIMDEC3 plus public text-height edit must redraw without persisting an artificial rounding increment."}
(OUT/("generic-default-render-"+label+".json")).write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"product_sha":args.sha,"all_expected":result["all_expected"],"initial":before,"after":after}))
