"""Replay r9 saved angular cache failures and paired controls against fixed source."""
import argparse,hashlib,json,pathlib,sys
arg=argparse.ArgumentParser();arg.add_argument("sha");args=arg.parse_args()
ROOT=pathlib.Path(r"D:\Projects\AgentCAD-output\source-capability-100");OUT=ROOT/"reviewer-rubric-recheck";label=args.sha[:7]
snapshot=OUT/("snapshot-"+label);sys.path.insert(0,str(snapshot/"src"))
import agentcad,ezdxf
from agentcad.dimension_display import read_display
from agentcad.policy import Policy
from agentcad.service import Runtime
assert pathlib.Path(agentcad.__file__).resolve().is_relative_to(snapshot.resolve())
cases=[]
for units in (2,5):
    source=ROOT/"reviewer-pr44-r9/angular-precision"/f"linear-units-{units}-angular-cache.dxf";raw=source.read_bytes()
    for role in ("original-damaged","normal-control"):
        directory=OUT/("angular-precision-"+label)/f"units-{units}-{role}";directory.mkdir(parents=True,exist_ok=True)
        target=directory/"case.dxf";target.write_bytes(raw)
        if role=="normal-control":
            doc=ezdxf.readfile(target);dim=doc.modelspace().query("DIMENSION").first
            doc.blocks[dim.dxf.geometry].query("MTEXT").first.text="60.0000%%d";doc.saveas(target)
        before=target.read_bytes();doc=ezdxf.readfile(target);dim=doc.modelspace().query("DIMENSION").first
        display=read_display(dim);runtime=Runtime(Policy(root=directory))
        validation=runtime.validate_drawing("case.dxf",detail=True)
        delivery=runtime.deliver_drawing("case.dxf","delivery",formats=["dxf"])
        expected=role=="normal-control"
        match=display["resolution"]==.0001 and validation.get("validation",{}).get("passed") is expected and delivery.get("ok") is expected
        cases.append({"case":f"units-{units}-{role}","source":source.relative_to(ROOT).as_posix(),"source_sha256":hashlib.sha256(raw).hexdigest(),"input":target.relative_to(ROOT).as_posix(),"input_sha256":hashlib.sha256(before).hexdigest(),"same_bytes_as_original":before==raw,"control_change":"only cached text60.0100 changed to60.0000" if expected else None,"input_unchanged_during_verification":before==target.read_bytes(),"display":display,"validation":validation,"delivery":delivery,"all_expected":match})
for angular_unit in (1,2,3,4):
    directory=OUT/("angular-precision-"+label)/f"unsupported-angular-{angular_unit}";directory.mkdir(parents=True,exist_ok=True)
    doc=ezdxf.readfile(source);dim=doc.modelspace().query("DIMENSION").first
    override=dim.override();override.update({"dimaunit":angular_unit});override.commit()
    doc.blocks[dim.dxf.geometry].query("MTEXT").first.text="60";target=directory/"case.dxf";doc.saveas(target)
    before=target.read_bytes();display=read_display(ezdxf.readfile(target).entitydb[dim.dxf.handle])
    validation=Runtime(Policy(root=directory)).validate_drawing("case.dxf",detail=True,requirements=[{"type":"dimension","kind":"angular","value":60}])
    cases.append({"case":f"unsupported-angular-{angular_unit}","input":target.relative_to(ROOT).as_posix(),"input_sha256":hashlib.sha256(before).hexdigest(),"input_unchanged_during_verification":before==target.read_bytes(),"display":display,"validation":validation,"all_expected":display["value"] is None and display["status"]=="unsupported_angular_format" and validation.get("validation",{}).get("passed") is False})
report={"product_sha":args.sha,"imported_from":agentcad.__file__,"scope":"r9 exact saved decimal-degree failures with DIMLUNIT2/5, paired text-only corrected controls, and explicit refusal to certify bare non-decimal angular formats as degrees.","cases":cases,"all_expected":all(c["all_expected"] and c["input_unchanged_during_verification"] for c in cases)}
(OUT/("angular-precision-"+label+".json")).write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"product_sha":args.sha,"all_expected":report["all_expected"],"cases":[{"case":c["case"],"status":c["display"]["status"],"passed":c["validation"]["validation"]["passed"],"expected":c["all_expected"]} for c in cases]}))
