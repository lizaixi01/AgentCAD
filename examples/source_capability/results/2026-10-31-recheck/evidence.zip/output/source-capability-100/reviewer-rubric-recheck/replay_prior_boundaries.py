"""Relocate prior independent probes; preserve the sealed originals byte-for-byte."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import subprocess
import sys

BASE = Path(r"D:\Projects\AgentCAD-output\source-capability-100")
OLD = BASE / "reviewer-rubric"
OUT = BASE / "reviewer-rubric-recheck"
SHA = sys.argv[1]
SHORT = SHA[:7]
ORIGINAL = "953c3f07359970438aac2dee281288f76f5feffd"
scripts = [
    "repro_agent_generic_initial_precision.py", "repro_generic_requirement_semantics.py",
    "repro_generic_parser_boundaries.py", "repro_generic_default_render.py", "repro_angular_precision.py",
    "repro_annotation_boundaries_953c3f0.py", "repro_precision_953c3f0.py", "repro_fine_geometry_953c3f0.py",
    "repro_coordinate_source_final.py", "repro_all_view_sources.py", "repro_xrecord_delivery_953c3f0.py",
]
copies = []
for kind in ("control", "rounded_at_creation"):
    source = OLD / ("pro-initial-check-" + kind) / "case.dxf"
    target = OUT / ("pro-initial-check-" + kind) / "case.dxf"
    target.parent.mkdir(exist_ok=True)
    if target.exists():
        assert target.read_bytes() == source.read_bytes()
    else:
        target.write_bytes(source.read_bytes())
    copies.append({"source": source.relative_to(BASE).as_posix(), "copy": target.relative_to(BASE).as_posix(), "sha256": hashlib.sha256(source.read_bytes()).hexdigest()})
directory = OUT / ("prior-replay-scripts-" + SHORT)
directory.mkdir(exist_ok=False)
reports = []
for name in scripts:
    source = OLD / name
    original_raw = source.read_bytes()
    code = original_raw.decode("utf-8-sig")
    # Only output/snapshot locations and fixed revision labels change. Input
    # fixtures in reviewer-pr44-r8/r9 remain the same saved byte sources.
    code = code.replace(str(OLD), str(OUT)).replace('ROOT/"reviewer-rubric"', 'ROOT/"reviewer-rubric-recheck"')
    code = code.replace(ORIGINAL, SHA).replace("953c3f0", SHORT)
    target = directory / name.replace("953c3f0", SHORT)
    target.write_text(code, encoding="utf-8")
    arguments = [sys.executable, str(target)]
    if "args.sha" in code:
        arguments.append(SHA)
    proc = subprocess.run(arguments, cwd=OUT, capture_output=True, text=True, encoding="utf-8", errors="replace")
    log = directory / (target.stem + ".log")
    log.write_text(proc.stdout + proc.stderr, encoding="utf-8")
    assert source.read_bytes() == original_raw
    reports.append({"source_script": source.relative_to(BASE).as_posix(), "source_script_sha256": hashlib.sha256(original_raw).hexdigest(), "relocated_script": target.relative_to(BASE).as_posix(), "relocated_script_sha256": hashlib.sha256(target.read_bytes()).hexdigest(), "exit_code": proc.returncode, "log": log.relative_to(BASE).as_posix()})
    if proc.returncode:
        break
result = {"product_sha": SHA, "scope": "Eleven prior independent headless probes replayed in the new reviewer directory. Relocation changes only output/snapshot location and fixed SHA labels, not behavioral inputs or assertions. Original scripts and prior sealed files remain unchanged.", "copied_same_byte_inputs": copies, "runs": reports, "passed": len(reports) == len(scripts) and all(r["exit_code"] == 0 for r in reports)}
(OUT / ("prior-replay-validation-" + SHORT + ".json")).write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"passed": result["passed"], "completed": len(reports), "runs": [{"name": r["relocated_script"], "exit_code": r["exit_code"]} for r in reports]}, indent=2))
raise SystemExit(0 if result["passed"] else 1)
