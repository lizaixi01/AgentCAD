"""Saved-byte follow-up probes: actual rendered inheritance and scientific zero."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

BASE = Path(r"D:\Projects\AgentCAD-output\source-capability-100")
OUT = BASE / "reviewer-rubric-recheck"
SHA = sys.argv[1]
SNAPSHOT = OUT / ("snapshot-" + SHA[:7])
sys.path.insert(0, str(SNAPSHOT / "src"))
import ezdxf
import agentcad.service as service_module
from agentcad.dimension_display import read_display
from agentcad.policy import Policy
from agentcad.service import Runtime
assert Path(service_module.__file__).resolve().is_relative_to(SNAPSHOT.resolve())

def sha256(raw):
    return hashlib.sha256(raw).hexdigest()

cases = []
for kind, source, filename, handle, value in [
    ("inheritance", BASE / "reviewer-publication-recheck/code-behavior/inheritance-probe/inheritance.dxf", "inheritance.dxf", "E3", 17),
    ("scientific_zero", BASE / "scientific-zero-probe/zero.dxf", "zero.dxf", "8B", 0),
]:
    raw = source.read_bytes()
    for mode in ("same_bytes", "normal_control"):
        root = OUT / ("followup-" + SHA[:7]) / (kind + "-" + mode)
        root.mkdir(parents=True, exist_ok=False)
        path = root / filename
        path.write_bytes(raw)
        if mode == "normal_control":
            doc = ezdxf.readfile(path)
            if kind == "inheritance":
                doc.layers.get("0").transparency = 0
            else:
                dim = doc.entitydb[handle]
                doc.blocks[dim.dxf.geometry].query("MTEXT").first.text = "0.00E+00"
            doc.saveas(path)
        before = path.read_bytes()
        doc = ezdxf.readfile(path)
        dim = doc.entitydb[handle]
        rt = Runtime(Policy(root=root))
        validation = rt.validate_drawing(filename, detail=True)
        verification = rt.verify_dimensions(filename, [{"id": "dimension", "handle": handle, "value": value}])
        engineering = rt.read_engineering(filename, "mechanical") if kind == "inheritance" else None
        delivery = rt.deliver_drawing(filename, "delivery", formats=["dxf", "svg"] if kind == "inheritance" else ["dxf"])
        svg_file = root / "delivery" / (Path(filename).stem + ".svg")
        svg = None
        if svg_file.is_file():
            tree = ET.fromstring(svg_file.read_bytes())
            styles = {}
            for e in tree.iter():
                if e.tag.endswith("style") and e.text:
                    for cls, body in re.findall(r"\.([^\s{]+)\s*\{([^}]*)\}", e.text):
                        styles[cls] = dict((a.strip(), b.strip()) for a, b in re.findall(r"([\w-]+)\s*:\s*([^;]+);", body))
            hidden = [key for key, value in styles.items() if value.get("fill-opacity") == "0.000"]
            paths = [e.attrib for e in tree.iter() if e.tag.endswith("path") and e.attrib.get("class") in hidden]
            svg = {"path": svg_file.relative_to(BASE).as_posix(), "sha256": sha256(svg_file.read_bytes()), "zero_alpha_path_count": len(paths), "zero_alpha_paths": paths}
        result = {"kind": kind, "mode": mode, "input_original": source.relative_to(BASE).as_posix(), "input_original_sha256": sha256(raw), "input_before_api_sha256": sha256(before), "same_bytes": before == raw, "measurement": dim.get_measurement(), "display": read_display(dim), "validation": validation, "verification": verification, "engineering": engineering, "delivery": delivery, "svg": svg, "input_unchanged_after_api": path.read_bytes() == before}
        (root / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        cases.append(result)
report = {"product_sha": SHA, "scope": "Independent same-byte replay and paired controls; inspect actual SVG styles/paths as well as saved dimension properties. No native applications launched.", "cases": cases}
path = OUT / ("followup-replay-" + SHA[:7] + ".json")
path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"report": str(path), "cases": [{"kind": r["kind"], "mode": r["mode"], "display": r["display"], "validation_passed": r["validation"]["validation"]["passed"], "verify_accepted": r["verification"]["accepted"], "delivery_ok": r["delivery"]["ok"], "svg_zero_alpha_paths": None if r["svg"] is None else r["svg"]["zero_alpha_path_count"]} for r in cases]}, indent=2))
