"""Recheck the exact saved scientific-precision counterexample and paired controls."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import subprocess
import sys

BASE = Path(r"D:\Projects\AgentCAD-output\source-capability-100")
OUT = BASE / "reviewer-rubric-recheck"
REPO = Path(r"D:\Projects\AgentCAD")
SHA = sys.argv[1]
SHORT = SHA[:7]
SNAPSHOT = OUT / ("snapshot-" + SHORT)
INPUT = BASE / "reviewer-publication-final/code-behavior/scientific-probe/scientific.dxf"
assert (SNAPSHOT / "src/agentcad/dimension_display.py").is_file(), "Run the fixed snapshot preparation first."
sys.path.insert(0, str(SNAPSHOT / "src"))
import ezdxf
import agentcad.service as service_module
from agentcad.policy import Policy
from agentcad.service import Runtime
from agentcad.dimension_display import read_display
assert Path(service_module.__file__).resolve().is_relative_to(SNAPSHOT.resolve())

def sha256(data):
    return hashlib.sha256(data).hexdigest()

sources = []
for rel in ["src/agentcad/dimension_display.py", "src/agentcad/validate/checks.py", "src/agentcad/validate/features.py", "src/agentcad/validate/requirements.py", "src/agentcad/model.py", "src/agentcad/delivery.py"]:
    git = subprocess.check_output(["git", "-C", str(REPO), "show", f"{SHA}:{rel}"])
    local = (SNAPSHOT / rel).read_bytes()
    assert local.replace(b"\r\n", b"\n") == git.replace(b"\r\n", b"\n")
    sources.append({"path": rel, "git_sha256": sha256(git), "snapshot_sha256": sha256(local)})
raw = INPUT.read_bytes()
cases = []
for name, new_text in [("same_bytes_wrong", None), ("correct_control", "%%c6.50E-03"), ("zero_wrong", "%%c0.00E+00"), ("forged_large_exponent", "%%c1.00E+03")]:
    root = OUT / ("scientific-" + SHORT) / name
    root.mkdir(parents=True, exist_ok=False)
    path = root / "scientific.dxf"
    path.write_bytes(raw)
    if new_text is not None:
        doc = ezdxf.readfile(path)
        dim = doc.entitydb["8B"]
        doc.blocks[dim.dxf.geometry].query("MTEXT").first.text = new_text
        doc.saveas(path)
    before = path.read_bytes()
    if new_text is None:
        assert before == raw
    doc = ezdxf.readfile(path)
    dim = doc.entitydb["8B"]
    rt = Runtime(Policy(root=root))
    validation = rt.validate_drawing("scientific.dxf", detail=True)
    verification = rt.verify_dimensions("scientific.dxf", [{"id": "diameter", "handle": "8B", "value": .0065}])
    delivery = rt.deliver_drawing("scientific.dxf", "delivery", formats=["dxf"])
    result = {"case": name, "input_file": path.relative_to(BASE).as_posix(), "input_sha256_before_api": sha256(before), "identical_original_bytes": before == raw, "measurement": dim.get_measurement(), "read_display": read_display(dim), "validation": validation, "verify_dimensions": verification, "delivery": delivery, "source_unchanged": path.read_bytes() == before}
    (root / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    cases.append(result)
report = {"product_sha": SHA, "reviewer": "independent AI reviewer, requested/published by AgentCAD", "scope": "Fixed-source saved-byte public Runtime checks. Only actual cached MTEXT is changed for paired controls. No CAD/FreeCAD/Claude.", "source_boundary": sources, "original_input": INPUT.relative_to(BASE).as_posix(), "original_input_sha256": sha256(raw), "python": sys.version, "ezdxf": ezdxf.__version__, "cases": cases}
output = OUT / ("scientific-replay-" + SHORT + ".json")
output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"report": str(output), "cases": [{"case": r["case"], "display": r["read_display"], "validation_passed": r["validation"]["validation"]["passed"], "verify_accepted": r["verify_dimensions"]["accepted"], "delivery_ok": r["delivery"]["ok"]} for r in cases]}, indent=2))
