"""Replay the PR reviewer's exact saved parser fixtures against fixed source; no native CAD."""
import argparse,hashlib,io,json,pathlib,subprocess,sys,tarfile
arg=argparse.ArgumentParser();arg.add_argument("sha");args=arg.parse_args()
ROOT=pathlib.Path(r"D:\Projects\AgentCAD-output\source-capability-100")
OUT=ROOT/"reviewer-rubric-recheck";label=args.sha[:7];snapshot=OUT/("snapshot-"+label)
if not snapshot.exists():
    snapshot.mkdir()
    archive=subprocess.check_output(["git","-C",r"D:\Projects\AgentCAD","archive",args.sha,"src"])
    with tarfile.open(fileobj=io.BytesIO(archive)) as tar:tar.extractall(snapshot,filter="data")
sys.path.insert(0,str(snapshot/"src"))
import agentcad,ezdxf
from agentcad.policy import Policy
from agentcad.service import Runtime
assert pathlib.Path(agentcad.__file__).resolve().is_relative_to(snapshot.resolve())
manifest=[]
for name,diameter,expected in (("suffix-control",6.4,True),("suffix-tampered",6.0,False),("literal-normal",6.4,True)):
    manifest.append(("cases",name,diameter,expected))
for stack in (47,35):
    for tag,diameter,expected in (("normal",6.5,True),("tampered",6.0,False)):
        manifest.append(("additional-cases",f"fraction-{stack}-tolerance-{tag}",diameter,expected))
    manifest.append(("additional-cases",f"fraction-{stack}-no-tolerance",6.5,True))
cases=[]
for folder,name,diameter,expected in manifest:
    source=ROOT/"reviewer-pr44-r8"/folder/(name+".dxf");raw=source.read_bytes()
    directory=OUT/("generic-parser-"+label)/name;directory.mkdir(parents=True,exist_ok=True)
    target=directory/"case.dxf";target.write_bytes(raw)
    doc=ezdxf.readfile(target);dim=doc.modelspace().query("DIMENSION").first
    texts=[e.dxf.text if e.dxftype()=="TEXT" else e.text for e in doc.blocks[dim.dxf.geometry] if e.dxftype() in {"TEXT","MTEXT"}]
    runtime=Runtime(Policy(root=directory))
    verify=runtime.verify_dimensions("case.dxf",[{"id":"hole","handle":dim.dxf.handle,"value":diameter}])
    validation=runtime.validate_drawing("case.dxf",detail=True,requirements=[{"type":"dimension","kind":"diameter","value":diameter}])
    delivery=runtime.deliver_drawing("case.dxf","delivery",formats=["dxf"])
    case={"case":name,"original_input":source.relative_to(ROOT).as_posix(),"input":target.relative_to(ROOT).as_posix(),"input_sha256":hashlib.sha256(raw).hexdigest(),"same_bytes_as_original":target.read_bytes()==raw==source.read_bytes(),"physical_diameter":diameter,"expected_accepted":expected,"raw_texts":texts,"verify":verify,"validation":validation,"delivery":delivery}
    case["behavior_matches_expected"]=(verify.get("accepted") is expected and validation.get("validation",{}).get("passed") is expected and delivery.get("ok") is expected)
    (directory/"result.json").write_text(json.dumps(case,indent=2)+"\n",encoding="utf-8")
    cases.append(case)
result={"product_sha":args.sha,"imported_from":agentcad.__file__,"scope":"Same-byte replay of suffix/fraction fixtures from independent PR reviewer r8 through public Runtime APIs; no input regeneration, native CAD or product changes.","cases":cases,"all_expected":all(c["behavior_matches_expected"] for c in cases)}
(OUT/("generic-parser-boundaries-"+label+".json")).write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"product_sha":args.sha,"all_expected":result["all_expected"],"cases":[{"case":c["case"],"expected":c["expected_accepted"],"accepted":c["verify"].get("accepted"),"displayed":c["verify"].get("rows",[{}])[0].get("displayed"),"delivery":c["delivery"].get("ok")} for c in cases]}))
