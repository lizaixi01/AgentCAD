"""Audit the already completed independent headless runs, without native applications."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile
import xml.etree.ElementTree as ET

BASE = Path(r"D:\Projects\AgentCAD-output\source-capability-100")
OUT = BASE / "reviewer-rubric-recheck"
REPO = Path(r"D:\Projects\AgentCAD")
SHA = "290ced3033f85e1fc97611cf1c920d922524bc3a"
SNAPSHOT = OUT / "snapshot-290ced3"
checks = []
index = {}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def check(name, passed, detail=None):
    checks.append({"check": name, "passed": bool(passed), "detail": detail})
    assert passed, name


def load(name):
    path = OUT / (name + ".json")
    raw = path.read_bytes()
    index[path.relative_to(BASE).as_posix()] = {"sha256": digest(raw), "bytes": len(raw)}
    result = json.loads(raw)
    if "product_sha" in result:
        check(name + ": fixed product", result["product_sha"] == SHA)
    return result


def git(*args):
    return subprocess.check_output(["git", "-C", str(REPO), *args])


archive = git("archive", "--format=tar", SHA, "src")
sources = []
with tarfile.open(fileobj=io.BytesIO(archive), mode="r:") as tar:
    for member in tar.getmembers():
        if not member.isfile():
            continue
        actual = (SNAPSHOT / member.name).read_bytes()
        archived = tar.extractfile(member).read()
        blob = git("show", SHA + ":" + member.name)
        is_text = Path(member.name).suffix not in {".png", ".jpg", ".jpeg", ".ico"}
        equivalent = actual.replace(b"\r\n", b"\n") == blob.replace(b"\r\n", b"\n") if is_text else actual == blob
        check(member.name + ": snapshot/archive exact and Git content parity", actual == archived and equivalent)
        sources.append({"path": member.name, "git_blob_content_sha256": digest(blob), "snapshot_raw_sha256": digest(actual), "git_archive_raw_sha256": digest(archived), "normalization": "CRLF to LF only" if is_text else "binary, none"})
check("All fixed source and static files included", len(sources) == 80)

for name in ["transparency-replay-290ced3", "scientific-replay-290ced3"]:
    report = load(name)
    original = (BASE / report["original_input"]).read_bytes()
    check(name + ": original raw hash", digest(original) == report["original_input_sha256"])
    for case in report["cases"]:
        actual = (BASE / case["input_file"]).read_bytes()
        check(name + ": saved input unchanged: " + case["case"], digest(actual) == case["input_sha256_before_api"])
        if case["case"].startswith("same_bytes"):
            check(name + ": original exact byte replay", case["identical_original_bytes"] and actual == original)
        expected = case["case"] in {"opaque_control", "partial_control", "correct_control"}
        check(name + ": public verification: " + case["case"], case["verify_dimensions"]["accepted"] is expected)
        check(name + ": strict delivery: " + case["case"], case["delivery"]["ok"] is expected)
        if name.startswith("transparency"):
            check(name + ": manufacturing: " + case["case"], case["read_engineering"]["manufacturing"][0]["passed"] is expected)
            check(name + ": visible text state: " + case["case"], case["read_display"]["status"] == ("read" if expected else "hidden"))
            check(name + ": source unchanged flag: " + case["case"], case["source_file_unchanged_by_read_and_delivery"])
            if expected:
                check(name + ": actual SVG has no fully transparent paths: " + case["case"], case["svg"]["zero_alpha_path_count"] == 0)
        else:
            check(name + ": general validation: " + case["case"], case["validation"]["validation"]["passed"] is expected)
            check(name + ": physical scientific precision: " + case["case"], case["read_display"]["resolution"] == 1e-5)
            check(name + ": source unchanged flag: " + case["case"], case["source_unchanged"])

followup = load("followup-replay-290ced3")
for case in followup["cases"]:
    key = case["kind"] + "/" + case["mode"]
    original = (BASE / case["input_original"]).read_bytes()
    check(key + ": original raw hash", digest(original) == case["input_original_sha256"])
    if case["mode"] == "same_bytes":
        check(key + ": original exact byte replay", case["same_bytes"] and case["input_before_api_sha256"] == digest(original))
    expected = case["kind"] == "inheritance" or case["mode"] == "normal_control"
    check(key + ": verification", case["verification"]["accepted"] is expected)
    check(key + ": validation", case["validation"]["validation"]["passed"] is expected)
    check(key + ": delivery", case["delivery"]["ok"] is expected)
    check(key + ": source unchanged", case["input_unchanged_after_api"])
    if case["kind"] == "inheritance":
        check(key + ": actual SVG visible", case["svg"]["zero_alpha_path_count"] == 0)
    else:
        check(key + ": scientific zero resolution", case["display"]["resolution"] == 0)

preview = load("actual-preview-validation-290ced3")
check("Actual SVG / viewer / PDF stream / PDF pixels equal paired control", preview["passed"] and all(preview["checks"].values()))
for case in preview["cases"]:
    for file_key, hash_key in [("source_input", "input_sha256"), ("pdf", "pdf_sha256"), ("image", "image_sha256")]:
        check("Actual preview hash: " + case["mode"] + "/" + file_key, digest((BASE / case[file_key]).read_bytes()) == case[hash_key])
    check("Preview source unchanged: " + case["mode"], case["source_file_unchanged"])

initial = load("agent-generic-initial-precision-290ced3")
for case in initial["cases"]:
    expected = case["case"] == "control"
    check("Generic same-byte Pro input: " + case["case"], case["in_memory_verification"]["accepted"] is expected and case["saved_public_verification"]["accepted"] is expected)

for name, aggregate, row_key in [
    ("generic-requirement-semantics-290ced3", "all_expected_behavior", None),
    ("generic-parser-boundaries-290ced3", "all_expected", "behavior_matches_expected"),
    ("generic-default-render-290ced3", "all_expected", None),
    ("angular-precision-290ced3", "all_expected", "all_expected"),
    ("coordinate-source-counterexamples-290ced3", "all_expected_behavior", "meets_expected_behavior"),
    ("all-view-source-counterexamples-290ced3", "all_expected_behavior", "meets_expected_behavior"),
]:
    report = load(name)
    check(name + ": behavioral expectations", report[aggregate] is True)
    if row_key:
        for case in report["cases"]:
            check(name + ": " + case["case"], case[row_key] is True)

annotations = load("annotation-counterexamples-290ced3")
for case in annotations["cases"]:
    expected = case["case"] == "control"
    check("Annotation owner / required roles / saved style: " + case["case"], case["delivery_ok"] is expected and all(x["passed"] is expected for x in case["manufacturing"]) and bool(case["critique"]) is (not expected))

for name in ["precision-counterexamples-290ced3", "fine-geometry-counterexamples-290ced3"]:
    report = load(name)
    for case in report["cases"]:
        expected = case["case"] == "control"
        check(name + ": " + case["case"], case["delivery"]["ok"] is expected and all(x["passed"] is expected for x in case["read"]["manufacturing"]) and bool(case["read"]["critique"]) is (not expected))

parity = load("xrecord-parity-counterexample-290ced3")
check("Owned extension record loss rejected despite structural audit passing", parity["delivery"]["ok"] is False and parity["delivery"]["error"]["code"] == "DELIVERY_PARITY_FAILED" and parity["events"][0]["dxf_snapshot_equal_despite_record_loss"] is False and parity["events"][0]["structural_audit_errors"] == 0 and parity["read_exported_artifact"]["error"]["code"] == "INVALID_DOMAIN_RECORD")

prior = load("prior-replay-validation-290ced3")
check("All eleven relocated prior harnesses completed", len(prior["runs"]) == 11 and all(x["exit_code"] == 0 for x in prior["runs"]))
for item in prior["copied_same_byte_inputs"]:
    check("Prior Pro input is identical: " + item["copy"], (BASE / item["source"]).read_bytes() == (BASE / item["copy"]).read_bytes() and digest((BASE / item["copy"]).read_bytes()) == item["sha256"])

headless = load("headless-validation-290ced3")
correction = load("headless-context-correction-290ced3")
for report in [headless, correction]:
    for key in ["xml", "log"]:
        check("Retained test artifact hash: " + report[key], digest((BASE / report[key]).read_bytes()) == report[key + "_sha256"])
for test in headless["test_source_hashes"]:
    blob = git("show", SHA + ":" + test["path"])
    actual = (SNAPSHOT / test["path"]).read_bytes()
    check("Test fixed-source parity: " + test["path"], actual == blob and digest(blob) == test["git_content_sha256"])
testcases = ET.parse(BASE / headless["xml"]).getroot().findall(".//testcase")
failed = [t for t in testcases if t.find("failure") is not None or t.find("error") is not None]
retest = ET.parse(BASE / correction["xml"]).getroot().findall(".//testcase")
check("First headless result retained accurately", len(testcases) == 169 and len(failed) == 1 and failed[0].get("name") == "test_demo_icon" and headless["counts"] == {"passed": 168, "skipped": 0, "failed": 1, "error": 0} and headless["exit_code"] == 1)
check("Only path-sensitive case retested, unchanged code", len(retest) == 1 and retest[0].get("name") == "test_demo_icon" and retest[0].find("failure") is None and retest[0].find("error") is None and correction["exit_code"] == 0 and correction["first_run_was_all_green"] is False)

sealed = load("sealed-prior-integrity")
for file in sealed["files"]:
    raw = (BASE / file["path"]).read_bytes()
    check("Sealed prior unchanged: " + file["path"], digest(raw) == file["sha256"] and len(raw) == file["bytes"])

report = {
    "product_sha": SHA,
    "reviewer": "independent AI reviewer, requested/published by AgentCAD",
    "verified_at_utc": datetime.now(timezone.utc).isoformat(),
    "passed": all(c["passed"] for c in checks),
    "scope": "Post-run audit of independently replayed saved inputs and controls, actual SVG/PDF/viewer outputs, eleven earlier counterexample harnesses, fixed Git source/tests, and unchanged sealed prior files. No native applications launched. Not a final score.",
    "rendering_limit": "The transparency contract checked here is zero-alpha rejection and visible output for nonzero effective alpha. The inheritance example matches its opaque control. This does not certify identical intermediate opacity intensity across output formats.",
    "test_context_correction": "Initial run was 168 passed / 1 failed from test_demo_icon scanning 'viewer' in a temporary path named reviewer. The same unchanged case passed once with a neutral temporary root. Both results are preserved; no first-run all-green claim.",
    "source_file_count": len(sources),
    "source_files": sources,
    "checks": checks,
    "evidence_files": [{"path": k, **v} for k, v in index.items()],
    "final_score": None,
    "still_required": ["Complete current native regression", "Current CI/source/artifact parity", "Current unmodified v8 gate", "Current native showcase and independent visual review", "Current same-host correctness/performance observations"],
}
target = OUT / "independent-validation-290ced3.json"
target.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"passed": report["passed"], "source_files": len(sources), "checks": len(checks), "report": str(target)}))
