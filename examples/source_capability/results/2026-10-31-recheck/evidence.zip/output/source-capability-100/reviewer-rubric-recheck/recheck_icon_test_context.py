"""Keep the initial test failure; rerun its path-sensitive assertion in a neutral temp path."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

BASE = Path(r"D:\Projects\AgentCAD-output\source-capability-100")
OUT = BASE / "reviewer-rubric-recheck"
SHA = "290ced3033f85e1fc97611cf1c920d922524bc3a"
SNAPSHOT = OUT / "snapshot-290ced3"
env = dict(os.environ)
env["PYTHONPATH"] = str(SNAPSHOT / "src")
env["AGENTCAD_VIEWER"] = "0"
temp = BASE / "rubric-tests-290ced3-icon"
assert "viewer" not in str(temp)
xml = OUT / "headless-icon-context-290ced3.xml"
cmd = [sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", "--basetemp=" + str(temp), "--junitxml=" + str(xml), "tests/test_q_setup_gui.py::test_demo_icon"]
proc = subprocess.run(cmd, cwd=SNAPSHOT, env=env, capture_output=True, text=True, encoding="utf-8", errors="replace")
log = OUT / "headless-icon-context-290ced3.log"
log.write_text(proc.stdout + proc.stderr, encoding="utf-8")
test = SNAPSHOT / "tests/test_q_setup_gui.py"
original = OUT / "headless-290ced3.log"
report = {"product_sha": SHA, "initial_run": "reviewer-rubric-recheck/headless-validation-290ced3.json", "initial_result": {"passed": 168, "failed": 1}, "cause": "test_demo_icon asserts the substring 'viewer' is absent from the entire desktop file. The temporary home path contained 'reviewer-rubric-recheck', so the path triggered that test assertion even though the action was demo. This is a test-path false alarm, not an observed product mislaunch.", "correction": "Only rerun the failing case with a neutral temporary root without the substring 'viewer'; product and test source bytes unchanged. Preserve the initial failure verbatim.", "test_sha256": hashlib.sha256(test.read_bytes()).hexdigest(), "initial_log_sha256": hashlib.sha256(original.read_bytes()).hexdigest(), "command": cmd, "exit_code": proc.returncode, "xml": xml.relative_to(BASE).as_posix(), "xml_sha256": hashlib.sha256(xml.read_bytes()).hexdigest(), "log": log.relative_to(BASE).as_posix(), "log_sha256": hashlib.sha256(log.read_bytes()).hexdigest(), "first_run_was_all_green": False}
(OUT / "headless-context-correction-290ced3.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"exit_code": proc.returncode, "output": proc.stdout, "record": str(OUT / "headless-context-correction-290ced3.json")}, indent=2))
raise SystemExit(proc.returncode)
