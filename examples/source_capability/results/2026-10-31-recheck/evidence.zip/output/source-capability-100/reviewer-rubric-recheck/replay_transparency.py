"""Independent saved-byte opacity replay against one fixed source; no native CAD."""
from __future__ import annotations

import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile
import xml.etree.ElementTree as ET

BASE = Path(r"D:\Projects\AgentCAD-output\source-capability-100")
OUT = BASE / "reviewer-rubric-recheck"
REPO = Path(r"D:\Projects\AgentCAD")
INPUT = BASE / "reviewer-publication-final/code-behavior/transparency-probe/mechanical.dxf"
SHA = sys.argv[1]
SHORT = SHA[:7]
SNAPSHOT = OUT / ("snapshot-" + SHORT)


def sha256(data):
    return hashlib.sha256(data).hexdigest()


archive = subprocess.check_output(["git", "-C", str(REPO), "archive", "--format=tar", SHA, "src"])
SNAPSHOT.mkdir(parents=True, exist_ok=True)
with tarfile.open(fileobj=io.BytesIO(archive), mode="r:") as tar:
    for member in tar.getmembers():
        target = (SNAPSHOT / member.name).resolve()
        assert target.is_relative_to(SNAPSHOT.resolve())
        if member.isdir():
            target.mkdir(parents=True, exist_ok=True)
        elif member.isfile():
            target.parent.mkdir(parents=True, exist_ok=True)
            content = tar.extractfile(member).read()
            if target.exists():
                assert target.read_bytes() == content
            else:
                target.write_bytes(content)
        else:
            raise AssertionError(member.name)

sys.path.insert(0, str(SNAPSHOT / "src"))
import ezdxf
from ezdxf.addons.drawing import RenderContext
import agentcad.dimension_display as display_module
import agentcad.service as service_module
from agentcad.policy import Policy
from agentcad.service import Runtime
from agentcad.dimension_display import read_display

assert Path(service_module.__file__).resolve().is_relative_to(SNAPSHOT.resolve())
raw = INPUT.read_bytes()
source_paths = ["src/agentcad/dimension_display.py", "src/agentcad/engineering/mechanical_annotations.py", "src/agentcad/verification.py", "src/agentcad/validate/checks.py", "src/agentcad/validate/features.py", "src/agentcad/delivery.py", "src/agentcad/service.py"]
sources = []
for rel in source_paths:
    git_bytes = subprocess.check_output(["git", "-C", str(REPO), "show", f"{SHA}:{rel}"])
    actual = (SNAPSHOT / rel).read_bytes()
    assert actual.replace(b"\r\n", b"\n") == git_bytes.replace(b"\r\n", b"\n")
    sources.append({"path": rel, "git_sha256": sha256(git_bytes), "snapshot_sha256": sha256(actual)})

cases = []
for name, opacity in [("same_bytes_transparent", None), ("opaque_control", 0.0), ("partial_control", 0.5)]:
    root = OUT / ("transparency-" + SHORT) / name
    root.mkdir(parents=True, exist_ok=False)
    path = root / "mechanical.dxf"
    path.write_bytes(raw)
    doc = ezdxf.readfile(path)
    dim = doc.entitydb["E3"]
    text = doc.entitydb["FC"]
    assert text.dxftype() == "MTEXT" and text.text == "17"
    if opacity is not None:
        text.transparency = opacity
        doc.saveas(path)
    before_api_bytes = path.read_bytes()
    if name == "same_bytes_transparent":
        assert before_api_bytes == raw
    reopened = ezdxf.readfile(path)
    dim = reopened.entitydb["E3"]
    text = reopened.entitydb["FC"]
    props = RenderContext(reopened).resolve_all(text)
    rt = Runtime(Policy(root=root))
    engineering = rt.read_engineering("mechanical.dxf", "mechanical")
    verification = rt.verify_dimensions("mechanical.dxf", [{"id": "length", "handle": "E3", "value": 17}])
    delivery = rt.deliver_drawing("mechanical.dxf", "delivery", formats=["dxf", "svg"])
    svg_file = root / "delivery/mechanical.svg"
    svg_evidence = None
    if svg_file.exists():
        tree = ET.fromstring(svg_file.read_bytes())
        styles = {}
        for e in tree.iter():
            if e.tag.endswith("style") and e.text:
                for cls, body in re.findall(r"\.([^\s{]+)\s*\{([^}]*)\}", e.text):
                    styles[cls] = dict((a.strip(), b.strip()) for a, b in re.findall(r"([\w-]+)\s*:\s*([^;]+);", body))
        invisible_classes = [key for key, props in styles.items() if props.get("fill-opacity") == "0.000"]
        invisible_paths = [e.attrib for e in tree.iter() if e.tag.endswith("path") and e.attrib.get("class") in invisible_classes]
        svg_evidence = {"path": svg_file.relative_to(BASE).as_posix(), "sha256": sha256(svg_file.read_bytes()), "zero_alpha_style_classes": invisible_classes, "zero_alpha_path_count": len(invisible_paths), "zero_alpha_paths": invisible_paths}
    result = {
        "case": name, "input_file": path.relative_to(BASE).as_posix(), "input_sha256_before_api": sha256(before_api_bytes),
        "identical_original_bytes": before_api_bytes == raw, "dimension_handle": "E3", "text_handle": "FC",
        "actual_text": text.text, "transparency": text.transparency, "raw_transparency": text.dxf.transparency,
        "resolved_color": props.color, "read_display": read_display(dim), "read_engineering": engineering,
        "verify_dimensions": verification, "delivery": delivery, "svg": svg_evidence,
        "source_file_unchanged_by_read_and_delivery": path.read_bytes() == before_api_bytes,
    }
    (root / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    cases.append(result)

report = {"product_sha": SHA, "reviewer": "independent AI reviewer, requested/published by AgentCAD", "scope": "Saved-byte public Runtime replay with opaque and partial-transparent controls; no AutoCAD/FreeCAD/Claude launched.", "original_input": INPUT.relative_to(BASE).as_posix(), "original_input_sha256": sha256(raw), "imported_service": str(service_module.__file__), "python": sys.version, "ezdxf": ezdxf.__version__, "source_boundary": sources, "cases": cases}
output = OUT / ("transparency-replay-" + SHORT + ".json")
output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"report": str(output), "product_sha": SHA, "cases": [{"case": r["case"], "resolved_color": r["resolved_color"], "display_status": r["read_display"]["status"], "manufacturing_passed": r["read_engineering"]["manufacturing"][0]["passed"], "verify_accepted": r["verify_dimensions"]["accepted"], "delivery_ok": r["delivery"]["ok"], "svg_invisible_paths": None if r["svg"] is None else r["svg"]["zero_alpha_path_count"]} for r in cases]}, indent=2))
