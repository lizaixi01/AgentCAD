"""Retain exact Actions artifacts and verify their GitHub-provided digests."""
import hashlib,json,subprocess,time,zipfile
from pathlib import Path

root=Path('D:/Projects/AgentCAD-output/source-capability-100')
repo=Path('D:/Projects/AgentCAD-wt/source-capability-100')
sha='290ced3033f85e1fc97611cf1c920d922524bc3a'
short=sha[:7]
run_id=41114528669
def api(endpoint):
    return subprocess.check_output(['gh','api',endpoint],cwd=repo)
def write_json(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
run=json.loads(api(f'repos/lizaixi01/AgentCAD/actions/runs/{run_id}?refresh={int(time.time())}'))
assert run['head_sha']==sha and run['conclusion']=='success'
jobs=json.loads(api(f'repos/lizaixi01/AgentCAD/actions/runs/{run_id}/jobs?per_page=100'))
assert len(jobs['jobs'])==4 and all(j['conclusion']=='success' for j in jobs['jobs'])
artifacts=json.loads(api(f'repos/lizaixi01/AgentCAD/actions/runs/{run_id}/artifacts'))
assert len(artifacts['artifacts'])==4
write_json(root/f'ci-{short}.raw.json',run)
write_json(root/f'ci-jobs-{short}.json',jobs)
write_json(root/f'ci-artifacts-{short}.json',artifacts)
write_json(root/f'ci-{short}.json',{'run_id':run_id,'head_sha':sha,'status':run['status'],
    'conclusion':run['conclusion'],'html_url':run['html_url'],'jobs':jobs['jobs']})
raw=root/f'ci-raw-{short}';raw.mkdir(exist_ok=False)
extracted=root/f'ci-{short}';extracted.mkdir(exist_ok=False)
rows=[]
for artifact in artifacts['artifacts']:
    assert artifact['workflow_run']['head_sha']==sha
    data=api(f"repos/lizaixi01/AgentCAD/actions/artifacts/{artifact['id']}/zip")
    digest=hashlib.sha256(data).hexdigest()
    assert 'sha256:'+digest==artifact['digest'],artifact['name']
    path=raw/(artifact['name']+'.zip');path.write_bytes(data)
    destination=extracted/artifact['name'];destination.mkdir()
    count=0
    with zipfile.ZipFile(path) as archive:
        for info in archive.infolist():
            target=(destination/info.filename).resolve()
            assert target.is_relative_to(destination.resolve()),info.filename
            if info.is_dir():target.mkdir(parents=True,exist_ok=True);continue
            target.parent.mkdir(parents=True,exist_ok=True)
            content=archive.read(info.filename);target.write_bytes(content)
            assert target.read_bytes()==content
            count+=1
    rows.append({'artifact_id':artifact['id'],'name':artifact['name'],
        'zip':path.relative_to(root).as_posix(),'sha256':digest,
        'github_digest_matches':True,'extracted_files_match':count})
write_json(root/f'ci-artifact-integrity-{short}.json',{'run_id':run_id,'artifacts':rows,'all_passed':True})
print(json.dumps({'run_id':run_id,'artifacts':len(rows),'files':sum(r['extracted_files_match'] for r in rows),'all_digests_match':True}))
