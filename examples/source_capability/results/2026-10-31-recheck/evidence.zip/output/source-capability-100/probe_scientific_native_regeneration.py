from pathlib import Path
import json
import ezdxf
from agentcad.backends.autocad import _run
from agentcad.dimension_display import read_display
root=Path('D:/Projects/AgentCAD-output/source-capability-100/scientific-native-style-probe')
root.mkdir(exist_ok=False)
doc=ezdxf.new('R2010',setup=True,units=4);rows=[]
for index,(style,diameter,lfac,txt) in enumerate([
 ('Standard',.0065,1,2.5),('EZDXF',.0065,1,.0004),('EZDXF',6.5,.001,.25),
 ('Standard',6.5,.001,.25),('EZDXF',.0065,1,2.5),('Standard',.0065,1,.0004)]):
 center=(index*20,0)
 doc.modelspace().add_circle(center,diameter/2)
 o=doc.modelspace().add_diameter_dim(center=center,radius=diameter/2,angle=45,dimstyle=style,
     override={'dimlunit':1,'dimdec':2,'dimrnd':0,'dimlfac':lfac,'dimzin':0,'dimtxt':txt,'dimasz':txt})
 o.render();d=o.dimension;d.dxf.discard('geometry');d.dxf.discard('actual_measurement')
 rows.append({'handle':d.dxf.handle,'style':style,'diameter':diameter,'lfac':lfac,'text_height':txt,
              'style_attributes':doc.dimstyles.get(style).dxfattribs()})
doc.saveas(root/'definitions.dxf')
job,_=_run(root/'jobs',{'in.dxf':root/'definitions.dxf'},[
 '(command "_.DXFIN" "__JOBDIR__/in.dxf")','(command "_.REGENALL")',
 '(command "_.DXFOUT" "__JOBDIR__/out.dxf" "_V" "2018" "_Binary")'])
native=ezdxf.readfile(job/'out.dxf')
for row in rows:
 d=native.entitydb[row['handle']];row['display']=read_display(d)
 row['entities']=[e.dxftype() for e in native.blocks[d.dxf.geometry]]
 print({k:row[k] for k in ('style','diameter','lfac','text_height','display')})
(root/'result.json').write_text(json.dumps(rows,indent=2)+'\n','utf-8')
