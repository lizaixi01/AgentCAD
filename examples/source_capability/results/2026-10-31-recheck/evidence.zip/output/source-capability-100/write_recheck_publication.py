"""Render documentation from the independently sealed repaired-source result."""
import hashlib,json,re
from pathlib import Path
repo=Path('D:/Projects/AgentCAD-wt/source-capability-100')
out=Path('D:/Projects/AgentCAD-output/source-capability-100')
target=repo/'examples/source_capability/results/2026-10-31-recheck'
sha='290ced3033f85e1fc97611cf1c920d922524bc3a'
def read(p):return json.loads(p.read_text('utf-8-sig'))
assessment=read(target/'assessment.json');manifest=read(target/'manifest.json')
assert assessment['status']=='final_local_recheck'
agent,pro=assessment['products'];assert agent['product_sha']==sha
assert agent['name']=='AgentCAD' and 'Pro' in pro['name']
scores=f"AgentCAD {agent['total_score']}/100 · AutoCAD MCP Pro {pro['total_score']}/100"
verification=read(target/'verification-summary.json')
local=verification['lanes'][0]['counts'];assert local['failed']==0
performance=read(target/'performance.json')
assert performance['correctness_passed']
category_table='| Category | Weight | AgentCAD | AutoCAD MCP Pro |\n|---|---:|---:|---:|\n'
for a,p in zip(agent['categories'],pro['categories']):
    assert a['id']==p['id'] and a['weight']==p['weight']
    category_table+=f"| {a['name']} | {a['weight']} | {a['score']} | {p['score']} |\n"
category_table+=f"| **Total** | **100** | **{agent['total_score']}** | **{pro['total_score']}** |\n"
lanes='| Environment | Passed | Skipped |\n|---|---:|---:|\n'
for lane in verification['lanes']:
    name='Local Windows 3.11; AutoCAD 2027 / FreeCAD 1.1.4' if lane['path'].startswith('windows-native') else lane['path'].split('/')[1].removeprefix('evidence-')
    lanes+=f"| {name} | {lane['counts']['passed']} | {lane['counts']['skipped']} |\n"
perf_table='| Synthetic lines | Baseline `69c1425` | Candidate `290ced3` | Candidate / baseline |\n|---|---:|---:|---:|\n'
for row in performance['summary']:
    if row['metric']=='total_s':
        perf_table+=f"| {row['count']:,} | {row['median']['baseline']:.3f} s | {row['median']['candidate']:.3f} s | {row['candidate_over_baseline']:.3f} |\n"

report=f'''# Source-capability repair and reassessment, 2026-10-31

**{scores}**, under the unchanged [local rubric v1](source-capability-rubric.md).
A separate AI reviewer assessed both pinned sources; AgentCAD requested and
publishes the review. This is a local comparison of two products, not an official
upstream leaderboard or external certification. The original v8 execution score
is a separate result: **31/31**, tied with Pro.

{category_table}
The [original independent assessment](../examples/source_capability/results/2026-10-31-recheck/assessment.json)
records every item, source pin, evidence hash and limitation. A score of 100 means
the 20 bounded items met this rubric's highest evidence anchor. It is not a claim
that every CAD feature exists, that all inputs are correct, or that a drawing is
authorized for manufacture.

## Fixed sources and correction history

- AgentCAD: [`290ced3`](https://github.com/lizaixi01/AgentCAD/tree/{sha}).
- Pro and the unchanged original v8 evaluator: `58a05ddfc34a9832c626e82cd88ecdce8e16a62a`.
- Version-performance baseline: `69c1425a2dd7465f6f8c092033447b608554a8a3`.
- [Independent code re-review](https://github.com/lizaixi01/AgentCAD/pull/44#issuecomment-6531683436)
  passed the repaired source; the separately retained scoring review evaluates the
  complete evidence and is not substituted by that code verdict.

The earlier [98 / 96 review](source-capability-review.md) remains historical.
The first manufacturing follow-up at `6699109` assigned 100 / 93, but final
publication review demonstrated further false successes. Its assessment, archive
and measurements are [retained with a superseded notice](source-capability-manufacturing-review.md).
Those old passing runs do not establish the correctness of the repaired version.

The new review replays the actual failing files and normal controls, including:

- Fully transparent dimension text: generic verification, manufacturing readback
  and strict delivery now reject it. Entity, layer and block transparency are
  resolved with the parent dimension; explicit opaque child overrides remain valid.
- Renderer inheritance: SVG export, the viewer and PDF drawing share a dimension
  context, so layer-zero child text inherits the actual parent layer. Tests inspect
  actual rendered text paths, and the reviewer checked PDF content and pixels.
- Small scientific values: display precision follows physical magnitude and
  DIMDEC, without a decimal-format floor or a tolerance enlarged by forged text.
  Physical zero receives no fabricated nonzero magnitude; explicit DIMRND retains
  its declared role. Ordinary validation and strict delivery reject the retained
  bad-value cases; normal controls remain accepted.

Independent targeted validation retains its initial temporary-path test failure:
`test_demo_icon` matched the substring `viewer` in the review directory name.
The product and test were unchanged; rerunning that one case under a neutral
temporary root passed. Initial fixture mistakes, the interrupted `f1eb298` native
run and all original counterexamples are retained, not counted as successful runs.

Pro's local {pro['total_score']} is assessed at the same fixed `58a05dd` source under
the same rubric. The previously reproduced first-rendering precision false success
still caps C2; the local deductions remain F3 −1, C2 −3, T3 −1 and S1 −2. Pro's
separate **93/100 v1.6.0 self-review (2026-09-24)** uses different scoring detail.
Equal numbers do not make the two assessments interchangeable, and neither is
combined with unreviewed upstream projects to claim an official overall first.

## M14 and manufacturing annotations

M14's **24 mm counterbore diameter and 15 mm depth** are checked against GOST
12876-67 amendment 4, figure 4 / table 4. The through-hole diameter **15.5 mm**
uses the separate ISO 273 medium series. The output explicitly identifies these
mixed nominal references; full source tolerances, corner radii and chamfers are
not certified. [Reference audit and scan fingerprint](standard-tables.md#m14-interpretation-and-limits)
document the evidence without redistributing standards PDFs.

Mechanical drawings annotate supplied segment and overall lengths, distinct
outside/bore diameters, hole count and diameter, pitch circle, spacing and start
angle. Saved front/end/section geometry, native dimensions, actual visible text,
ownership and required annotation roles are checked together. Missing, altered
or fully hidden required annotations block strict delivery. Large annotation
records use owned XRECORDs; recorded 100-hole/native and precision-boundary cases
remain available through traced historical evidence.

Unspecified hole depth, machining process, surface finish and tolerances are not
invented. Callers still place views and notes. This is a useful checked drawing
contract, not universal automatic arrangement or complete manufacturing release.

## Verification and production evidence

All five lanes collected the same **{verification['test_count']} test IDs**, with
zero failures or errors. Local native testing ran in an isolated checkout with
AutoCAD 2027 and FreeCAD 1.1.4 enabled; its {local['skipped']} skips require unavailable
CadQuery. Skips never count as passes.

{lanes}
[Completed CI](https://github.com/lizaixi01/AgentCAD/actions/runs/41114528669) ·
[Per-test statuses and reasons](../examples/source_capability/results/2026-10-31-recheck/verification-summary.json).
Four original Actions ZIP digests match GitHub's recorded digests. CI's merge
checkout `884ac93` has exactly the same Git tree as `290ced3`; local raw source
hashes and CI LF blobs are checked separately. Local public-MCP and Linux 3.12 CI
runs both passed the untouched v8 matrix and its explicit all-31-must-pass gate.

The [fresh production report](../examples/source_capability/results/2026-10-31-recheck/showcase-report.json)
retains 40 Runtime calls, seven passed checks, five real DWG/readback/AUDIT workflows
and two A3 activation witnesses. Two distinct mechanical assemblies, architecture,
P&ID and a toleranced bore produce seven one-page PDFs, independently rendered
and [visually inspected](../examples/source_capability/results/2026-10-31-recheck/visual-review.md).
The native witness uses actual CTAB/REGENALL/DXFOUT; inactive viewport 0/0 and
active 2/2 records remain raw, without ID patching.

Mechanical, mechanical-variant and tolerance delivery quality is **94**, retaining
two undefined-VIEWPORTS-layer warnings each; architecture/P&ID quality is **100**.
These drawing-quality values are separate from source and v8 scores. PDFs use
AgentCAD's exporter, not Autodesk's PDF driver. The appearance checks establish
visible text and the tested inheritance behavior, not exact intermediate opacity
intensity across every output format. Native Windows results do not establish
AutoCAD/FreeCAD execution on Linux or macOS.

## Same-environment version comparison

One excluded warm-up and five measured observations per version/count ran in
alternating order, in fresh processes with the same interpreter and dependencies.
All **24 observations** independently passed endpoint, count, unit and DXF-audit
checks. Total create/export/reopen/check medians:

{perf_table}
These are narrow synthetic version measurements on this machine, not a speed
comparison with Pro or a general speed claim. [Raw observations and environment](../examples/source_capability/results/2026-10-31-recheck/performance.json)
preserve every sample, including the excluded warm-ups.

## Reproduce and inspect

[Reproduction commands](../examples/source_capability/README.md) apply after
checking out the fixed product source above. Use separate empty output directories
and run AutoCAD serially. The [new evidence directory](../examples/source_capability/results/2026-10-31-recheck/README.md)
provides the unchanged independent assessment, raw evidence, previews and full
SHA-256 manifest. Its two sealed companion archives supply explicitly indexed
historical evidence; no previous measurement is overwritten or relabeled.
'''
(repo/'docs/source-capability-recheck.md').write_text(report,'utf-8')

nav=f'''# Repaired source-capability assessment — 2026-10-31

**{scores}**, under the unchanged
[local rubric v1](../../../../docs/source-capability-rubric.md). Separate AI review
requested and published by AgentCAD; this is not an official upstream ranking.
Product: `{sha}`. Pro/evaluator:
`58a05ddfc34a9832c626e82cd88ecdce8e16a62a`.

| Record | Content |
|---|---|
| [Assessment](assessment.json) | Unchanged independent judgments for both products and indexed evidence |
| [Reviewer report](assessment-review.md) | Independent final verdict and limits |
| [Detailed report](../../../../docs/source-capability-recheck.md) | Six categories, repairs, validation and scope |
| [Regression summary](verification-summary.json) | {verification['test_count']} identical test IDs in five lanes; skips kept separate |
| [v8 report](v8-report.json) | Original public-MCP execution: 31/31 |
| [Performance](performance.json) | 24 correctness-checked observations, raw timings and environment |
| [Production](showcase-report.json) | Fresh synthetic examples, native DWG/AUDIT and actual A3 activation |
| [Visual review](visual-review.md) | Seven independently rendered and inspected PDFs |
| [Evidence ZIP](evidence.zip) | {len(manifest['members']):,} new retained files, including failures and counterexamples |
| [Manifest](manifest.json) | SHA-256 for archive, every member, standalone files and companion ZIPs |

Local regression: **{local['passed']} passed / {local['skipped']} skipped**;
[four completed CI lanes](https://github.com/lizaixi01/AgentCAD/actions/runs/41114528669).
Archive size: {manifest['archive']['bytes']:,} bytes. SHA-256:

```text
{manifest['archive']['sha256']}
```

Assessment SHA-256 (copied without edits from the independent reviewer):

```text
{hashlib.sha256((target/'assessment.json').read_bytes()).hexdigest()}
```

Extract this ZIP and both sealed companions into the same empty directory:
[2026-10-30](../2026-10-30/README.md) and
[superseded 6699109 review](../2026-10-31/README.md).
New and 6699109 paths start at `output/source-capability-100/`; older paths start
at `output/source-capability/`. The new ZIP does not overwrite either companion's
members. The assessment labels inherited evidence by archive and retains the
invalidated 6699109 conclusion as history, not as the current score.

Machine paths record provenance and are not portable installation requirements.
Hashes cover raw bytes: do not normalize line endings. The manifest excludes
itself and this navigational README. Original synthetic drawings only; standards
PDFs/page renders and Autodesk sample drawings are excluded.

See [reproduction instructions](../../README.md). A rubric score is not complete
CAD coverage or manufacturing certification; Pro's historical self-review 93 and
v8's 31-task score remain separate results.
'''
(target/'README.md').write_text(nav,'utf-8')

p=repo/'README.md';text=p.read_text('utf-8')
old=next(line for line in text.splitlines() if line.startswith('| [Source-capability review]'))
new=f"| [Source-capability review](docs/benchmarks.md#source-capability-comparison) | **{scores}** | Same frozen local rubric, separately reviewed at `290ced3` / `58a05dd`; M14 and manufacturing gaps closed. [Evidence and limits](docs/source-capability-recheck.md). Not an upstream ranking |"
text=text.replace(old,new)
old=next(line for line in text.splitlines() if line.startswith('| Tests |'))
new=f"| Tests | Pinned assessment regression at `290ced3`: **{local['passed']} passed, {local['skipped']} skipped** (CadQuery-dependent), with AutoCAD 2027 and FreeCAD 1.1.4 enabled. [Windows/Linux/macOS CI and retained evidence](docs/source-capability-recheck.md#verification-and-production-evidence) report optional-backend skips separately |"
text=text.replace(old,new);p.write_text(text,'utf-8')

p=repo/'docs/benchmarks.md';text=p.read_text('utf-8')
v8_marker='## AutoCAD MCP benchmark\n'
assert 'Latest repaired-source rerun' not in text
text=text.replace(v8_marker,v8_marker+'''
Latest repaired-source rerun, 2026-10-31: AgentCAD `290ced3` again passed **31/31**
locally and in Linux CI using the same unchanged upstream evaluator.
[New raw report](../examples/source_capability/results/2026-10-31-recheck/v8-report.json)
and [source/environment evidence](source-capability-recheck.md#verification-and-production-evidence)
are retained separately from the original comparison below.
''',1)
start=text.index('## Source-capability comparison\n')+len('## Source-capability comparison\n')
end=text.index('## BenchCAD 2 development samples',start)
historical=text[start:end].strip()
assert 'Repaired-source assessment, 2026-10-31' not in historical
latest=f'''
**Repaired-source assessment, 2026-10-31: {scores}.**
The same frozen rubric v1 applies to AgentCAD `290ced3` and Pro `58a05dd`.
M14's nominal dimensions have checked references; mechanical manufacturing
annotations and visible dimension verification have saved-output/native evidence.
The repaired source was independently reassessed after the earlier 6699109 score
was invalidated; its original record is retained below.

{category_table}
Verification: **{local['passed']} passed / {local['skipped']} skipped** with AutoCAD/FreeCAD,
four completed CI lanes, original v8 **31/31**, seven inspected PDFs and 24
correctness-checked performance observations. This is a local comparison of two
pinned sources, not an official overall ranking. Pro's historical self-review
93 remains separate. [Full review and limits](source-capability-recheck.md) ·
[Reproduce / inspect evidence](../examples/source_capability/results/2026-10-31-recheck/README.md).

<details>
<summary>Superseded 6699109 assessment and earlier historical records (preserved)</summary>

{historical}

</details>

'''
text=text[:start]+latest+text[end:];p.write_text(text,'utf-8')

p=repo/'examples/source_capability/README.md';text=p.read_text('utf-8')
marker='## Environment and regression evidence'
assert 'results/2026-10-31-recheck/README.md' not in text
text=text.replace('remain historical references; repair/recheck is pending.',
 'remain historical references. The repaired result is linked below.')
text=text.replace(marker,f'''The [repaired-source assessment](results/2026-10-31-recheck/README.md) records
**{scores}** at `290ced3` / `58a05dd`. Original failing
files and controls were independently replayed; full native regression is
**{local['passed']} passed / {local['skipped']} skipped**, with completed four-platform CI,
original v8 **31/31**, fresh production PDFs and same-environment timings.
See the [repair report](../../docs/source-capability-recheck.md) for score limits
and the two companion archives needed for explicitly inherited evidence.

{marker}''');p.write_text(text,'utf-8')

for name,link in [('docs/source-capability-manufacturing-review.md','source-capability-recheck.md'),
                 ('examples/source_capability/results/2026-10-31/README.md','../2026-10-31-recheck/README.md')]:
    p=repo/name;text=p.read_text('utf-8');split=text.index('\n\n')+2
    text=text[:split]+f'**Repaired-source result:** see the [290ced3 reassessment]({link}). The older record below remains superseded.\n\n'+text[split:]
    text=text.replace('A repaired-version reassessment is pending.','The repaired-version reassessment is linked above.')
    p.write_text(text,'utf-8')

adr=f'''

## 显示真实性修复后的重新定分（2026-10-31）

固定源码 `{sha}` 的独立复评为
**AgentCAD {agent['total_score']} / Pro {pro['total_score']}**，沿用原20项及六类权重，不修改锚点。
此前6699109的100结论被真实反例推翻，原JSON、ZIP和测量保持原字节；新的结论只引用
修复后的原件复放、可见输出及完整证据，不把旧通过记录重新标记为新版本。

本版真实AutoCAD/FreeCAD回归{local['passed']}通过、{local['skipped']}项CadQuery缺失跳过；
四组CI与本机收集相同{verification['test_count']}项、均零失败。CI合并检出与产品Git树完全相同。
本机和Linux CI的原始v8均31/31。制造样例含实际DWG/AUDIT与A3激活，七份PDF目视记录
和24次正确性验证的版本性能观测单列，不把结构验证当作所有格式的像素/透明强度一致。

应持续保持的合同：校验与实际绘图须共享DIMENSION继承；完全隐藏的必需文字不能放行；
科学计数精度必须取自物理量级，零值不能凭空继承0.01容差。数据、图样、计分三类质量
不能混用。100是声明范围内达到量表最高证据锚点，不能解释为制造认证或官方榜首。
完整记录见[新证据目录](../examples/source_capability/results/2026-10-31-recheck/README.md)。
'''
p=repo/'docs/decision-record.md';text=p.read_text('utf-8')
assert '## 显示真实性修复后的重新定分' not in text
p.write_text(text+adr,'utf-8')
body=f'''M14 counterbore data previously lacked a verified depth source, and mechanical
assemblies lacked complete saved manufacturing callouts. This change checks the
24 mm × 15 mm nominal against GOST 12876-67, keeps the separate ISO 273 through-hole
reference explicit, and generates/verifies supplied dimensions and hole patterns
across front/end/section views. Missing, altered or invisible required annotations
now block strict delivery.

Independent review also exposed display-value, transparency/inheritance and small
scientific-value false successes. The repaired implementation reads actual saved
text and shares dimension inheritance between validation, SVG, viewer and PDF
rendering. Original failures and the invalidated 6699109 assessment remain intact.
The new independent assessment is pinned to `{sha}` and uses the unchanged rubric:
**{scores}**. It is a local two-product review, not an upstream rank.

Validation at the measured source:

- Full Windows native regression: **{local['passed']} passed, {local['skipped']} CadQuery skips**;
  all five native/CI lanes collected the same **{verification['test_count']} IDs**, with zero failures.
- [Four-platform CI](https://github.com/lizaixi01/AgentCAD/actions/runs/41114528669),
  exact Git-tree/source parity, and retained original artifact digest checks.
- Original public-MCP v8: **31/31 locally and in Linux CI**.
- Five DWG/readback/AUDIT examples, two real A3 activation witnesses, seven inspected
  PDF pages and 24 correctness-checked version-performance observations.
- [Independent code re-review](https://github.com/lizaixi01/AgentCAD/pull/44#issuecomment-6531683436)
  passed the repaired source; independent final scoring and original evidence are
  in `examples/source_capability/results/2026-10-31-recheck/`.

README and the new report state the evaluated source, scoring limits, optional skips,
mixed standard references, retained drawing warnings and historical score correction.
Standards scans and Autodesk samples are not redistributed. The documentation/evidence
publication commit does not relabel measurements as if run at a later source revision.
'''
(out/'pr-recheck-body.txt').write_text(body,'utf-8')
print(scores)
