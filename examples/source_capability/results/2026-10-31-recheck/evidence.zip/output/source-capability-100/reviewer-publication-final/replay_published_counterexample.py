from pathlib import Path
import asyncio
import hashlib
import json
import os
import subprocess
import sys
import zipfile

sys.dont_write_bytecode = True
os.environ['AUTOCAD_MCP_BACKEND'] = 'ezdxf'
PRO = Path(r'D:\Projects\AgentCAD-output\autocad-benchmark-20261030\upstream')
ROOT = Path(r'D:\Projects\AgentCAD-output\source-capability-100\reviewer-publication-final\same-byte-replay')
ZIP = Path(r'D:\Projects\AgentCAD-wt\review-pr44-publication-final\examples\source_capability\results\2026-10-31\evidence.zip')
assert subprocess.check_output(['git','-C',str(PRO),'rev-parse','HEAD'],text=True).strip() == '58a05ddfc34a9832c626e82cd88ecdce8e16a62a'
assert not subprocess.check_output(['git','-C',str(PRO),'status','--porcelain'],text=True).strip()
sys.path.insert(0,str(PRO))
sys.path.insert(0,r'D:\Projects\AgentCAD-wt\review-pr44-publication-final\src')
import ezdxf
from backends.ezdxf_backend import EzdxfBackend
from engineering.verification.types import FeatureSelector, Requirement, RequirementSet
from engineering.verification.report import verify_requirements
from engineering.verification.artifact import verify_artifact
from agentcad.policy import Policy
from agentcad.service import Runtime

async def main():
    results=[]
    with zipfile.ZipFile(ZIP) as z:
        original = json.loads(z.read('output/source-capability-100/reviewer-rubric/pro-initial-precision-58a05dd.json'))
        for case in original['cases']:
            folder = ROOT / case['case']
            folder.mkdir(parents=True,exist_ok=True)
            path = folder / 'case.dxf'
            data = z.read('output/source-capability-100/reviewer-rubric/pro-initial-check-' + case['case'] + '/case.dxf')
            assert hashlib.sha256(data).hexdigest() == case['file_sha256']
            path.write_bytes(data)
            doc=ezdxf.readfile(path)
            dim=doc.entitydb[case['dimension_handle']]
            shown=[e.text if e.dxftype()=='MTEXT' else e.dxf.text for e in doc.blocks[dim.dxf.geometry] if e.dxftype() in {'MTEXT','TEXT'}]
            req=RequirementSet(requirements=(Requirement(id='hole',quantity='diameter',target=(('nominal',6.4),('unit','mm')),features=(FeatureSelector(kind='dimension',value=(('handle',dim.dxf.handle),)),),provenance='explicit',source=(('document','publication-review'),)),),units='mm')
            backend=EzdxfBackend()
            await backend.connect()
            try:
                await backend.drawing_open(str(path))
                pro=await verify_requirements(backend,req)
                saved=await verify_artifact(str(path),req,backend=backend)
            finally:
                await backend.disconnect()
            rt=Runtime(Policy(root=folder))
            agent=rt.verify_dimensions('case.dxf',[{'id':'hole','handle':dim.dxf.handle,'value':6.4}])
            results.append({'case':case['case'],'sha256':hashlib.sha256(data).hexdigest(),'shown':shown,'pro_memory':pro,'pro_saved':saved,'agentcad_current_head':agent})
    (ROOT/'result.json').write_text(json.dumps({'ezdxf':ezdxf.__version__,'scope':'same original archived DXF bytes; pinned Pro and current PR AgentCAD; no native apps','cases':results},indent=2,default=str),encoding='utf-8')
    print(json.dumps([{'case':r['case'],'shown':r['shown'],'pro_accepted':r['pro_saved']['accepted'],'agentcad_accepted':r['agentcad_current_head']['accepted']} for r in results],indent=2))

asyncio.run(main())
