from pathlib import Path
import json
import ezdxf
from agentcad.policy import Policy
from agentcad.service import Runtime
from agentcad.dimension_display import read_display
root=Path(r'D:/Projects/AgentCAD-output/source-capability-100/reviewer-publication-final/code-behavior/scientific-probe')
root.mkdir(parents=True,exist_ok=True)
doc=ezdxf.new('R2010',units=4,setup=True)
msp=doc.modelspace()
msp.add_circle((50,50),.0065/2)
dimov=msp.add_diameter_dim(center=(50,50),radius=.0065/2,angle=45,dimstyle='Standard',override={'dimdec':2,'dimrnd':0,'dimlfac':1,'dimzin':0,'dimlunit':1,'dimdsep':46})
dimov.render()
dim=dimov.dimension
text=doc.blocks[dim.dxf.geometry].query('MTEXT').first
text.text='%%c9.90E-03'
doc.saveas(root/'scientific.dxf')
rt=Runtime(Policy(root=root))
validation=rt.validate_drawing('scientific.dxf',detail=True)
delivery=rt.deliver_drawing('scientific.dxf','delivered',formats=['dxf'])
result={'measurement':dim.get_measurement(),'read_display':read_display(dim),'validation':validation,'delivery':delivery,'expected_scientific_resolution':.00001}
(root/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'measurement':result['measurement'],'read_display':result['read_display'],'validation_issues':validation['validation']['issues'],'validation_passed':validation['validation']['passed'],'delivery_ok':delivery['ok'],'error':delivery.get('error'),'result':str(root/'result.json')},ensure_ascii=True))

