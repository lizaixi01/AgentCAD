from pathlib import Path, PurePosixPath
from collections import Counter
from io import BytesIO
from statistics import median
import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile

REPO = Path(r'D:\Projects\AgentCAD-wt\review-pr44-publication-final')
OUT = Path(r'D:\Projects\AgentCAD-output\source-capability-100\reviewer-publication-final')
PUB = REPO / 'examples/source_capability/results/2026-10-31'
HEAD = '85ddde3b5e94307a70dc2897e08c0600190af10e'
PIN = '66991092973496b148da45b1f847ddb1a8b4999d'
BASE = 'output/source-capability-100/'
errors = []
checks = {}

def check(ok, label):
    if not ok:
        errors.append(label)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def jload(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])

def member_check(z, entry, prefix=''):
    key = prefix + entry['path']
    try:
        data = z.read(key)
    except KeyError:
        errors.append(f'missing member: {key}')
        return
    check(len(data) == entry['bytes'], f'member size: {key}')
    check(digest(data) == entry['sha256'], f'member hash: {key}')

manifest = jload(PUB / 'manifest.json')
assess = jload(PUB / 'assessment.json')
archive_data = (PUB / 'evidence.zip').read_bytes()
check(len(archive_data) == manifest['archive']['bytes'], 'archive size')
check(digest(archive_data) == manifest['archive']['sha256'], 'archive hash')
with zipfile.ZipFile(BytesIO(archive_data)) as z:
    names = z.namelist()
    check(len(names) == len(set(names)), 'duplicate archive member')
    check(set(names) == {e['path'] for e in manifest['members']}, 'manifest member coverage')
    check(all(n.startswith(BASE) and '..' not in PurePosixPath(n).parts and not PurePosixPath(n).is_absolute() for n in names), 'archive path safety')
    for entry in manifest['members']:
        member_check(z, entry)
    checks['archive'] = {'members': len(names), 'bytes': len(archive_data), 'sha256': digest(archive_data)}
    for entry in manifest['standalone']:
        data = (PUB / entry['path']).read_bytes()
        check(len(data) == entry['bytes'], 'standalone size: ' + entry['path'])
        check(digest(data) == entry['sha256'], 'standalone hash: ' + entry['path'])
    checks['standalone_files'] = len(manifest['standalone'])
    for entry in assess['evidence_index']:
        member_check(z, entry, BASE)
    checks['current_evidence_references'] = len(assess['evidence_index'])
    historical = assess['historical_local_review']
    old_pub = PUB.parent / '2026-10-30'
    old_data = (old_pub / 'evidence.zip').read_bytes()
    check(digest(old_data) == historical['evidence_zip_sha256'], 'historical archive hash')
    check(digest((old_pub / 'assessment.json').read_bytes()) == historical['assessment_sha256'], 'historical assessment hash')
    check(not git('diff', '--name-only', 'origin/main...HEAD', '--', 'examples/source_capability/results/2026-10-30', 'docs/source-capability-review.md', 'docs/source-capability-rubric.md').strip(), 'historical files changed')
    with zipfile.ZipFile(BytesIO(old_data)) as old:
        for entry in assess['inherited_evidence_index']:
            member_check(old, entry, historical['evidence_path_base'])
        for product in assess['products']:
            for item in product['items']:
                for path in item.get('evidence_paths', []):
                    check(BASE + path in names, 'item reference: ' + path)
                for entry in item.get('inherited_evidence', []):
                    check(historical['evidence_path_base'] + entry['path'] in old.namelist(), 'inherited item reference: ' + entry['path'])
    checks['historical_evidence_references'] = len(assess['inherited_evidence_index'])
    checks['historical_archive_sha256'] = digest(old_data)
    check(z.read(BASE + 'reviewer-rubric/assessment.json') == (PUB / 'assessment.json').read_bytes(), 'assessment author copy differs')
    check(digest(git('show', PIN + ':docs/source-capability-rubric.md')) == assess['method']['frozen_rubric_sha256'], 'frozen rubric hash')
    check(git('show', '25abc96b9e39abe4e52464d3f8f00eba589759e5:docs/source-capability-rubric.md') == git('show', PIN + ':docs/source-capability-rubric.md'), 'rubric differs from frozen commit')
    checks['scores'] = {}
    for product in assess['products']:
        items = {i['id']: i for i in product['items']}
        check(len(items) == 20, 'item count: ' + product['name'])
        check(all(type(i['score']) is int and 0 <= i['score'] <= 5 for i in items.values()), 'item score range')
        check(sum(i['score'] for i in items.values()) == product['total_score'], 'product arithmetic: ' + product['name'])
        for cat in product['categories']:
            check(sum(items[i]['score'] for i in cat['item_ids']) == cat['score'], 'category arithmetic: ' + product['name'] + ' ' + cat['id'])
            check(cat['weight'] == 5 * len(cat['item_ids']), 'category weight: ' + cat['id'])
        check(sum(c['score'] for c in product['categories']) == product['total_score'], 'category total: ' + product['name'])
        for item in items.values():
            check(item['deduction']['points'] == 5 - item['score'], 'deduction arithmetic: ' + product['name'] + ' ' + item['id'])
        checks['scores'][product['name']] = {i: v['score'] for i,v in items.items()}
    ver = jload(PUB / 'verification-summary.json')
    sets = []
    checks['test_lanes'] = []
    for lane in ver['lanes']:
        raw = z.read(BASE + lane['path'])
        check(digest(raw) == lane['sha256'], 'regression XML hash: ' + lane['path'])
        root = ET.fromstring(raw)
        cases = root.findall('.//testcase')
        counts = Counter('skipped' if c.find('skipped') is not None else 'failed' if c.find('failure') is not None else 'errors' if c.find('error') is not None else 'passed' for c in cases)
        ids = {(c.attrib.get('classname',''), c.attrib['name']) for c in cases}
        check(len(cases) == lane['total'] == 823, 'regression total: ' + lane['path'])
        check(all(counts[k] == n for k,n in lane['counts'].items()), 'regression counts: ' + lane['path'])
        check(counts['failed'] == counts['errors'] == 0, 'regression failure: ' + lane['path'])
        sets.append(ids)
        checks['test_lanes'].append({'path': lane['path'], 'counts':dict(counts), 'ids':len(ids)})
    check(all(s == sets[0] for s in sets), 'cross-platform test ID equality')
    api = json.loads(subprocess.check_output(['gh','api','repos/lizaixi01/AgentCAD/actions/runs/41101708770/artifacts']))
    (OUT / 'ci-artifacts-live.json').write_text(json.dumps(api,indent=2),encoding='utf-8')
    unpacked = 0
    for art in api['artifacts']:
        raw = z.read(BASE + 'ci-raw-6699109/' + art['name'] + '.zip')
        check(digest(raw) == art['digest'].split(':')[-1], 'GitHub artifact digest: ' + art['name'])
        check(len(raw) == art['size_in_bytes'], 'GitHub artifact size: ' + art['name'])
        with zipfile.ZipFile(BytesIO(raw)) as inner:
            for name in inner.namelist():
                if name.endswith('/'):
                    continue
                check(inner.read(name) == z.read(BASE + 'ci-6699109/' + art['name'] + '/' + name), 'CI extracted file mismatch: ' + name)
                unpacked += 1
    checks['ci_original_artifacts'] = {'count':len(api['artifacts']), 'unpacked_files':unpacked}
    checks['v8'] = []
    for path in ['v8-6699109/report.json','ci-6699109/evidence-ubuntu-latest-py3.12/v8/report.json']:
        report = json.loads(z.read(BASE + path))
        check(len(report['results']) == 31 and all(r['status'] == 'pass' for r in report['results']), 'v8 task status: ' + path)
        check(report['summary']['passed'] == 31 and report['summary']['score'] == 100, 'v8 summary: ' + path)
        check(report['git_sha'] == PIN or path.startswith('ci-'), 'v8 pin: ' + path)
        checks['v8'].append({'path':path,'summary':report['summary'],'git_sha':report['git_sha']})
    perf = jload(PUB / 'performance.json')
    check(all(m['passed'] for m in perf['measurements']), 'performance correctness')
    check(len(perf['measurements']) == 24, 'performance observation count')
    for count in [2000,10000]:
        for version in ['baseline','candidate']:
            group = [m for m in perf['measurements'] if m['count']==count and m['version']==version]
            check(sorted(m['repeat'] for m in group) == [-1,0,1,2,3,4], 'performance repeat coverage')
    for summary in perf['summary']:
        for version in ['baseline','candidate']:
            values = [m[summary['metric']] for m in perf['measurements'] if m['count']==summary['count'] and m['version']==version and m['repeat'] >= 0]
            check(median(values) == summary['median'][version], 'performance median mismatch')
        check(abs(summary['median']['candidate']/summary['median']['baseline']-summary['candidate_over_baseline']) < 1e-12,'performance ratio mismatch')
    checks['performance'] = {'observations':len(perf['measurements']),'summary':perf['summary']}
    # All public top-level reports must be byte-for-byte copies of retained measured reports.
    for public, member in [('performance.json','performance-6699109/report.json'),('showcase-report.json','showcase-6699109/report.json'),('v8-report.json','v8-6699109/report.json'),('verification-summary.json','verification-summary-6699109.json')]:
        check((PUB/public).read_bytes() == z.read(BASE+member), 'standalone original mismatch: '+public)
    checks['standalone_report_copies'] = 4

checks['head'] = git('rev-parse','HEAD').decode().strip()
checks['base'] = git('rev-parse','origin/main').decode().strip()
check(checks['head'] == HEAD,'review checkout head changed')
checks['errors'] = errors
(OUT / 'publication-integrity.json').write_text(json.dumps(checks,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps(checks,indent=2,ensure_ascii=False))
raise SystemExit(bool(errors))
