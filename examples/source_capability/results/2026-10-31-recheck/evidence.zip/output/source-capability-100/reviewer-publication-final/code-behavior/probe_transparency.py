from pathlib import Path
import json
import ezdxf
from ezdxf.addons.drawing import RenderContext
from agentcad.policy import Policy
from agentcad.service import Runtime
from agentcad.dimension_display import read_display
root=Path(r'D:/Projects/AgentCAD-output/source-capability-100/reviewer-publication-final/code-behavior/transparency-probe')
root.mkdir(parents=True,exist_ok=True)
rt=Runtime(Policy(root=root))
assert rt.create_drawing('mechanical.dxf', units='mm')['ok']
spec={'parts':[{'name':'shaft','at':[135,195], 'segments':[{'length':17,'d_outer':40}]}]}
created=rt.apply_operations('mechanical.dxf',[{'op':'draw_mechanical_assembly','spec':spec}])
assert created['ok'],created
before=rt.read_engineering('mechanical.dxf','mechanical')
assert before['critique']==[],before
row=next(a for a in before['manufacturing'][0]['annotations'] if a['kind']=='length.0')
doc=ezdxf.readfile(root/'mechanical.dxf')
dim=doc.entitydb[row['handle']]
text=doc.blocks[dim.dxf.geometry].query('MTEXT').first
text.transparency=1.0
props=RenderContext(doc).resolve_all(text)
doc.saveas(root/'mechanical.dxf')
readback=rt.read_engineering('mechanical.dxf','mechanical')
verified=rt.verify_dimensions('mechanical.dxf',[{'id':'length','handle':dim.dxf.handle,'value':17}])
delivery=rt.deliver_drawing('mechanical.dxf','delivered',formats=['dxf','svg'])
result={'mutation':{'dimension':dim.dxf.handle,'text':text.dxf.handle,'raw_text':text.text,'transparency':text.transparency,'raw_transparency':text.dxf.transparency,'resolved_color':props.color},'read_display':read_display(dim),'engineering':readback,'verify_dimensions':verified,'delivery':delivery}
(root/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'mutation':result['mutation'],'manufacturing_passed':readback['manufacturing'][0]['passed'],'critique':readback['critique'],'dimension_accepted':verified['accepted'],'delivery_ok':delivery['ok'],'delivery_error':delivery.get('error'),'result':str(root/'result.json')},ensure_ascii=False))
