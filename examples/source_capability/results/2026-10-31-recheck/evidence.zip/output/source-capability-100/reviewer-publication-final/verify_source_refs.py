from pathlib import Path
from urllib.parse import unquote
import hashlib
import json
import re
import subprocess
import zipfile

ROOT=Path(r'D:\Projects\AgentCAD-wt\review-pr44-publication-final')
PRO=Path(r'D:\Projects\AgentCAD-output\autocad-benchmark-20261030\upstream')
OUT=Path(r'D:\Projects\AgentCAD-output\source-capability-100\reviewer-publication-final')
PUB=ROOT/'examples/source_capability/results/2026-10-31'
PIN='66991092973496b148da45b1f847ddb1a8b4999d'
errors=[]
report={}
cache={}
def check(ok,label):
    if not ok:errors.append(label)
def gh(path):return hashlib.sha256(path).hexdigest()
def git(root,*args):return subprocess.check_output(['git','-C',str(root),*args])
def blob(root,sha,path):
    key=(str(root),sha,path)
    if key not in cache:cache[key]=git(root,'show',sha+':'+path)
    return cache[key]
assessment=json.loads((PUB/'assessment.json').read_bytes())
source_refs=0
for product in assessment['products']:
    root=ROOT if product['name']=='AgentCAD' else PRO
    for item in product['items']:
        for source in item['source']:
            data=blob(root,product['product_sha'],source['path'])
            check('/blob/'+product['product_sha']+'/' in source['url'],'source URL pin: '+source['url'])
            check(source['path'] in unquote(source['url']),'source URL path: '+source['url'])
            if 'line' in source:check(1<=source['line']<=len(data.splitlines()),'source line: '+source['url'])
            source_refs+=1
report['source_references']=source_refs
report['distinct_source_files']=len(cache)
with zipfile.ZipFile(PUB/'evidence.zip') as z:
    base='output/source-capability-100/'
    native=json.loads(z.read(base+'windows-native-6699109.environment.json'))
    parity=json.loads(z.read(base+'ci-source-parity-6699109.json'))
    local_v8=json.loads(z.read(base+'v8-6699109/report.json'))
    ci_v8=json.loads(z.read(base+'ci-6699109/evidence-ubuntu-latest-py3.12/v8/report.json'))
    for entry in parity['files']:
        data=blob(ROOT,PIN,entry['path'])
        check(gh(data)==entry['git_lf_sha256']==entry['ci_raw_sha256'],'source LF hash: '+entry['path'])
        check(entry['local_raw_sha256'] in {gh(data),gh(data.replace(b'\n',b'\r\n'))},'source local line endings: '+entry['path'])
        check(native['source_sha256'][entry['path']]==entry['local_raw_sha256'],'native provenance hash: '+entry['path'])
        check(local_v8['manifest']['source_sha256'][entry['path']]==entry['local_raw_sha256'],'v8 local provenance: '+entry['path'])
        check(ci_v8['manifest']['source_sha256'][entry['path']]==entry['ci_raw_sha256'],'v8 CI provenance: '+entry['path'])
    report['pinned_product_files_checked']=len(parity['files'])
    report['native_source_hashes']=len(native['source_sha256'])
    # Preserve the original published Pro failure and its control; check their DXF bytes.
    pro=json.loads(z.read(base+'reviewer-rubric/pro-initial-precision-58a05dd.json'))
    for case in pro['cases']:
        path=base+'reviewer-rubric/pro-initial-check-'+case['case']+'/case.dxf'
        check(gh(z.read(path))==case['file_sha256'],'Pro original input hash: '+case['case'])
    integration=json.loads((PUB/'integration-1041de9/pytest.environment.json').read_bytes())
    for path,sha in integration['source_sha256'].items():
        data=blob(ROOT,integration['product_commit'],path)
        check(sha in {gh(data),gh(data.replace(b'\n',b'\r\n'))},'integration source hash: '+path)
    report['integration_source_hashes']=len(integration['source_sha256'])

changed=git(ROOT,'diff','--name-only','origin/main...HEAD').decode().splitlines()
links=0
for rel in changed:
    if not rel.endswith('.md'):continue
    doc=ROOT/rel
    for target in re.findall(r'\]\(([^\s)]+)(?:\s+"[^"]*")?\)',doc.read_text(encoding='utf-8-sig')):
        if re.match(r'[a-z]+:',target):continue
        path,_,anchor=unquote(target).partition('#')
        dest=(doc.parent/path).resolve() if path else doc
        check(dest.exists(),'local link missing: '+rel+' -> '+target)
        if anchor and dest.suffix=='.md' and dest.exists():
            headings=re.findall(r'^#{1,6}\s+(.+?)\s*#*$',dest.read_text(encoding='utf-8-sig'),re.M)
            anchors={re.sub(r'[^\w\- ]','',h.strip().lower()).replace(' ','-') for h in headings}
            check(anchor in anchors,'local heading missing: '+rel+' -> '+target)
        links+=1
report['local_markdown_links_checked']=links
report['errors']=errors
(OUT/'source-reference-checks.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
raise SystemExit(bool(errors))
