import hashlib
import json
import math
from pathlib import Path
import ezdxf
from agentcad.dimension_display import read_display
from agentcad.ops.annotate import render_dimension
from agentcad.policy import Policy
from agentcad.service import Runtime

ROOT=Path(r'D:/Projects/AgentCAD-output/source-capability-100/reviewer-pr44-r10')
OLD=ROOT.parent/'reviewer-pr44-r9'
CASES=ROOT/'angular-replay';CASES.mkdir(exist_ok=True)
runtime=Runtime(Policy(root=CASES))
rows=[]

def inspect(name,expected,source=None,requirement=None):
    path=CASES/name;before=path.read_bytes()
    doc=ezdxf.readfile(path);dim=doc.modelspace().query('DIMENSION').first
    validation=runtime.validate_drawing(name,detail=True,requirements=requirement)
    delivery=runtime.deliver_drawing(name,path.stem+'-delivery',formats=['dxf'])
    display=read_display(dim)
    passed=validation['validation']['passed']==expected
    if expected:passed &= delivery['ok'] and display['value'] is not None
    else:passed &= delivery.get('error',{}).get('code')=='DELIVERY_REJECTED'
    rows.append({'case':name,'expected':expected,'passed':bool(passed),'display':display,
        'validation':validation,'delivery':delivery,'sha256':hashlib.sha256(before).hexdigest(),
        'source':str(source) if source else None,
        'unchanged':before==path.read_bytes(),'same_bytes_as_original':before==source.read_bytes() if source else None})

for units in [2,5]:
    source=OLD/'angular-precision'/f'linear-units-{units}-angular-cache.dxf'
    (CASES/source.name).write_bytes(source.read_bytes())
    inspect(source.name,False,source)

for source in sorted((OLD/'angles').glob('*.dxf')):
    (CASES/source.name).write_bytes(source.read_bytes())
    # All of these are actual saved normal controls from the 953 review, not rerendered files.
    expected=json.loads((OLD/'evidence.json').read_text(encoding='utf-8'))['angular_controls']
    value=next(c['expected'] for c in expected if c['case']==source.stem)
    inspect(source.name,True,source,[{'type':'dimension','kind':'angular','value':value,'tolerance':1e-4}])

for units in [2,4,5]:
    doc=ezdxf.new('R2010',setup=True,units=4);msp=doc.modelspace()
    p1=(50,0);p2=(25,25*math.sqrt(3));msp.add_line((0,0),p1);msp.add_line((0,0),p2)
    dim=msp.add_angular_dim_3p(base=(20,10),center=(0,0),p1=p1,p2=p2,dimstyle='Standard',
        override={'dimlunit':units,'dimadec':4,'dimdec':1,'dimrnd':0})
    render_dimension(dim)
    name=f'fresh-normal-linear-unit-{units}.dxf';doc.saveas(CASES/name)
    inspect(name,True,requirement=[{'type':'dimension','kind':'angular','value':60}])

unsupported=[]
template=ezdxf.readfile(CASES/'fresh-normal-linear-unit-2.dxf')
for units in [1,2,3,4]:
    # Existing saved decimal-looking cache cannot be trusted as decimal degrees after units change.
    doc=ezdxf.readfile(CASES/'fresh-normal-linear-unit-2.dxf');dim=doc.modelspace().query('DIMENSION').first
    override=dim.override();override.update({'dimaunit':units});override.commit()
    name=f'unsupported-angle-unit-{units}.dxf';doc.saveas(CASES/name)
    before=(CASES/name).read_bytes()
    response=runtime.verify_dimensions(name,[{'id':'angle','handle':dim.dxf.handle,'value':60}])
    validation=runtime.validate_drawing(name,detail=True,requirements=[{'type':'dimension','kind':'angular','value':60}])
    display=read_display(dim)
    unsupported.append({'case':name,'display':display,'verify':response,'validation':validation,
        'unchanged':before==(CASES/name).read_bytes(),
        'passed':display['value'] is None and display['status']=='unsupported_angular_format'
            and not response['accepted'] and validation['validation']['requirements'][0]['status']=='fail'})

(ROOT/'angular-replay.json').write_text(json.dumps({'head':'66991092973496b148da45b1f847ddb1a8b4999d',
    'cases':rows,'unsupported_units':unsupported},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'cases':len(rows),'passed':sum(r['passed'] for r in rows),'failures':[r['case'] for r in rows if not r['passed']],
    'same_byte_replays':sum(r['same_bytes_as_original'] is True for r in rows),
    'unsupported_units':len(unsupported),'unsupported_passed':sum(r['passed'] for r in unsupported)}))
