"""Check byte provenance and local links in the new publication bundle."""
import hashlib,json,re,sys,zipfile
from pathlib import Path
from urllib.parse import unquote

repo=Path('D:/Projects/AgentCAD-wt/source-capability-100')
out=Path('D:/Projects/AgentCAD-output/source-capability-100')
result=repo/'examples/source_capability/results/2026-10-31'
def read(p):return json.loads(p.read_text('utf-8-sig'))
def sha(b):return hashlib.sha256(b).hexdigest()
def check(data,row):
    assert len(data)==row['bytes'],row['path']
    assert sha(data)==row['sha256'],row['path']

m=read(result/'manifest.json');a=read(result/'assessment.json')
assert a['status']=='final_local_assessment'
assert (result/'assessment.json').read_bytes()==(out/'reviewer-rubric/assessment.json').read_bytes()
assert (result/'assessment-review.md').read_bytes()==(out/'reviewer-rubric/FINAL-REVIEW.md').read_bytes()
check((result/m['archive']['path']).read_bytes(),m['archive'])
paths=[r['path'] for r in m['members']]
assert len(paths)==len(set(paths))
with zipfile.ZipFile(result/'evidence.zip') as z:
    assert set(z.namelist())==set(paths)
    for row in m['members']:
        check(z.read(row['path']),row)
        assert '/standards/' not in row['path']
        assert 'windows-native-1041de9' not in row['path']
    index={r['path']:r for r in a['evidence_index']}
    for row in index.values():check(z.read(a['evidence_path_base']+row['path']),row)
    for product in a['products']:
        assert sum(c['score'] for c in product['categories'])==product['total_score']
        assert sum(i['score'] for i in product['items'])==product['total_score']
        assert len(product['items'])==20
        for item in product['items']:
            assert 0<=item['score']<=5
            for path in item['evidence_paths']:assert path in index,path
for row in m['standalone']:check((result/row['path']).read_bytes(),row)
old=result.parent/'2026-10-30'
assert sha((old/'evidence.zip').read_bytes())==m['prior_archive']['sha256']
assert sha((old/'assessment.json').read_bytes())==a['historical_local_review']['assessment_sha256']
with zipfile.ZipFile(old/'evidence.zip') as z:
    inherited={r['path']:r for r in a['inherited_evidence_index']}
    for row in inherited.values():check(z.read(a['historical_local_review']['evidence_path_base']+row['path']),row)
    for product in a['products']:
        for item in product['items']:
            for row in item['inherited_evidence']:assert row['path'] in inherited,row
links=[]
for name in ['README.md','docs/benchmarks.md','docs/source-capability-manufacturing-review.md',
             'examples/source_capability/README.md','examples/source_capability/results/2026-10-31/README.md']:
    file=repo/name
    for link in re.findall(r'\]\(([^)]+)\)',file.read_text('utf-8')):
        if re.match(r'[a-zA-Z]+:',link) or link.startswith('#'):continue
        path=unquote(link.split('#',1)[0]).strip('<>')
        if not path:continue
        target=(repo/path[1:] if path.startswith('/') else file.parent/path).resolve()
        assert target.exists(),(name,link)
        links.append((name,link))
summary={'passed':True,'product_commit':m['product_commit'],
         'scores':{p['name']:p['total_score'] for p in a['products']},
         'archive_members':len(paths),'indexed_evidence':len(index),'inherited_evidence':len(inherited),
         'standalone_files':len(m['standalone']),'local_links':len(links),
         'archive_sha256':m['archive']['sha256'],'historical_archive_unchanged':True}
(out/'publication-validation.json').write_text(json.dumps(summary,indent=2)+'\n','utf-8')
print(json.dumps(summary,indent=2))
