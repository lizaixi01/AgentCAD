import hashlib,json,sys,xml.etree.ElementTree as ET
from pathlib import Path
root=Path('D:/Projects/AgentCAD-output/source-capability-100')
sha=sys.argv[1];ci=root/('ci-'+sha[:7]);rows=[]
paths=[root/('windows-native-'+sha[:7]+'.xml'),*sorted(ci.rglob('pytest.xml'))]
assert len(paths)==5,paths
for p in paths:
 tree=ET.parse(p);cases={}
 for e in tree.iter('testcase'):
  key=e.get('classname','')+'::'+e.get('name','')
  assert key not in cases,key
  failures=[*e.findall('failure'),*e.findall('error')]
  skip=e.find('skipped')
  cases[key]={'status':'failed' if failures else 'skipped' if skip is not None else 'passed'}
  if skip is not None:cases[key]['reason']=skip.get('message') or skip.text
  if failures:cases[key]['details']=[x.get('message') or x.text for x in failures]
 counts={s:sum(v['status']==s for v in cases.values()) for s in ['passed','skipped','failed']}
 rows.append({'path':p.relative_to(root).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
              'counts':counts,'total':len(cases),'cases':cases})
ids=set(rows[0]['cases']);same=all(set(r['cases'])==ids for r in rows)
assert same and all(r['counts']['failed']==0 for r in rows)
data={'product_commit':sha,'all_test_ids_equal':same,'test_count':len(ids),'lanes':rows,'skips_are_passes':False}
out=root/('verification-summary-'+sha[:7]+'.json');out.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'test_count':len(ids),'lanes':[{k:r[k] for k in ['path','counts']} for r in rows]}))
