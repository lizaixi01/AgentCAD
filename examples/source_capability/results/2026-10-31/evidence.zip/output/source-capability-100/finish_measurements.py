"""Continue serial native/CPU measurements only after the pinned full run passes."""
import json,os,subprocess,sys,time
from pathlib import Path

repo=Path('D:/Projects/AgentCAD-wt/source-capability-100')
root=Path('D:/Projects/AgentCAD-output/source-capability-100')
sha='760a2c2e9f68908da8377cd3fb30727552b03730'
short=sha[:7]
state=root/('measurement-stages-'+short+'.json')
stages=[]
def record(stage,**details):
    stages.append({'stage':stage,'unix':time.time(),**details})
    state.write_text(json.dumps({'product_commit':sha,'stages':stages},indent=2)+'\n',encoding='utf-8')
    print(json.dumps(stages[-1]),flush=True)

record('waiting_for_full_regression')
deadline=time.monotonic()+2100
while True:
    if time.monotonic()>deadline:
        record('failed',reason='full regression timeout');sys.exit(2)
    data=json.loads((root/('windows-native-'+short+'.environment.json')).read_text(encoding='utf-8'))
    if 'exit_code' in data:
        if data['exit_code'] or not data['source_unchanged']:
            record('failed',reason='full regression did not pass',exit_code=data['exit_code']);sys.exit(3)
        break
    time.sleep(3)
record('full_regression_passed')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==sha
env={**os.environ,'PYTHONUTF8':'1','AGENTCAD_VIEWER':'0','AGENTCAD_ACCORECONSOLE':'D:/Apps/AutoCAD/AutoCAD 2027/accoreconsole.exe'}
commands=[
 ('showcase',[sys.executable,'examples/source_capability/showcase.py','--out',str(root/('showcase-'+short)),'--native']),
 ('performance',[sys.executable,'examples/source_capability/compare.py','--baseline','69c1425a2dd7465f6f8c092033447b608554a8a3',
   '--candidate',sha,'--out',str(root/('performance-'+short)),'--counts','2000','10000','--repeats','5']),
]
for stage,cmd in commands:
    record(stage+'_started',command=cmd)
    with (root/(stage+'-'+short+'.log')).open('w',encoding='utf-8') as log:
        result=subprocess.run(cmd,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
    record(stage+'_finished',exit_code=result.returncode)
    if result.returncode:sys.exit(result.returncode)
record('all_measurements_completed')
