import sys,json
from pathlib import Path
sys.path.insert(0,'D:/Projects/AgentCAD-wt/source-capability-100/src')
from agentcad.policy import Policy
from agentcad.service import Runtime
root=Path(sys.argv[1]);root.mkdir(exist_ok=False)
r=Runtime(Policy(root=root));rows=[]
def call(tool,**args):
 result=getattr(r,tool)(**args);rows.append({'tool':tool,'arguments':args,'result':result})
 (root/'report.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
 print(tool,result.get('ok'),result.get('error',result.get('critique')),flush=True)
 assert result['ok'],result
 return result
call('apply_operations',path='many.dxf',create={'units':'mm'},operations=[{'op':'draw_mechanical_assembly','spec':{'parts':[{'name':'index ring','at':[220,190],'segments':[{'length':10,'d_outer':80,'d_inner':20}],'views':['front','side'],'features':[{'kind':'hole_circle','pcd':60,'diameter':.5,'count':100}]}]}}])
call('read_engineering',path='many.dxf',kind='mechanical')
call('export_drawing',path='many.dxf',output='many.dwg',format='dwg')
call('import_drawing',source='many.dwg',output='reopened.dxf')
call('read_engineering',path='reopened.dxf',kind='mechanical')
