import hashlib,json,subprocess,sys
from pathlib import Path
from PIL import Image
from pypdf import PdfReader
root=Path('D:/Projects/AgentCAD-output/source-capability-100')
sha=sys.argv[1];short=sha[:7]
source=root/('showcase-'+short)
report=json.loads((source/'report.json').read_text(encoding='utf-8'))
assert report['source_commit']==sha and all(v=='passed' for v in report['checks'].values())
target=root/('previews-'+short);target.mkdir(exist_ok=False)
renderer=Path('C:/Users/HUAWEI/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/Library/bin/pdftoppm.exe')
pairs={
 'mechanical':'mechanical-delivery/mechanical.pdf',
 'mechanical-native':'mechanical-native.pdf',
 'mechanical-variant':'mechanical-variant-delivery/mechanical-variant.pdf',
 'mechanical-variant-native':'mechanical-variant-native.pdf',
 'architecture':'architecture-delivery/architecture.pdf',
 'pid':'pid-delivery/pid.pdf',
 'tolerance':'tolerance-delivery/tolerance.pdf',
}
rows=[]
for name,relative in pairs.items():
    pdf=source/relative;prefix=target/name;png=prefix.with_suffix('.png')
    cmd=[str(renderer),'-scale-to','2000','-png','-singlefile',str(pdf),str(prefix)]
    subprocess.run(cmd,check=True,capture_output=True)
    assert len(PdfReader(pdf).pages)==1
    rows.append({'pdf':pdf.relative_to(root).as_posix(),'preview':png.relative_to(root).as_posix(),
        'pdf_sha256':hashlib.sha256(pdf.read_bytes()).hexdigest(),'png_sha256':hashlib.sha256(png.read_bytes()).hexdigest(),
        'pixels':list(Image.open(png).size),'command':cmd})
version=subprocess.run([str(renderer),'-v'],capture_output=True,text=True)
data={'product_commit':sha,'renderer':str(renderer),'renderer_version':version.stderr.strip(),
      'previews':rows,'visual_review':'Rendering completed; human/agent visual inspection is a separate record.'}
(root/('preview-render-'+short+'.json')).write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
print('Rendered',len(rows),'one-page PDFs')
