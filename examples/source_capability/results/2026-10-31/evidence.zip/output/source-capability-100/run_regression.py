import hashlib,importlib.metadata,json,os,platform,subprocess,sys,time
from pathlib import Path
repo=Path('D:/Projects/AgentCAD-wt/source-capability-100')
out=Path('D:/Projects/AgentCAD-output/source-capability-100')
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
label='windows-native-'+commit[:7]
def hashes():
 return {p.relative_to(repo).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((repo/'src').rglob('*.py'))}
env={**os.environ,'PYTHONUTF8':'1','AGENTCAD_VIEWER':'0','AGENTCAD_FREECAD':'D:/Tools/FreeCAD/1.1.4/FreeCAD_1.1.4-Windows-x86_64-py311'}
cmd=[sys.executable,'-m','pytest','-p','no:cacheprovider','--basetemp='+str(out/('test-'+label)),'--junitxml='+str(out/(label+'.xml'))]
data={'product_commit':commit,'source_sha256':hashes(),'python':sys.version,'executable':sys.executable,'platform':platform.platform(),
      'dependencies':{n:importlib.metadata.version(n) for n in ['ezdxf','mcp','numpy','pypdf','pillow','pytest']},
      'uv_lock_sha256':hashlib.sha256((repo/'uv.lock').read_bytes()).hexdigest(),
      'configured_environment':{k:env[k] for k in ['PYTHONUTF8','AGENTCAD_VIEWER','AGENTCAD_FREECAD']},'invocation':cmd,'started_unix':time.time()}
record=out/(label+'.environment.json')
record.write_text(json.dumps(data,indent=2),encoding='utf-8')
with (out/(label+'.log')).open('w',encoding='utf-8') as log:
 p=subprocess.run(cmd,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
data.update(exit_code=p.returncode,finished_unix=time.time(),source_unchanged=hashes()==data['source_sha256'])
data['artifacts']={suffix:hashlib.sha256((out/(label+suffix)).read_bytes()).hexdigest() for suffix in ['.log','.xml'] if (out/(label+suffix)).exists()}
record.write_text(json.dumps(data,indent=2),encoding='utf-8')
print(json.dumps({k:data[k] for k in ['product_commit','exit_code','source_unchanged']}),flush=True)
sys.exit(p.returncode or int(not data['source_unchanged']))
