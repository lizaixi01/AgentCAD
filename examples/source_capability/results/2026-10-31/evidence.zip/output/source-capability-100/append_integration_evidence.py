"""Retain a later integration check without relabeling the scored product."""
import hashlib,json,shutil,subprocess,xml.etree.ElementTree as ET
from pathlib import Path

repo=Path('D:/Projects/AgentCAD-wt/source-capability-100')
out=Path('D:/Projects/AgentCAD-output/source-capability-100')
result=repo/'examples/source_capability/results/2026-10-31'
commit='1041de966bf39d01513a86341c0ad501987cd5f7'
score_commit='66991092973496b148da45b1f847ddb1a8b4999d'
label='windows-native-'+commit[:7]
env=json.loads((out/(label+'.environment.json')).read_text('utf-8'))
assert env['product_commit']==commit and env['exit_code']==0 and env['source_unchanged']
tests=list(ET.parse(out/(label+'.xml')).iter('testcase'))
counts={'collected':len(tests),'passed':0,'skipped':0,'failed':0,'errors':0}
for case in tests:
    status='skipped' if case.find('skipped') is not None else 'failed' if case.find('failure') is not None else 'errors' if case.find('error') is not None else 'passed'
    counts[status]+=1
assert counts['failed']==counts['errors']==0
dest=result/('integration-'+commit[:7]);dest.mkdir(exist_ok=False)
for suffix in ('.environment.json','.log','.xml'):
    shutil.copyfile(out/(label+suffix),dest/('pytest'+suffix))
changes=subprocess.check_output(['git','diff','--name-only',score_commit,commit,'--','src','tests'],cwd=repo,text=True).splitlines()
summary={'scope':'Later main-line integration regression, separate from the pinned source-capability assessment',
         'product_commit':commit,'score_commit':score_commit,'counts':counts,'source_unchanged':True,
         'changes_since_score_commit':changes,
         'configured_native_backends':['AutoCAD 2027','FreeCAD 1.1.4'],
         'skips':'CadQuery-dependent tests; not counted as passes'}
(dest/'summary.json').write_text(json.dumps(summary,indent=2)+'\n','utf-8')
for name in ('README.md','../../../../docs/source-capability-manufacturing-review.md'):
    path=result/name
    link='integration-'+commit[:7]+'/summary.json' if name=='README.md' else '../examples/source_capability/results/2026-10-31/integration-'+commit[:7]+'/summary.json'
    with path.open('a',encoding='utf-8') as stream:
        stream.write(f'\nLater [main-line integration regression]({link}) at `{commit[:7]}`: '
                     f'**{counts["passed"]} passed / {counts["skipped"]} skipped**, with no failures or errors. '
                     'This check includes subsequent installer/viewer changes and does not relabel the scored `6699109` measurement.\n')
manifest=json.loads((result/'manifest.json').read_text('utf-8'))
manifest['standalone'] += [{'path':p.relative_to(result).as_posix(),'bytes':p.stat().st_size,
                           'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(dest.iterdir())]
(result/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n','utf-8')
print(json.dumps(summary,indent=2))
