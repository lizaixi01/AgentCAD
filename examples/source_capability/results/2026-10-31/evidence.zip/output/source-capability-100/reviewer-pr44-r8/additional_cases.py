import hashlib
import json
from pathlib import Path

import ezdxf
from ezdxf.tools.text import MTextEditor
from agentcad.dimension_display import read_display
from agentcad.policy import Policy
from agentcad.service import Runtime

ROOT = Path(r'D:/Projects/AgentCAD-output/source-capability-100/reviewer-pr44-r8')
CASES = ROOT / 'additional-cases'
CASES.mkdir(exist_ok=True)
runtime = Runtime(Policy(root=CASES))

def run(name, diameter, raw, settings):
    doc = ezdxf.new('R2010', units=4, setup=True)
    doc.modelspace().add_circle((50,50), diameter/2)
    dim = doc.modelspace().add_diameter_dim(center=(50,50), radius=diameter/2, angle=45,
        dimstyle='Standard', override={'dimdec':1,'dimrnd':0,'dimlfac':1,'dimzin':8,
                                      'dimdsep':ord('.')})
    dim.render()
    d = dim.dimension
    overrides = d.override()
    overrides.update(settings)
    overrides.commit()
    doc.blocks[d.dxf.geometry].query('MTEXT').first.text = raw
    path = CASES / f'{name}.dxf'
    doc.saveas(path)
    before = path.read_bytes()
    fresh = ezdxf.readfile(path)
    data = {'case':name, 'diameter':diameter, 'raw_mtext':raw, 'overrides':settings,
        'evidence':read_display(fresh.entitydb[d.dxf.handle]),
        'verify':runtime.verify_dimensions(path.name,[{'id':'hole','handle':d.dxf.handle,'value':diameter}]),
        'validation':runtime.validate_drawing(path.name,detail=True,
            requirements=[{'type':'dimension','kind':'diameter','value':diameter}]),
        'delivery':runtime.deliver_drawing(path.name,name+'-delivery',formats=['dxf'])}
    data['sha256'] = hashlib.sha256(before).hexdigest()
    data['file_bytes_unchanged'] = before == path.read_bytes()
    return data

cases=[]
for stacking in ['/', '#']:
    fraction=str(MTextEditor().stack('1','2',stacking))
    tolerance=str(MTextEditor().stack('+0.1','-0.1','^'))
    raw='%%c6 {\\H0.7x;'+fraction+'} {\\H0.7x;'+tolerance+'}'
    settings={'dimlunit':5,'dimfrac':0 if stacking=='/' else 1,
              'dimtol':1,'dimtp':.1,'dimtm':.1,'dimtdec':1}
    for diameter,tag in [(6.5,'normal'),(6.0,'tampered')]:
        cases.append(run(f'fraction-{ord(stacking)}-tolerance-{tag}',diameter,raw,settings))
    raw_no_tolerance='%%c6 {\\H0.7x;'+fraction+'}'
    cases.append(run(f'fraction-{ord(stacking)}-no-tolerance',6.5,raw_no_tolerance,
                     {'dimlunit':5,'dimfrac':0 if stacking=='/' else 1,'dimtol':0}))

(ROOT/'additional-evidence.json').write_text(json.dumps({'head':'fd6d45f274897cf7e2541d4c70d88113dfb6cb22','cases':cases},ensure_ascii=False,indent=2),encoding='utf-8')
for c in cases:
    print(json.dumps({'case':c['case'],'raw':c['raw_mtext'],'evidence':c['evidence'],
        'accepted':c['verify'].get('accepted'),'delivery':c['delivery']['ok'],
        'unchanged':c['file_bytes_unchanged']},ensure_ascii=True))
