独立复审结论：**请求修改**。本轮精确审查 head `fd6d45f274897cf7e2541d4c70d88113dfb6cb22`，PR API 所报 base 为 `0b93e9bfb49037992102adfec1128c2e4deb6d17`。已复核当前 25 文件范围，重点检查 `760a2c2..fd6d45f` 新增的通用可见标注读取链路。前一 head 的通过结论不覆盖以下新增代码。

1. **[P2] 仅移除真正的末尾后缀，避免截断公称值内部的数字。** [dimension_display.py:99–102](https://github.com/lizaixi01/AgentCAD/blob/fd6d45f274897cf7e2541d4c70d88113dfb6cb22/src/agentcad/dimension_display.py#L99-L102) 对模板 `<> 4` 使用 `text.split(suffix, 1)`。正常直径 6.4、实际缓存文字 `%%c6.4 4` 被读成 6（在主值的小数位 `4` 处截断），导致正常图误拒。更严重的成对反例是直径 6，仅将已保存缓存改为相同的 `%%c6.4 4`：`verify_dimensions(value=6)` 接受，显式 dimension 要求 value=6 通过，strict DXF delivery 也成功。请按模板后缀的真实末尾边界移除，保留分隔语义，并覆盖正常与错误缓存两种情况。

2. **[P2] 不要将公称值的第一个叠排分数当作公差起点。** [dimension_display.py:81–85](https://github.com/lizaixi01/AgentCAD/blob/fd6d45f274897cf7e2541d4c70d88113dfb6cb22/src/agentcad/dimension_display.py#L81-L85) 在 `dimtol=1` 时直接截断首个 `\S`。合法 MTEXT `%%c6 {\H0.7x;\S1/2;} {\H0.7x;\S+0.1^ -0.1;}` 的主值是 6½，首个 stack 是主值中的分数，第二个才是上下公差。使用 `dimlunit=5, dimfrac=0, dimtol=1, dimtp=.1, dimtm=.1, dimtdec=1, dimdec=1, dimrnd=0` 时，当前读取却返回 6。直径 6.5 的正常对照误拒；直径 6 配此缓存被接受，显示要求与 strict DXF delivery 同样通过。叠排内容由现有 `ezdxf.tools.text.MTextEditor.stack` 生成（含 caret 后必需空格）；去掉公差后，水平分数对照正确读为 6.5。请按 MTEXT 结构区分主值分数和公差；不能确定时返回未验证，不能把截断值认证为主值。斜排 `\S1#2;` 的成对反例也具有同样错误认证。

独立验证结果：

- 在自己的工作树与虚拟环境运行 14 个相关非 CAD 测试文件：**231 passed，1 failed**。现有 `tests/test_h_operations.py::test_dimensions_measure_actual_geometry` 的旋转尺寸要求失败：物理测量 `45.98076211353316`，已存 MTEXT 为 `46`，保存后的 `dimdec=2/dimrnd=0`。本轮测试尚未达到仓库要求的全通过；作者已收到失败原件。这里按实际可见值检查是本轮有意改变的语义，应修正渲染与测试契约，不能恢复以推算值冒充可见值。
- 对历史“创建时 DIMDEC=0”的原始 DXF 进行同字节重放：两个 SHA256 均与原证据一致；正常对照显示 6.4 并接受，舍入反例现在显示 6 并拒绝，确认该原问题已修复。
- 本轮新增失败及正常对照均保留原始 DXF、公开 API 返回、SHA256 和读取前后字节不变检查：`D:/Projects/AgentCAD-output/source-capability-100/reviewer-pr44-r8/evidence.json`、`additional-evidence.json`；测试 XML 为同目录 `headless.xml`。历史证据未改写，产品文件未修改，未启动 AutoCAD/FreeCAD。

当前 fetch 到的 `origin/main` 已是 `9bc130519c501dfc8ebc0e68f3ec67622a46f0bc`，PR API 仍报告上述旧 base 且 mergeable=false。合入更新后的主分支并完成修复后，需要对新精确 head 复审及执行仓库要求的验证。
