import json
import sys
from pathlib import Path

repo = Path(r'D:/Projects/AgentCAD-wt/source-capability-100')
sys.path.insert(0, str(repo / 'src'))
sys.path.insert(0, str(repo / 'examples/source_capability'))
from showcase import MECHANICAL
from agentcad.policy import Policy
from agentcad.service import Runtime

out = Path(sys.argv[1]).absolute()
out.mkdir(parents=True, exist_ok=False)
rt = Runtime(Policy(root=out))
results = []
def call(name, **kwargs):
    r = getattr(rt, name)(**kwargs)
    results.append({'tool': name, 'arguments': kwargs, 'result': r})
    (out / 'development-report.json').write_text(json.dumps(results, indent=2), encoding='utf-8')
    print(name, r.get('ok'), r.get('critique', r.get('error')), flush=True)
    assert r['ok'], r
    return r
call('apply_operations', path='mechanical.dxf', create={'units':'mm'}, operations=[{'op':'draw_mechanical_assembly','spec':MECHANICAL}])
call('deliver_drawing', path='mechanical.dxf', output_dir='delivery', formats=['dxf','pdf','svg','json'])
call('export_drawing', path='mechanical.dxf', output='mechanical.dwg', format='dwg')
call('import_drawing', source='mechanical.dwg', output='native.dxf')
call('read_engineering', path='native.dxf', kind='mechanical')
call('export_drawing', path='native.dxf', output='native.pdf', format='pdf')
