"""Publish a completed independent assessment without rewriting earlier trials."""
import hashlib,json,sys
from pathlib import Path

repo=Path('D:/Projects/AgentCAD-wt/source-capability-100')
root=Path('D:/Projects/AgentCAD-output/source-capability-100')
sha=sys.argv[1];short=sha[:7]
result=repo/'examples/source_capability/results/2026-10-31'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
assessment=read(result/'assessment.json')
assert assessment['status']=='final_local_assessment'
a,p=assessment['products'];assert a['product_sha']==sha
verification=read(result/'verification-summary.json')
manifest=read(result/'manifest.json')
perf=read(result/'performance.json')
local=verification['lanes'][0]['counts']
assert local['failed']==0
ci=read(root/('ci-'+short+'.json'))
run_id=ci.get('databaseId',ci.get('id'))
assert run_id
ci_url=f'https://github.com/lizaixi01/AgentCAD/actions/runs/{run_id}'
assert (repo/'docs/benchmarks.md').read_text('utf-8').count('## BenchCAD 2 development samples')==1
assert (repo/'examples/source_capability/README.md').read_text('utf-8').count('## Environment and regression evidence')==1
rows=[]
for ac,pc in zip(a['categories'],p['categories']):
    assert ac['name']==pc['name']
    rows.append(f"| {ac['name']} | {ac.get('max_score',ac.get('weight'))} | {ac['score']} | {pc['score']} |")
table='\n'.join(['| Category | Weight | AgentCAD | AutoCAD MCP Pro |','|---|---:|---:|---:|',*rows,
    f"| **Total** | **100** | **{a['total_score']}** | **{p['total_score']}** |"])
lanes=[]
for row in verification['lanes']:
    label='Local Windows 3.11; AutoCAD 2027 / FreeCAD 1.1.4' if row is verification['lanes'][0] else row['path'].split('/')[1].replace('evidence-','')
    c=row['counts'];lanes.append(f"| {label} | {c['passed']} | {c['skipped']} |")
timings=[]
for row in perf['summary']:
    if row['metric']=='total_s':
        m=row['median'];timings.append(f"| {row['count']:,} | {m['baseline']:.3f} s | {m['candidate']:.3f} s | {row['candidate_over_baseline']:.3f} |")
report=f'''# Source-capability manufacturing follow-up, 2026-10-31

**AgentCAD {a['total_score']}/100; AutoCAD MCP Pro {p['total_score']}/100**, assessed by a separate AI reviewer
under the unchanged [local rubric v1](source-capability-rubric.md). AgentCAD requested
and publishes this assessment. It is a comparison of two pinned sources, not an
official upstream rank or external certification. The source score is separate
from the original v8 execution result of **31/31, 100/100**.

{table}

The [unaltered independent assessment](../examples/source_capability/results/2026-10-31/assessment.json)
contains 20 item judgments for each product, source references, counterexamples,
evidence hashes and limitations. A score of 100 means every bounded item met the
rubric's highest evidence anchor; it is not a percentage of all CAD features,
proof of universal correctness or permission to manufacture an unchecked drawing.

## Fixed versions and the change from 98 / 96

- AgentCAD: [`{short}`](https://github.com/lizaixi01/AgentCAD/tree/{sha}).
- Pro and the unmodified upstream evaluator: `58a05ddfc34a9832c626e82cd88ecdce8e16a62a`.
- Version-performance baseline: `69c1425a2dd7465f6f8c092033447b608554a8a3`.
- [Independent product review](https://github.com/lizaixi01/AgentCAD/pull/44#issuecomment-6529726990):
  278 related tests and original counterexample/control replays passed at this source.

The [2026-10-30 assessment](source-capability-review.md) remains unchanged at 98 / 96.
AgentCAD's former E1 and E2 gaps now have a checked M14 nominal row and saved,
readable manufacturing annotations. The new review also exposed a previously
missed correctness problem in **both** products: a 6.4 diameter initially rendered
with DIMDEC=0 prints 6, while verification claimed the displayed value was 6.4.
The same original DXF bytes and a valid precision control were replayed against
both pinned products. AgentCAD now reads the saved visible text and rejects this
case. At the unchanged Pro source it remains a false success, so the frozen rubric
caps C2 at 2 (previously 5). Its other deductions remain F3 −1, T3 −1 and S1 −2.

Pro's resulting local {p['total_score']} is a **new assessment**, even if numerically equal
to its separately published **93/100 v1.6.0 self-review, 2026-09-24**. The old 96
was not a newer Pro release being downgraded by performance; additional evidence
changed the local judgment. These scores cannot be combined with the eight other
upstream projects, which were not re-assessed, to claim an official overall first.

## M14 and mechanical production

M14 uses the washer-free hexagon-socket-head **24 mm counterbore diameter and
15 mm depth** in GOST 12876-67, amendment 4 (1983), figure 4 / table 4. New output
replaces the previously unverified 14.6 mm depth. The 15.5 mm through hole retains
its separate ISO 273 medium-series source. This is an explicitly mixed-reference
nominal drawing; the source's full tolerance, corner and chamfer requirements are
not certified. See the [source audit and scan fingerprint](standard-tables.md#m14-interpretation-and-limits).
Downloaded standards and Autodesk sample drawings are not redistributed.

Mechanical assemblies now annotate supplied segment/overall lengths, every distinct
outer/bore diameter, and hole quantity, diameter, pitch circle, spacing and starting
angle. Front/end/section readback checks actual source geometry, native DIMENSION
definitions, visible text, ownership and required roles. Missing or altered
annotations block strict delivery. Large records use owned XRECORD storage and
DXF parity follows their contents; a 100-hole case survives real DWG roundtrip/AUDIT.
Binary DXF backend intermediates retain double precision at large coordinates.

The generic dimension path also reads actual saved display values. Missing,
hidden or ambiguous text does not become a verified value by inference from
geometry. Numeric suffixes and nominal stacked fractions are distinguished from
deviation stacks. Zero DIMRND preserves DIMDEC precision after redraw. Two-line
angles use the arc-selected sector and ignore linear scale/format variables;
AutoCAD independently regenerated all four sector controls. Non-decimal angular
formats without a unit-aware reader remain explicitly unverified.

No unspecified hole depth, machining process, surface finish or tolerance is
invented. Caller-provided view positions still matter; this is not universal
automatic sheet arrangement or a complete manufacturing release.

## Verification and production evidence

All five lanes collected the same **{verification['test_count']} test IDs**, without failures or errors.
The eight local skips require unavailable CadQuery; skips never count as passes.

| Environment | Passed | Skipped |
|---|---:|---:|
{chr(10).join(lanes)}

The [completed CI run]({ci_url}) and
[verification summary](../examples/source_capability/results/2026-10-31/verification-summary.json)
retain per-test status and skip reasons. The archive matches local raw source
hashes and CI's LF sources to the pinned Git blobs, recording CI's merge checkout
separately. Both local public-MCP and Linux 3.12 CI runs pass the untouched original
v8 matrix and its additional all-31-must-pass gate.

The [production report](../examples/source_capability/results/2026-10-31/showcase-report.json)
uses two structurally different mechanical assemblies, architecture, P&ID and a
toleranced bore. Seven saved PDFs were separately rendered and visually inspected;
the report retains exact input specs, calls, outputs, native jobs and hashes.
Mechanical, mechanical-variant and tolerance delivery quality is **94**, with two
undefined-VIEWPORTS-layer warnings each; architecture/P&ID quality is **100**.
Those drawing-quality numbers are neither the source score nor the v8 score.

The native mechanical witness activates the actual A3 layout with CTAB/REGENALL;
raw inactive viewport id/status 0/0 is retained alongside the active 2/2 witness.
PDFs are produced by AgentCAD's exporter, not an Autodesk PDF driver. Visual
inspection and structural checks have separate scopes. Windows native evidence
does not establish native AutoCAD or FreeCAD behavior on Linux/macOS.

## Same-environment version comparison

One excluded warm-up and five measured trials per version/count ran in alternating
order in fresh processes. All **24 observations** independently verified endpoints,
entity counts, units and DXF audit. Total create/export/reopen/check medians:

| Synthetic lines | Baseline `69c1425` | Candidate `{short}` | Candidate / baseline |
|---|---:|---:|---:|
{chr(10).join(timings)}

[Raw timings](../examples/source_capability/results/2026-10-31/performance.json) measure
these line workflows within AgentCAD. They do not establish statistical significance,
general CAD speed or a speed advantage over Pro.

## Retained failures and reproduction

The [new evidence archive](../examples/source_capability/results/2026-10-31/README.md)
preserves earlier failures and superseded passes, including FreeCAD's lost final
progress event, XRECORD/native precision failures, altered geometry and annotation
counterexamples, the completed `760a2c2` run preceding discovery of the generic
verification defect, `fd6d45f`'s 755 passed / 8 skipped / 1 failed regression, and
`953c3f0`'s 30/31 v8 result with its intentionally interrupted native regression.
The final version fixes the underlying contracts; old test expectations and
original evaluator inputs/scoring were not weakened to erase failures.

The new main-line legacy-lock deletion race was separately reproduced and removed:
old non-cooperating markers require offline manual handling, while modern OS locks
and transaction crash recovery remain automatic. A Windows test-launcher exit race
is retained with actual writer PID evidence; the lock correctly remained held until
the writer itself exited.

Follow the [reproduction commands](../examples/source_capability/README.md) using
the exact product and evaluator commits above. Earlier published archives, figures
and measurements remain accessible unchanged. Later publication/main-line changes
are not silently relabeled as this pinned source measurement.
'''
(repo/'docs/source-capability-manufacturing-review.md').write_text(report,encoding='utf-8')

nav=f'''# Source-capability follow-up evidence — 2026-10-31

**AgentCAD {a['total_score']} / AutoCAD MCP Pro {p['total_score']}**, under the unchanged
[local rubric v1](../../../../docs/source-capability-rubric.md). This is an independent
AI review requested and published by AgentCAD, not official upstream ranking or
external certification. Pro's historical self-review 93 remains a separate result.

| Record | Content |
|---|---|
| [Assessment](assessment.json) | Original independent 40-item assessment, pins, deductions and evidence hashes |
| [Review report](../../../../docs/source-capability-manufacturing-review.md) | Six categories, repaired gaps, verification and limits |
| [Regression summary](verification-summary.json) | {verification['test_count']} identical test IDs in five lanes, with explicit skips |
| [v8 report](v8-report.json) | Original 31/31 public MCP execution |
| [Performance](performance.json) | 24 correctness-checked version observations |
| [Production](showcase-report.json) | Fresh synthetic drawings and real DWG/readback/AUDIT |
| [Visual review](visual-review.md) | Seven PDF previews and separate readability findings |
| [Independent reviewer report](assessment-review.md) | Final assessment verdict and scope |
| [Evidence ZIP](evidence.zip) | {len(manifest['members']):,} retained files, including failed development trials |
| [Manifest](manifest.json) | SHA-256 for ZIP, every member and standalone evidence |

Product: `{sha}`. Pro/evaluator: `58a05ddfc34a9832c626e82cd88ecdce8e16a62a`.
Local native regression: **{local['passed']} passed / {local['skipped']} skipped**.
[Completed CI]({ci_url}); each platform's optional skips are separately recorded.

ZIP size: {manifest['archive']['bytes']:,} bytes. SHA-256:

```text
{manifest['archive']['sha256']}
```

The independently authored assessment is copied unchanged. SHA-256:

```text
{hashlib.sha256((result/'assessment.json').read_bytes()).hexdigest()}
```

Extract this archive alongside the unchanged [2026-10-30 archive](../2026-10-30/README.md).
New paths start at `output/source-capability-100/`; inherited paths remain under
`output/source-capability/`. Original machine paths are provenance, not portable
installation requirements. Hashes cover raw bytes; do not normalize artifact line
endings. The manifest excludes itself and this navigational README.

All drawings are original synthetic examples. Standards PDFs/page renders and
Autodesk sample drawings are excluded. Mechanical/tolerance quality 94 retains
two VIEWPORTS-layer warnings; architecture/P&ID quality 100 has a different scope
from source and v8 scoring. This is not a manufacturing-release certification.
'''
(result/'README.md').write_text(nav,encoding='utf-8')

path=repo/'README.md';text=path.read_text(encoding='utf-8')
lines=text.splitlines()
found=0
for n,line in enumerate(lines):
 if line.startswith('| [Source-capability review]'):
  lines[n]=f'| [Source-capability review](docs/benchmarks.md#source-capability-comparison) | **{a["total_score"]}/100 vs {p["total_score"]}/100 for AutoCAD MCP Pro** | Pinned sources `{short}` / `58a05dd`, same frozen local rubric and separate AI reviewer; [full evidence](docs/source-capability-manufacturing-review.md). Not an upstream ranking |';found+=1
 if line.startswith('| Tests | Latest recorded regression') or line.startswith('| Tests | Pinned assessment regression'):
  lines[n]=f'| Tests | Pinned assessment regression at `{short}`: **{local["passed"]} passed, {local["skipped"]} skipped** (CadQuery-dependent), with AutoCAD 2027 and FreeCAD 1.1.4 enabled. [Windows/Linux/macOS CI and retained evidence](docs/source-capability-manufacturing-review.md#verification-and-production-evidence) report optional-backend skips separately |';found+=1
assert found==2
path.write_text('\n'.join(lines)+'\n',encoding='utf-8')

path=repo/'docs/benchmarks.md';text=path.read_text(encoding='utf-8')
marker='## Source-capability comparison\n'
assert text.count(marker)==1
new=f'''\n**Latest follow-up, 2026-10-31: AgentCAD {a['total_score']}/100 · AutoCAD MCP Pro {p['total_score']}/100.**
The same frozen rubric v1 applies to AgentCAD `{short}` and Pro `58a05dd`.
M14 nominal-source verification and manufacturing annotations now have independent
evidence. Further symmetric tests exposed a previously missed false success in
both products; AgentCAD fixes it, while Pro's same pinned source loses three C2
points. Its new local {p['total_score']} and historical self-review 93 are separate assessments.

{table}

Verification: **{local['passed']} passed / {local['skipped']} skipped** with native AutoCAD/FreeCAD,
four completed CI lanes, original v8 **31/31**, seven inspected PDF outputs and
24 correctness-checked version-performance observations. This is a local comparison
of these two pinned products, not an official overall leaderboard or manufacturing
certificate. [Review and limits](source-capability-manufacturing-review.md) ·
[Reproduce / inspect the archive](../examples/source_capability/results/2026-10-31/README.md).

<details>
<summary>Historical assessment and chart, 2026-10-30: 98 / 96 (unchanged)</summary>

'''
text=text.replace(marker,marker+new,1)
end='## BenchCAD 2 development samples'
assert text.count(end)==1
text=text.replace(end,'</details>\n\n'+end,1)
path.write_text(text,encoding='utf-8')

path=repo/'examples/source_capability/README.md';text=path.read_text(encoding='utf-8')
anchor='## Environment and regression evidence'
text=text.replace(anchor,f'''The [2026-10-31 follow-up](results/2026-10-31/README.md) records AgentCAD
**{a['total_score']}** / Pro **{p['total_score']}**, with new manufacturing and symmetric display-verification
evidence. Use its pinned product `{short}` and performance baseline `69c1425`;
the older result and commands' example baseline remain historical references.

'''+anchor,1)
text=text.replace('- Two rooms with a partition, doors, window, dimension chains and schedules;',
'''- A distinct fractional-length sleeve and eight-hole flange, two BOM rows,
  supplied dimensions and hole placement, plus a separately sourced M14 detail.
- Two rooms with a partition, doors, window, dimension chains and schedules;''',1)
path.write_text(text,encoding='utf-8')
print('Wrote follow-up report, result navigation, README row and benchmark history navigation')
