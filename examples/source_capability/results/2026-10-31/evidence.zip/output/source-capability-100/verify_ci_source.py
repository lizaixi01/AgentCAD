import hashlib,json,subprocess,sys
from pathlib import Path
repo=Path('D:/Projects/AgentCAD-wt/source-capability-100')
root=Path('D:/Projects/AgentCAD-output/source-capability-100')
sha=sys.argv[1];short=sha[:7]
local=root/('v8-'+short)/'report.json'
ci=next((root/('ci-'+short)).rglob('report.json'))
a=json.loads(local.read_text(encoding='utf-8'))['adapter_metadata']
b=json.loads(ci.read_text(encoding='utf-8'))['adapter_metadata']
assert a['product_sha']==sha and not a['product_dirty'] and not b['product_dirty']
assert a['source_sha256'].keys()==b['source_sha256'].keys()
rows=[]
for name in a['source_sha256']:
    data=(repo/name).read_bytes()
    git=subprocess.check_output(['git','show',sha+':'+name],cwd=repo)
    local_hash=hashlib.sha256(data).hexdigest()
    git_hash=hashlib.sha256(git).hexdigest()
    assert local_hash==a['source_sha256'][name],name
    assert data.replace(b'\r\n',b'\n')==git,name
    assert b['source_sha256'][name]==git_hash,name
    rows.append({'path':name,'local_raw_sha256':local_hash,'git_lf_sha256':git_hash,'ci_raw_sha256':b['source_sha256'][name]})
result={'product_commit':sha,'ci_merge_commit':b['product_sha'],
    'local_report':local.relative_to(root).as_posix(),'ci_report':ci.relative_to(root).as_posix(),
    'parity':'Local raw hashes match retained report; CRLF-normalized source equals fixed Git blobs; CI raw LF hashes equal those blobs.',
    'source_files':len(rows),'passed':True,'files':rows}
(root/('ci-source-parity-'+short+'.json')).write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print('Verified',len(rows),'source files against fixed Git blobs and both reports')
