import hashlib
import json
import math
from pathlib import Path

import ezdxf
from agentcad.dimension_display import read_display
from agentcad.model import measure_dimension
from agentcad.policy import Policy
from agentcad.service import Runtime

ROOT=Path(r'D:/Projects/AgentCAD-output/source-capability-100/reviewer-pr44-r9')
OLD=ROOT.parent
HEAD='953c3f07359970438aac2dee281288f76f5feffd'
out={'head':HEAD,'generic_replays':[],'mechanical_replays':[],'fresh_mechanical':[],'angular_controls':[]}

def save():
    (ROOT/'evidence.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')

case_dir=ROOT/'generic-replays';case_dir.mkdir(exist_ok=True)
rt=Runtime(Policy(root=case_dir))
for folder,evidence in [('cases','evidence.json'),('additional-cases','additional-evidence.json')]:
    old_dir=OLD/'reviewer-pr44-r8'
    old=json.loads((old_dir/evidence).read_text(encoding='utf-8'))
    for c in old['cases']:
        name=c['case']
        if name.startswith('fraction-tolerance-'):
            continue # replaced by canonical MTextEditor-generated cases below
        filename=name if name.endswith('.dxf') else name+'.dxf'
        source=old_dir/folder/filename
        raw=source.read_bytes();target=case_dir/filename;target.write_bytes(raw)
        doc=ezdxf.readfile(target);dim=doc.modelspace().query('DIMENSION').first
        value=c.get('diameter',6.4)
        actual=rt.verify_dimensions(filename,[{'id':'nominal','handle':dim.dxf.handle,'value':value}])
        validation=rt.validate_drawing(filename,detail=True,requirements=[{'type':'dimension','kind':'diameter','value':value}])
        delivery=rt.deliver_drawing(filename,target.stem+'-delivery',formats=['dxf'])
        should_accept=not any(s in filename for s in ['tampered','rounded_at_creation'])
        passed=actual.get('accepted')==should_accept
        passed &= (validation.get('validation',{}).get('requirements',[{}])[0].get('status')=='pass')==should_accept
        if 'tampered' in filename:
            passed &= not delivery['ok'] and delivery.get('error',{}).get('code')=='DELIVERY_REJECTED'
        row={'case':filename,'source':str(source),'expected_accept':should_accept,'passed':bool(passed),
             'sha256':hashlib.sha256(raw).hexdigest(),'old_sha256':c.get('sha256'),
             'unchanged':raw==target.read_bytes()==source.read_bytes(),'verify':actual,'validation':validation,'delivery':delivery}
        out['generic_replays'].append(row);save()

old7=OLD/'reviewer-pr44-r7'
old_cases=json.loads((old7/'evidence.json').read_text(encoding='utf-8'))['cases']
case_dir=ROOT/'mechanical-replays';case_dir.mkdir(exist_ok=True)
rt=Runtime(Policy(root=case_dir))
for c in old_cases:
    name=c['name'];source=old7/'cases'/(name+'.dxf');target=case_dir/source.name
    raw=source.read_bytes();target.write_bytes(raw)
    read=rt.read_engineering(target.name,'mechanical')
    delivery=rt.deliver_drawing(target.name,name+'-delivery',formats=['dxf'])
    should_accept=c['expected']=='accept'
    accepted=read['ok'] and not read.get('critique') and delivery['ok']
    passed=(accepted==should_accept)
    if not should_accept:
        passed &= bool(read.get('critique')) and delivery.get('error',{}).get('code')=='DELIVERY_REJECTED'
    out['mechanical_replays'].append({'case':name,'expected':c['expected'],'passed':bool(passed),
        'sha256':hashlib.sha256(raw).hexdigest(),'old_sha256':c['sha256'],
        'unchanged':raw==target.read_bytes()==source.read_bytes(),'read':read,'delivery':delivery});save()

case_dir=ROOT/'fresh-mechanical';case_dir.mkdir(exist_ok=True)
rt=Runtime(Policy(root=case_dir))
for c in old_cases:
    if c['expected']!='accept':continue
    name=c['name'];filename=name+'.dxf'
    made=rt.apply_operations(filename,[{'op':'draw_mechanical_assembly','spec':c['spec']}],create={'units':'mm'})
    read=rt.read_engineering(filename,'mechanical') if made['ok'] else None
    delivery=rt.deliver_drawing(filename,name+'-delivery',formats=['dxf']) if made['ok'] else None
    out['fresh_mechanical'].append({'case':name,'spec':c['spec'],'create':made,'read':read,'delivery':delivery,
        'passed':bool(made['ok'] and read['ok'] and not read.get('critique') and delivery['ok'])});save()

case_dir=ROOT/'angles';case_dir.mkdir(exist_ok=True)
rt=Runtime(Policy(root=case_dir))
alpha=math.degrees(math.atan2(3,4))
def polar(center,r,angle):
    rad=math.radians(angle)
    return (center[0]+r*math.cos(rad),center[1]+r*math.sin(rad))
for rotation in [0,143]:
    for rev1 in [False,True]:
        for rev2 in [False,True]:
            for sector in range(4):
                name=f'angle-{rotation}-{int(rev1)}{int(rev2)}-{sector}'
                doc=ezdxf.new('R2010',setup=True,units=4);msp=doc.modelspace();center=(125.5,-43.25)
                line1=(center,polar(center,50,rotation));line2=(center,polar(center,50,rotation+alpha))
                if rev1:line1=line1[::-1]
                if rev2:line2=line2[::-1]
                msp.add_line(*line1);msp.add_line(*line2)
                span=alpha if sector%2==0 else 180-alpha
                start=rotation+[0,alpha,180,180+alpha][sector]
                base=polar(center,30,start+span/2)
                dim=msp.add_angular_dim_2l(base=base,line1=line1,line2=line2,dimstyle='EZDXF',
                    override={'dimlfac':100,'dimadec':4,'dimrnd':0})
                dim.render();handle=dim.dimension.dxf.handle;filename=name+'.dxf';doc.saveas(case_dir/filename)
                changed=rt.apply_operations(filename,[{'op':'modify','target':handle,'set':{'text_height':3.5}}],strict=True)
                fresh=ezdxf.readfile(case_dir/filename);entity=fresh.entitydb[handle]
                display=read_display(entity);measured=measure_dimension(entity)
                verification=rt.verify_dimensions(filename,[{'id':'angle','handle':handle,'value':span,'tolerance':1e-4}])
                passed=changed['ok'] and measured is not None and abs(measured-span)<1e-8
                passed &= display['value'] is not None and abs(display['value']-round(span,4))<1e-8
                passed &= verification.get('accepted',False)
                out['angular_controls'].append({'case':name,'line1':line1,'line2':line2,'arc':base,'expected':span,
                    'passed':bool(passed),'changed':changed,'measured':measured,'display':display,'verify':verification});save()

for group, rows in out.items():
    if isinstance(rows,list):print(json.dumps({'group':group,'total':len(rows),'passed':sum(r['passed'] for r in rows),
        'failures':[r['case'] for r in rows if not r['passed']]},ensure_ascii=True))
