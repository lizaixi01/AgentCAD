import ctypes
import json
from pathlib import Path
import subprocess
import sys
import time

from agentcad.locking import drawing_lock
from agentcad.errors import AgentCADError

ROOT=Path(r'D:/Projects/AgentCAD-output/source-capability-100/reviewer-pr44-r9')
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.OpenProcess.argtypes=(ctypes.c_ulong,ctypes.c_int,ctypes.c_ulong)
kernel.OpenProcess.restype=ctypes.c_void_p
kernel.WaitForSingleObject.argtypes=(ctypes.c_void_p,ctypes.c_ulong)
kernel.WaitForSingleObject.restype=ctypes.c_ulong
kernel.CloseHandle.argtypes=(ctypes.c_void_p,)
code="""import os,sys
from pathlib import Path
from agentcad.locking import drawing_lock
with drawing_lock(Path(sys.argv[1])):
    print(os.getpid(),flush=True)
    sys.stdin.read()
"""
rows=[]
for index in range(12):
    directory=ROOT/f'lock-probe-{index}'
    child=subprocess.Popen([sys.executable,'-c',code,str(directory)],stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,creationflags=subprocess.CREATE_NO_WINDOW)
    actual=int(child.stdout.readline().strip())
    handle=kernel.OpenProcess(0x100000,False,actual)
    row={'launcher_pid':child.pid,'lock_holder_pid':actual,'attempts':[]}
    child.kill();child.wait(timeout=10);start=time.perf_counter()
    for attempt in range(80):
        alive_before=kernel.WaitForSingleObject(handle,0)==258
        try:
            with drawing_lock(directory):pass
            acquired=True
        except AgentCADError:
            acquired=False
        alive_after=kernel.WaitForSingleObject(handle,0)==258
        row['attempts'].append({'elapsed_ms':1000*(time.perf_counter()-start),
            'holder_alive_before':alive_before,'holder_alive_after':alive_after,'acquired':acquired})
        if acquired:break
        time.sleep(.001)
    child.communicate(timeout=10)
    kernel.CloseHandle(handle)
    rows.append(row)
(ROOT/'lock-probe.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
print(json.dumps({'runs':len(rows),'different_pid':sum(r['launcher_pid']!=r['lock_holder_pid'] for r in rows),
    'immediate_refusal':sum(not r['attempts'][0]['acquired'] for r in rows),
    'all_eventually_acquired':all(r['attempts'][-1]['acquired'] for r in rows),
    'refused_while_actual_alive':sum(any(not a['acquired'] and a['holder_alive_before'] for a in r['attempts']) for r in rows)}))
