import json
import math
from pathlib import Path
import ezdxf
from agentcad.dimension_display import read_display
from agentcad.policy import Policy
from agentcad.service import Runtime
from agentcad.ops.annotate import render_dimension

ROOT=Path(r'D:/Projects/AgentCAD-output/source-capability-100/reviewer-pr44-r9')
old=json.loads((ROOT/'evidence.json').read_text(encoding='utf-8'))
runtime=Runtime(Policy(root=ROOT/'angles'))
rows=[]
for c in old['angular_controls']:
    validation=runtime.validate_drawing(c['case']+'.dxf',detail=True,
        requirements=[{'type':'dimension','kind':'angular','value':c['expected'],'tolerance':1e-4}])
    rows.append({'case':c['case'],'validation':validation,
        'passed':bool(c['changed']['ok'] and abs(c['measured']-c['expected'])<1e-8
            and abs(c['display']['value']-round(c['expected'],4))<1e-8
            and validation['validation']['passed'])})
(ROOT/'angular-followup.json').write_text(json.dumps({'note':'Two-line angular binding was already unsupported; use the changed measured/displayed requirement contract.',
    'cases':rows},indent=2),encoding='utf-8')
case_dir=ROOT/'angular-precision';case_dir.mkdir(exist_ok=True)
runtime=Runtime(Policy(root=case_dir))
records=[]
for units in [2,5]:
    doc=ezdxf.new('R2010',setup=True,units=4);msp=doc.modelspace()
    p1=(50,0);p2=(25,25*math.sqrt(3));msp.add_line((0,0),p1);msp.add_line((0,0),p2)
    dim=msp.add_angular_dim_3p(base=(20,10),center=(0,0),p1=p1,p2=p2,dimstyle='Standard',
        override={'dimlunit':units,'dimadec':4,'dimdec':1,'dimrnd':0})
    render_dimension(dim)
    d=dim.dimension
    normal=read_display(d)
    block=doc.blocks[d.dxf.geometry];text=block.query('MTEXT').first
    text.text='60.0100%%d'
    file=f'linear-units-{units}-angular-cache.dxf';doc.saveas(case_dir/file)
    validation=runtime.validate_drawing(file,detail=True)
    delivery=runtime.deliver_drawing(file,f'delivery-{units}',formats=['dxf'])
    records.append({'units':units,'normal':normal,'changed':read_display(d),'validation':validation,'delivery':delivery})
(ROOT/'angular-precision.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'angular_controls_passed':sum(r['passed'] for r in rows),'total':len(rows)}))
for r in records:print(json.dumps({'units':r['units'],'normal':r['normal'],'changed':r['changed'],
    'passed':r['validation']['validation']['passed'],'delivery_ok':r['delivery']['ok']},ensure_ascii=True))
