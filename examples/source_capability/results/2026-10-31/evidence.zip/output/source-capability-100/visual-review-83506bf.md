# Visual review of product 83506bf

Reviewer: implementing Codex session, 2026-10-30. Independent score and code review
are separate records. Source: the unmodified `showcase-83506bf` report and saved
PDFs, rendered with Poppler `pdftoppm -scale-to 2000 -png -singlefile`. All seven
resulting previews were opened and visually inspected; this is not inferred from
the structural success flag. Previews are under `previews-83506bf`.

| PDF / preview | Observed result |
|---|---|
| mechanical-delivery/mechanical.pdf / mechanical.png | A3 1:1 frame, section, three-step profile and six-hole cap fit within the page. Lengths 18/24/13/55, OD 48/60/42/70 and bores 25 THRU are legible. The separate hole and pitch callouts read 6X diameter 6.6 and PCD diameter 52; equal spacing 60 degrees and first angle 30 degrees are visible. Balloons and five BOM rows remain legible. |
| mechanical-native.pdf / mechanical-native.png | Native DWG reopening and actual A3 activation retain those dimensions, fractional hole display, section hatching, BOM and paper annotation. No clipped callout or missing view observed. |
| mechanical-variant-delivery/mechanical-variant.pdf / mechanical-variant.png | Different three-step bush (17.5/23/11, overall 51.5; OD 42/60/34, bore 19) and eight-hole flange (OD 86, bore 18, 8X diameter 8.4 on PCD 64, first angle 22.5) are legible. M14 detail reads diameter 15.5, diameter 24 depth 15 with a mixed-reference note. Two BOM rows and the A3 frame fit. |
| mechanical-variant-native.pdf / mechanical-variant-native.png | Native reopening retains the fractional dimensions, all supplied hole-pattern annotations and M14 detail; no clipping or overlapping text observed. |
| architecture-delivery/architecture.pdf / architecture.png | Walls, hosted openings, room names/areas, schedules and dimension chains are legible. No new clipping or missing text observed. |
| pid-delivery/pid.pdf / pid.png | Equipment/instrument tags, both process-line identifiers and pneumatic signal connection are visible and distinct. |
| tolerance-delivery/tolerance.pdf / tolerance.png | Diameter 35 H7 with +0.025 / 0.000 stacked deviations and separate fit note are visible. |

Leader lines cross some geometry, as shown in the retained previews, but their
arrow targets and separate text remain identifiable. The nominal mechanical
dimensions supplied by these examples are annotated; unspecified hole depth,
finish, tolerances and manufacturing process are not invented. These are not shop
release drawings or full ISO/GOST conformity certificates. Sheet placement remains
caller-controlled; this inspection does not establish automatic layout for every
size or annotation density.

The native witness activates CTAB and regenerates the actual layout before PDF
export. It does not rewrite viewport IDs or geometry. The two mechanical native
PDFs are AgentCAD exports of that saved witness, not Autodesk PDF-driver output.
