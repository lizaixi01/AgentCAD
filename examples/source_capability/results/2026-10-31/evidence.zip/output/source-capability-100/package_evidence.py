"""Create a new, immutable publication bundle of original synthetic evidence."""
import hashlib,json,shutil,sys,zipfile
from pathlib import Path

root=Path('D:/Projects/AgentCAD-output/source-capability-100')
sha=sys.argv[2];short=sha[:7]
target=Path(sys.argv[1])

def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
assessment=read(root/'reviewer-rubric/assessment.json')
assert assessment['status']=='final_local_assessment'
assert assessment['products'][0]['product_sha']==sha
for product in assessment['products']:
 assert sum(c['score'] for c in product['categories'])==product['total_score']
 assert sum(i['score'] for i in product['items'])==product['total_score']
assert read(root/('verification-summary-'+short+'.json'))['product_commit']==sha
assert read(root/('ci-source-parity-'+short+'.json'))['passed']
assert read(root/('windows-native-'+short+'.environment.json'))['source_unchanged']
assert read(root/('windows-native-'+short+'.environment.json'))['exit_code']==0
assert read(root/('showcase-'+short)/'report.json')['source_commit']==sha
assert read(root/('performance-'+short)/'report.json')['snapshots']['candidate']['commit']==sha
assert read(root/('performance-'+short)/'report.json')['correctness_passed']
assert read(root/('v8-'+short)/'report.json')['adapter_metadata']['product_sha']==sha
target.mkdir(parents=True,exist_ok=False)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
mapping={
 'assessment.json':root/'reviewer-rubric/assessment.json',
 'assessment-review.md':root/'reviewer-rubric/FINAL-REVIEW.md',
 'verification-summary.json':root/('verification-summary-'+short+'.json'),
 'v8-report.json':root/('v8-'+short)/'report.json',
 'performance.json':root/('performance-'+short)/'report.json',
 'showcase-report.json':root/('showcase-'+short)/'report.json',
 'visual-review.md':root/('visual-review-'+short+'.md'),
}
for name,path in mapping.items():
 assert path.is_file(),path
 shutil.copyfile(path,target/name)
previews=root/('previews-'+short)
assert len(list(previews.glob('*.png')))==7
shutil.copytree(previews,target/'previews')

# All selected drawing trees are original Runtime/reviewer-generated examples.
# Never include the downloaded standards PDFs, their page images, repositories,
# installed environments, or the unrelated full regression fixture corpus.
trees=['dev-01','dev-02','boundary-01','showcase-83506bf','showcase-final',
       'showcase-'+short,'previews-83506bf','previews-'+short,'v8-final','v8-'+short,
       'ci-83506bf','ci-cd20aac','ci-'+short,'ci-raw-'+short,'native-precision','reviewer-pr44-r2','reviewer-pr44-r3',
       'precision-geometry-cd20aac','reviewer-pr44-r4-cd20aac',
       'reviewer-pr44-r5','binary-dxf-probe','source-dimensions-native','binary-native-tests',
       'all-view-native-tests','ci-392b7f2','v8-392b7f2',
       'ci-760a2c2','v8-760a2c2','showcase-760a2c2','performance-760a2c2',
       'v8-fd6d45f','v8-953c3f0','angular-native-probe','angular-native-rebuild',
       'reviewer-rubric','performance-'+short]
# The later main-line integration is a separate, still-running check. Do not
# archive partially written files or relabel its sources as the scored version.
integration_prefix='windows-native-1041de9'
files={p for p in root.iterdir() if p.is_file() and p.suffix in {'.json','.xml','.log','.py','.md','.txt'}
       and not p.name.startswith(integration_prefix)}
for name in trees:
 directory=root/name
 assert directory.is_dir(),directory
 for p in directory.rglob('*'):
  if not p.is_file():continue
  parts=p.relative_to(directory).parts
  if any(x.startswith('snapshot-') or x in {'__pycache__','.venv','.git','baseline','candidate'} for x in parts):continue
  files.add(p)
for name in ['standards-review.txt','evidence-manifest.json','implementation-review.txt','implementation-test-log.txt']:
 p=root/'reviewer-standards'/name
 assert p.is_file(),p
 files.add(p)
regression=root/('test-windows-native-'+short)
for d in regression.iterdir():
 if d.is_dir() and d.name.startswith(('test_large_manufacturing_record','test_eight_decimal_nominal','test_domain_and_tolerance_',
                                    'test_many_decimal_segments_and_fine','test_generic_precision_and_ang')):
  files.update(p for p in d.rglob('*') if p.is_file())
for p in (root/'reviewer-pr44-scratch').rglob('*'):
 if p.is_file() and p.suffix in {'.log','.xml'}:
  files.add(p)
# Later independent-review folders contain only generated synthetic cases.
for directory in [*root.glob('reviewer-pr44-r6*'),*root.glob('reviewer-pr44-r7*'),
                  *root.glob('reviewer-pr44-r8*'),*root.glob('reviewer-pr44-r9*'),
                  *root.glob('reviewer-pr44-r10*')]:
 files.update(p for p in directory.rglob('*') if p.is_file() and '__pycache__' not in p.parts)

members=[]
archive=target/'evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9,strict_timestamps=False) as z:
 for p in sorted(files):
  rel=p.relative_to(root).as_posix()
  assert not rel.startswith('standards/')
  name='output/source-capability-100/'+rel
  z.write(p,name)
  members.append({'path':name,'bytes':p.stat().st_size,'sha256':digest(p)})
manifest={'schema_version':1,'product_commit':sha,
 'archive':{'path':'evidence.zip','bytes':archive.stat().st_size,'sha256':digest(archive)},
 'members':members,
 'standalone':[{ 'path':p.relative_to(target).as_posix(),'bytes':p.stat().st_size,'sha256':digest(p)}
               for p in sorted(target.rglob('*')) if p.is_file() and p!=archive],
 'prior_archive':{'path':'../2026-10-30/evidence.zip','sha256':'1d2889cf18d66faf3c3a4633ef5e49ae0d5ed29a22aa3a7f1d4834683165de3e',
                  'scope':'Unchanged-boundary historical evidence; extract alongside this ZIP to retain output/source-capability paths.'},
 'exclusions':['Downloaded standards and page renders','Source snapshots and environments','Unrelated full-test fixtures',
               'Later 1041de9 main-line integration run; scored evidence remains pinned to 6699109'],
 'manifest_excludes_itself_and_navigation_readme':True}
(target/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'archive':manifest['archive'],'members':len(members),'standalone':len(manifest['standalone'])}))
