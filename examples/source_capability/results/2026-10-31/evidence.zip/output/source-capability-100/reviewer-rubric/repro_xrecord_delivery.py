"""New entity-owned XRECORD delivery parity boundary, fixed 83506bf source."""
import hashlib, json, pathlib, sys
OUT=pathlib.Path(r"D:\Projects\AgentCAD-output\source-capability-100\reviewer-rubric")
SNAPSHOT=OUT/"snapshot-83506bf"
sys.path.insert(0,str(SNAPSHOT/"src"))
import agentcad, ezdxf
from agentcad.policy import Policy
from agentcad.service import Runtime
from agentcad.delivery import dxf_snapshot
assert pathlib.Path(agentcad.__file__).resolve().is_relative_to(SNAPSHOT.resolve())
WORK=OUT/"case-83506bf-xrecord-delivery"
WORK.mkdir(exist_ok=True)
events=[]
class CorruptingRuntime(Runtime):
    def export_drawing(self,path,output,format=None,**kwargs):
        result=super().export_drawing(path,output,format,**kwargs)
        if result.get("ok") and format=="dxf":
            target=self.policy.resolve(output)
            actual=ezdxf.readfile(target)
            target_entity=next(e for e in actual.modelspace()
                if e.has_xdata("AGENTCAD_MECH") and e.has_extension_dict
                and e.get_extension_dict().get("AGENTCAD_MECH") is not None)
            before=dxf_snapshot(actual)
            xr=target_entity.get_extension_dict().get("AGENTCAD_MECH")
            xr.reset([(1,"INVALID JSON")])
            actual.saveas(target)
            after=ezdxf.readfile(target)
            events.append({"artifact":str(target.relative_to(WORK)),
                "entity":target_entity.dxf.handle,
                "dxf_snapshot_equal_despite_record_loss":before==dxf_snapshot(after),
                "structural_audit_errors":len(after.audit().errors)})
        return result
rt=CorruptingRuntime(Policy(root=WORK))
def ok(r):
    assert r["ok"],r
    return r
ok(rt.create_drawing("case.dxf",units="mm"))
spec={"parts":[{"name":"index ring","at":[220,190],"views":["front","side"],
    "segments":[{"length":10,"d_outer":80,"d_inner":20}],
    "features":[{"kind":"hole_circle","pcd":60,"diameter":.5,"count":100}]}]}
ok(rt.apply_operations("case.dxf",[{"op":"draw_mechanical_assembly","spec":spec}]))
before=ok(rt.read_engineering("case.dxf","mechanical"))
assert not before["critique"]
delivered=rt.deliver_drawing("case.dxf","delivery",formats=["dxf"],strict=True)
after=rt.read_engineering("delivery/case.dxf","mechanical")
report={"product_sha":"83506bfa8a7ccc4c7eaf9da84cc8004986af02e3",
    "scope":"Headless fault injection after export, preserving entity/extension handles; no native CAD launched.",
    "events":events,"delivery":delivered,"read_exported_artifact":after,
    "source_sha256":hashlib.sha256((WORK/"case.dxf").read_bytes()).hexdigest()}
(OUT/"xrecord-parity-counterexample-83506bf.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"product_sha":report["product_sha"],"events":events,"delivery_ok":delivered.get("ok"),
    "artifact_verification":[x["verification"] for x in delivered.get("artifacts",[])],
    "read_artifact_ok":after.get("ok"),"read_artifact_error":after.get("error")}))

