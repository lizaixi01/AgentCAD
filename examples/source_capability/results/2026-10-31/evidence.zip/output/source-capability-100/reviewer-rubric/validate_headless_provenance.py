"""Check reviewer imports and fixed snapshots; no CAD process or product writes."""
import argparse,hashlib,io,json,pathlib,subprocess,tarfile

p=argparse.ArgumentParser()
p.add_argument("sha")
p.add_argument("--output",required=True)
args=p.parse_args()
repo=pathlib.Path(r"D:\Projects\AgentCAD")
out=pathlib.Path(r"D:\Projects\AgentCAD-output\source-capability-100\reviewer-rubric")
snapshot=out/("snapshot-"+args.sha[:7])
archive=subprocess.check_output(["git","-C",str(repo),"archive",args.sha,"src"])
rows=[]
with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
    for member in tar.getmembers():
        if not member.isfile():
            continue
        expected=tar.extractfile(member).read()
        actual=(snapshot/member.name).read_bytes()
        blob=subprocess.check_output(["git","-C",str(repo),"show",args.sha+":"+member.name])
        rows.append({"path":member.name,"sha256":hashlib.sha256(actual).hexdigest(),
            "matches_materialized_git_archive":actual==expected,
            "git_blob_content_sha256":hashlib.sha256(blob).hexdigest(),
            "matches_fixed_git":actual==blob or actual.replace(b"\r\n",b"\n")==blob.replace(b"\r\n",b"\n")})
assert rows and all(r["matches_fixed_git"] for r in rows)
rubric=subprocess.check_output(["git","-C",str(repo),"show",args.sha+":docs/source-capability-rubric.md"])
rubric_hash=hashlib.sha256(rubric).hexdigest()
assert rubric_hash=="be562004ba7f25c0d131cdf690c9dc4844cd0df9dc3ede467ae2308420d1d52e"
reports=[]
for path in sorted(out.glob("*"+args.sha[:7]+".json")):
    if path.name.startswith(("boundary-","independent-headless-")):
        continue
    obj=json.loads(path.read_text(encoding="utf-8"))
    if obj.get("product_sha")!=args.sha:
        continue
    imported=obj.get("imported_from")
    if imported is not None:
        assert pathlib.Path(imported).resolve().is_relative_to(snapshot.resolve()),imported
    reports.append({"path":path.name,"sha256":hashlib.sha256(path.read_bytes()).hexdigest(),"imported_from":imported,"product_sha":obj["product_sha"]})
result={"product_sha":args.sha,"scope":"Independent headless source provenance only; does not assert native execution or final score.",
    "frozen_rubric_sha256":rubric_hash,"frozen_rubric_sha256_basis":"git show LF blob content; not CRLF worktree bytes",
    "snapshot_line_endings":"Windows git archive materializes CRLF for configured paths. Compare archive bytes exactly and compare repository blobs exactly or after CRLF-only normalization; the unchanged logo.svg blob itself contains CRLF.",
    "snapshot_files":rows,"reports":reports,"passed":True}
(out/args.output).write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"product_sha":args.sha,"snapshot_files":len(rows),"reports":len(reports),"passed":True}))
