"""Apply the identical saved Pro control/rounded DIMENSION bytes to AgentCAD's generic verifier."""
import argparse,hashlib,json,pathlib,sys
parser=argparse.ArgumentParser();parser.add_argument("sha");args=parser.parse_args()
OUT=pathlib.Path(r"D:\Projects\AgentCAD-output\source-capability-100\reviewer-rubric")
sys.path.insert(0,str(OUT/("snapshot-"+args.sha[:7])/"src"))
import agentcad,ezdxf
from agentcad.policy import Policy
from agentcad.service import Runtime
from agentcad.verification import verify_dimensions
results=[]
for case in ("control","rounded_at_creation"):
    source=OUT/("pro-initial-check-"+case)/"case.dxf"
    root=OUT/("agent-generic-initial-"+args.sha[:7]+"-"+case);assert not root.exists();root.mkdir()
    path=root/"case.dxf";path.write_bytes(source.read_bytes())
    doc=ezdxf.readfile(path)
    dimension=next(e for e in doc.modelspace() if e.dxftype()=="DIMENSION")
    texts=[e.text if e.dxftype()=="MTEXT" else e.dxf.text for e in doc.blocks[dimension.dxf.geometry] if e.dxftype() in {"MTEXT","TEXT"}]
    requirements=[{"id":"hole","handle":dimension.dxf.handle,"value":6.4}]
    rt=Runtime(Policy(root=root))
    result={"case":case,"identical_input_from":source.relative_to(OUT).as_posix(),
        "file_sha256":hashlib.sha256(path.read_bytes()).hexdigest(),"dimension_handle":dimension.dxf.handle,
        "units":doc.header.get("$INSUNITS"),"actual_rendered_texts":texts,
        "initial_dimdec":dimension.override().get("dimdec"),"requirements":requirements,
        "in_memory_verification":verify_dimensions(doc,requirements),
        "saved_public_verification":rt.verify_dimensions("case.dxf",requirements)}
    assert path.read_bytes()==source.read_bytes()
    (root/"result.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8");results.append(result)
report={"product_sha":args.sha,"imported_from":agentcad.__file__,"python":sys.version,"ezdxf":ezdxf.__version__,
    "scope":"Identical saved input bytes from the Pro initial-render case. Generic public verify_dimensions reads the file; no mechanical template or native CAD involved.","cases":results}
(OUT/("agent-generic-initial-precision-"+args.sha[:7]+".json")).write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"product_sha":args.sha,"cases":[{"case":r["case"],"actual_rendered_texts":r["actual_rendered_texts"],
    "in_memory_accepted":r["in_memory_verification"]["accepted"],"saved_public_verification":r["saved_public_verification"]} for r in results]}))
