"""Verify the revised fail-closed legacy marker boundary using public Runtime only."""
import argparse,hashlib,io,json,os,pathlib,subprocess,sys,tarfile
arg=argparse.ArgumentParser();arg.add_argument("sha");args=arg.parse_args()
OUT=pathlib.Path(r"D:\Projects\AgentCAD-output\source-capability-100\reviewer-rubric")
snapshot=OUT/("snapshot-"+args.sha[:7])
if not snapshot.exists():
    snapshot.mkdir()
    archive=subprocess.check_output(["git","-C",r"D:\Projects\AgentCAD","archive",args.sha,"src"])
    with tarfile.open(fileobj=io.BytesIO(archive)) as tar:tar.extractall(snapshot,filter="data")
sys.path.insert(0,str(snapshot/"src"))
import agentcad
from agentcad.policy import Policy
from agentcad.service import Runtime
assert pathlib.Path(agentcad.__file__).resolve().is_relative_to(snapshot.resolve())
dead=subprocess.run([sys.executable,"-c","import os;print(os.getpid())"],capture_output=True,text=True,check=True)
cases=[]
for name,content in (("live",str(os.getpid())),("exited",dead.stdout.strip()),("invalid","old runtime")):
    root=OUT/("legacy-refusal-"+args.sha[:7])/name;root.mkdir(parents=True,exist_ok=True)
    runtime=Runtime(Policy(root=root));assert runtime.create_drawing("case.dxf",units="mm")["ok"]
    _,store=runtime._drawing("case.dxf");marker=store.dir/"lock";marker.write_text(content)
    original=marker.read_bytes();drawing=(root/"case.dxf").read_bytes()
    recovered=runtime.recover("case.dxf")
    mutation=runtime.apply_operations("case.dxf",[{"op":"add_line","start":[0,0],"end":[10,0]}])
    preserved=marker.exists() and marker.read_bytes()==original
    blocked=recovered.get("ok") is False and recovered.get("error",{}).get("code")=="DRAWING_LOCKED" and mutation.get("ok") is False and mutation.get("error",{}).get("code")=="DRAWING_LOCKED"
    cases.append({"case":name,"marker_content":content,"recover":recovered,"mutation":mutation,"marker_unchanged":preserved,"drawing_unchanged":(root/"case.dxf").read_bytes()==drawing,"drawing_sha256":hashlib.sha256(drawing).hexdigest(),"expected_refusal":blocked and preserved})
normal_root=OUT/("legacy-refusal-"+args.sha[:7])/"modern-control";normal_root.mkdir(exist_ok=True)
runtime=Runtime(Policy(root=normal_root));assert runtime.create_drawing("case.dxf",units="mm")["ok"]
control=runtime.apply_operations("case.dxf",[{"op":"add_line","start":[0,0],"end":[10,0]}])
recovery=runtime.recover("case.dxf")
result={"product_sha":args.sha,"imported_from":agentcad.__file__,"cases":cases,"modern_control":control,"modern_no_recovery_needed":recovery,"all_expected":all(c["expected_refusal"] and c["drawing_unchanged"] for c in cases) and control.get("ok") is True and recovery.get("ok") is True,"scope":"Legacy live/exited/invalid markers must fail closed and remain byte-identical. A normal modern writer still works. Complete process crash/lock tests remain separately required; no native CAD run."}
(OUT/("legacy-lock-refusal-"+args.sha[:7]+".json")).write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"product_sha":args.sha,"all_expected":result["all_expected"],"cases":[{"case":c["case"],"refused":c["expected_refusal"],"unchanged":c["drawing_unchanged"]} for c in cases]}))
