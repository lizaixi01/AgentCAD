"""A real live legacy marker is replaced between compare and unlink; no CAD process."""
import argparse,hashlib,io,json,pathlib,subprocess,sys,tarfile
from unittest.mock import patch
arg=argparse.ArgumentParser();arg.add_argument("sha");args=arg.parse_args()
OUT=pathlib.Path(r"D:\Projects\AgentCAD-output\source-capability-100\reviewer-rubric")
snapshot=OUT/("snapshot-"+args.sha[:7])
if not snapshot.exists():
    snapshot.mkdir()
    archive=subprocess.check_output(["git","-C",r"D:\Projects\AgentCAD","archive",args.sha,"src"])
    with tarfile.open(fileobj=io.BytesIO(archive)) as tar:tar.extractall(snapshot,filter="data")
sys.path.insert(0,str(snapshot/"src"))
import agentcad
from agentcad.policy import Policy
from agentcad.service import Runtime
root=OUT/("legacy-lock-race-"+args.sha[:7]);root.mkdir(exist_ok=True)
runtime=Runtime(Policy(root=root))
assert runtime.create_drawing("case.dxf",units="mm")["ok"]
_,store=runtime._drawing("case.dxf");marker=store.dir/"lock"
dead=subprocess.run([sys.executable,"-c","import os; print(os.getpid())"],capture_output=True,text=True,check=True)
dead_pid=int(dead.stdout);assert dead.returncode==0
marker.write_text(str(dead_pid))
code="import os,pathlib,sys\nprint(os.getpid(),flush=True)\ncommand=input()\nif command=='replace':\n pathlib.Path(sys.argv[1]).write_text(str(os.getpid()))\n print('REPLACED',flush=True)\n input()\n"
child=subprocess.Popen([sys.executable,"-u","-c",code,str(marker)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
live_pid=int(child.stdout.readline());original=pathlib.Path.read_text;reads=0;replacement_text=None
def interposed(self,*a,**kw):
    global reads,replacement_text
    value=original(self,*a,**kw)
    if self==marker:
        reads+=1
        if reads==2:
            child.stdin.write("replace\n");child.stdin.flush()
            assert child.stdout.readline().strip()=="REPLACED"
            replacement_text=original(marker)
            assert int(replacement_text)==live_pid and child.poll() is None
    return value
before=(root/"case.dxf").read_bytes()
try:
    with patch.object(pathlib.Path,"read_text",interposed):recovered=runtime.recover("case.dxf")
    marker_after=marker.exists();live_after=child.poll() is None
    after_recovery=(root/"case.dxf").read_bytes()
    mutation=runtime.apply_operations("case.dxf",[{"op":"add_line","start":[0,0],"end":[10,0]}])
    result={"product_sha":args.sha,"imported_from":agentcad.__file__,"scenario":"A real Python child models an older writer acquiring/replacing its legacy marker immediately after the recovery method's second read and before unlink. If recovery refuses without reading, this scheduling point is not reached and the child remains idle.","synchronization":"Path.read_text is interposed only for the target marker to schedule a real child-process file replacement after the final read; product code is unchanged.","dead_writer_pid":dead_pid,"live_writer_pid":live_pid,"marker_reads":reads,"replacement_text":replacement_text,"replacement_triggered":replacement_text is not None,"recover":recovered,"marker_exists_after_recovery":marker_after,"replacement_child_still_running":live_after,"drawing_unchanged_by_recovery":before==after_recovery,"drawing_sha256_before":hashlib.sha256(before).hexdigest(),"new_writer":mutation,"new_write_was_allowed_while_legacy_writer_active":replacement_text is not None and live_after and mutation.get("ok") is True,"refusal_prevents_race":recovered.get("ok") is False and recovered.get("error",{}).get("code")=="DRAWING_LOCKED" and marker_after and original(marker)==str(dead_pid) and mutation.get("ok") is False,"scope":"Lock protocol exclusion only; no claim that the synthetic writer changed the drawing, no native CAD invocation."}
    (OUT/("legacy-lock-race-"+args.sha[:7]+".json")).write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({k:result[k] for k in ("product_sha","marker_reads","marker_exists_after_recovery","replacement_triggered","new_write_was_allowed_while_legacy_writer_active","refusal_prevents_race")}))
finally:
    child.stdin.write("exit\n");child.stdin.flush();child.communicate(timeout=10)
