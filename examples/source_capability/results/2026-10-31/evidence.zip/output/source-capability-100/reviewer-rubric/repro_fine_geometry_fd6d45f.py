import json,pathlib,sys
OUT=pathlib.Path(r"D:\Projects\AgentCAD-output\source-capability-100\reviewer-rubric")
sys.path.insert(0,str(OUT/"snapshot-fd6d45f"/"src"))
import agentcad,ezdxf
from agentcad.policy import Policy
from agentcad.service import Runtime
SHA="fd6d45f274897cf7e2541d4c70d88113dfb6cb22"
results=[]
for case in ["control","dimension_point_shift","source_outline_shift"]:
    root=OUT/("geometry-fd6d45f-"+case);root.mkdir(exist_ok=True)
    rt=Runtime(Policy(root=root))
    assert rt.create_drawing("case.dxf",units="mm")["ok"]
    spec={"parts":[{"name":"fine","at":[130,190],"segments":[{"length":17.12345678,"d_outer":40}]}]}
    r=rt.apply_operations("case.dxf",[{"op":"draw_mechanical_assembly","spec":spec}]);assert r["ok"],r
    r=rt.read_engineering("case.dxf","mechanical");assert r["ok"] and not r["critique"]
    dimrow=next(a for a in r["manufacturing"][0]["annotations"] if a["kind"]=="length.0")
    doc=ezdxf.readfile(root/"case.dxf")
    if case=="dimension_point_shift":
        dim=doc.entitydb[dimrow["handle"]]
        dim.dxf.defpoint3=dim.dxf.defpoint3+(5e-7,0,0)
    elif case=="source_outline_shift":
        body=doc.entitydb[r["parts"][0]["handle"]]
        points=list(body.get_points("xyseb"))
        p=points[1];points[1]=(p[0]+5e-7,*p[1:]);body.set_points(points,format="xyseb")
    if case!="control":doc.saveas(root/"case.dxf")
    read=rt.read_engineering("case.dxf","mechanical")
    delivered=rt.deliver_drawing("case.dxf","delivery",formats=["dxf"],strict=True)
    assert delivered["ok"]==(case=="control"),(case,read,delivered)
    result={"case":case,"delta":0 if case=="control" else 5e-7,"read":read,"delivery":delivered}
    (root/"result.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    results.append(result)
(OUT/"fine-geometry-counterexamples-fd6d45f.json").write_text(json.dumps({"product_sha":SHA,"imported_from":agentcad.__file__,"cases":results},indent=2)+"\n",encoding="utf-8")
print(json.dumps({"product_sha":SHA,"cases":[{"case":r["case"],"critique":r["read"].get("critique"),"delivery_ok":r["delivery"]["ok"]} for r in results]}))

