import hashlib,json,pathlib,subprocess
ROOT=pathlib.Path(r"D:\Projects\AgentCAD-output\source-capability-100\reviewer-rubric")
REPO=pathlib.Path(r"D:\Projects\AgentCAD")
OLD="b4c04669238e771a0888114f1af3260d7c371834"
NEW="83506bfa8a7ccc4c7eaf9da84cc8004986af02e3"
ARCHIVE="69c1425a2dd7465f6f8c092033447b608554a8a3"
def git(*args):return subprocess.check_output(["git","-C",str(REPO),*args])
def tree(sha, path):
    return {line.split("\t",1)[1]:line.split("\t",1)[0].split()[2] for line in git("ls-tree","-r",sha,"--",path).decode().splitlines()}
a,b=tree(OLD,"src"),tree(NEW,"src")
same=sorted(p for p in a.keys()&b.keys() if a[p]==b[p])
changed=sorted(p for p in a.keys()&b.keys() if a[p]!=b[p])
added=sorted(b.keys()-a.keys());removed=sorted(a.keys()-b.keys())
rubric=git("show","25abc96b9e39abe4e52464d3f8f00eba589759e5:docs/source-capability-rubric.md")
assert rubric==git("show",NEW+":docs/source-capability-rubric.md")
prior_local=pathlib.Path(r"D:\Projects\AgentCAD-output\source-capability\reviewer-rubric\assessment.json").read_bytes()
prior_public=git("show",ARCHIVE+":examples/source_capability/results/2026-10-30/assessment.json")
assert prior_local==prior_public
base_url="https://github.com/lizaixi01/AgentCAD/blob/"+ARCHIVE+"/examples/source_capability/results/2026-10-30/"
history=[]
for name in ["assessment.json","evidence.zip","manifest.json"]:
    content=git("show",ARCHIVE+":examples/source_capability/results/2026-10-30/"+name)
    history.append({"name":name,"sha256":hashlib.sha256(content).hexdigest(),"bytes":len(content),"url":base_url+name})
item_boundary={
"F1":"Primitive/measure/analytic geometry source unchanged; retain prior fixed geometric and native checks within that boundary. New mechanical dimension behavior is reviewed under F3/E2/C2.",
"F2":"Editing/identity/guard/store implementation unchanged. Prior edit evidence can be inherited for those paths; changed mechanical metadata feedback still needs current regression.",
"F3":"General annotate/tolerance/fits source unchanged, but new mechanical_annotations changes numerical generation and display contracts. Require fresh dimension examples and stale-display counterexamples.",
"F4":"records.py adds entity-owned XRECORD storage. Inherit ordinary layouts/blocks/print implementation evidence only; require new metadata retention/native/parity checks.",
"F5":"Mechanical generation and shared record serialization changed. P&ID/architecture algorithms and foreign plant logic unchanged, but current common-record regression/native checks remain required.",
"C1":"Transactional/lock/checkpoint source unchanged; inherit isolated state guarantees. New writer/error paths need current failed-operation and full-run evidence.",
"C2":"New manufacturing completeness/display contract changed. Confirmed owner, partial annotation-list and stale dimdec false passes cap this item at 2 pending repair/retest.",
"C3":"Delivery source itself unchanged but new XRECORD payload crosses its snapshot boundary. Confirmed output-record corruption is falsely accepted; cap at 2 pending repair/retest.",
"C4":"Shared domain record decoder now reads entity-owned XRECORD. Preserve unchanged malformed-file/unknown-unit evidence, require new malformed/absent metadata refusal cases.",
"B1":"Discovery/native backend modules unchanged; retain declared complementary-backend and missing-dependency contract evidence.",
"B2":"New dimensions and entity-owned records need native save/read/regeneration/AUDIT; old records alone do not cover this.",
"B3":"CI definition unchanged; completed old runs prove only old source. Await current four-lane CI and enabled local native run.",
"E1":"M14 source and nominal depth changed 14.6 to 15; new independently inspected Figure 4/Table 4 support D24/t15 with mixed ISO/GOST scope. Await final fixed-source numeric/public API/unit tests.",
"E2":"New two inspected native-witness examples visibly contain supplied critical lengths, outer/bore diameters and hole-pattern annotations. Await final fixed-source examples after integrity repairs; unspecified process/tolerance/depth are not invented.",
"E3":"Mechanical readback and shared records changed; retain unchanged P&ID/room/foreign ARC algorithms only after source trace, supplement with new manufacturing error-feedback evidence.",
"T1":"New behavioral tests are present; do not convert counts into score. Await completed current interface/process/integration/native runs.",
"T2":"Lock/reproducibility mechanisms unchanged; require current product/harness/environment hashes and archive boundary. Old evidence is linked, not copied or relabeled.",
"T3":"Await current completed CI/failure gates and version correctness/performance comparison. Do not sign from running jobs.",
"S1":"Policy/HTTP/path/scripting defaults and relevant implementation unchanged; prior actual-request/no-write evidence can be inherited, subject to final regression.",
"S2":"Lock/worker/cancellation/native timeout code unchanged; preserve prior process-boundary evidence, require new full run for integration."
}
result={"schema":"source-review-boundary-trace/v1","prior_product_sha":OLD,"candidate_product_sha":NEW,
"frozen_rubric_sha256":hashlib.sha256(rubric).hexdigest(),"frozen_rubric_unchanged":True,
"prior_assessment_bytes_match_public_archive":True,"historical_archive_commit":ARCHIVE,
"historical_evidence":history,"source_tree":{"prior_files":len(a),"candidate_files":len(b),"unchanged":same,"modified":changed,"added":added,"removed":removed},
"items":[{"id":k,"boundary":v} for k,v in item_boundary.items()],
"score_status":"pending; no final new total",
"scope":"Trace source/data boundaries, not merely same filenames. Changes to shared serializers invalidate assumptions in unchanged consumers."}
(ROOT/"boundary-trace-83506bf.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"prior_files":len(a),"candidate_files":len(b),"unchanged":len(same),"modified":changed,"added":added,"removed":removed,"historical_evidence":history,"rubric_sha256":result["frozen_rubric_sha256"]}))

