"""Inspect completed native regeneration and authenticated CI bytes; never launch CAD."""
import argparse,hashlib,json,math,pathlib,re,zipfile
import ezdxf
from ezdxf.tools.text import plain_mtext
arg=argparse.ArgumentParser();arg.add_argument("sha");args=arg.parse_args();label=args.sha[:7]
ROOT=pathlib.Path(r"D:\Projects\AgentCAD-output\source-capability-100");OUT=ROOT/"reviewer-rubric"
def load(p):return json.loads(p.read_text(encoding="utf-8"))
def digest(raw):return hashlib.sha256(raw).hexdigest()
api=load(OUT/("ci-artifacts-api-"+label+".json"));artifacts=[]
for artifact in api["artifacts"]:
    path=ROOT/("ci-raw-"+label)/(artifact["name"]+".zip");raw=path.read_bytes()
    assert "sha256:"+digest(raw)==artifact["digest"]
    assert artifact["workflow_run"]["head_sha"]==args.sha
    members=[]
    with zipfile.ZipFile(path) as z:
        for member in z.infolist():
            if member.is_dir():continue
            target=ROOT/("ci-"+label)/artifact["name"]/member.filename
            assert target.resolve().is_relative_to((ROOT/("ci-"+label)).resolve())
            data=z.read(member);assert data==target.read_bytes()
            members.append({"path":target.relative_to(ROOT).as_posix(),"sha256":digest(data)})
    artifacts.append({"path":path.relative_to(ROOT).as_posix(),"sha256":digest(raw),"matches_independent_github_api_digest":True,"files":members})
test_root=ROOT/("test-windows-native-"+label)/"test_generic_precision_and_ang0"
retained=OUT/("native-angular-"+label);retained.mkdir(exist_ok=True)
if test_root.exists():
    outputs=list((test_root/"native-jobs").glob("*/out.dxf"));assert len(outputs)==1
    job=outputs[0].parent
else:job=retained
files=[]
for name in ("in.dxf","out.dxf","job.scr","result.txt","console.log"):
    source=job/name;raw=source.read_bytes();target=retained/name
    if source!=target:target.write_bytes(raw)
    files.append({"path":target.relative_to(ROOT).as_posix(),"sha256":digest(raw),"bytes":len(raw)})
before=ezdxf.readfile(retained/"in.dxf");native=ezdxf.readfile(retained/"out.dxf")
inputs=list(before.modelspace().query("DIMENSION"));assert len(inputs)==4
assert all(not d.dxf.hasattr("geometry") and not d.dxf.hasattr("actual_measurement") for d in inputs)
assert (retained/"out.dxf").read_bytes().startswith(b"AutoCAD Binary DXF")
assert (retained/"result.txt").read_text().strip()=="done=1"
small=math.degrees(math.atan2(30,40));expected=[small,180-small,small,180-small];angles=[]
for original,want in zip(inputs,expected):
    dim=native.entitydb[original.dxf.handle]
    actual=math.degrees(dim.dxf.actual_measurement)
    texts=[e.text if e.dxftype()=="MTEXT" else e.dxf.text for e in native.blocks[dim.dxf.geometry] if e.dxftype() in {"MTEXT","TEXT"}]
    assert len(texts)==1
    plain=plain_mtext(texts[0]);shown=float(re.search(r"[-+]?\d+(?:\.\d*)?",plain).group())
    assert math.isclose(actual,want,abs_tol=1e-7) and shown==round(want,2)
    angles.append({"handle":dim.dxf.handle,"expected_degrees":want,"native_group42_radians":dim.dxf.actual_measurement,"native_measurement_degrees":actual,"actual_graphics_texts":texts,"displayed_number":shown,"passed":True})
result={"product_sha":args.sha,"passed":True,"ci_artifacts":artifacts,"ci_files_compared":sum(len(a["files"]) for a in artifacts),"native_angular":{"files":files,"cached_geometry_and_measurement_absent_in_input":True,"actual_autocad_binary_output":True,"completion_marker":True,"angles":angles,"scope":"Read-only independent inspection of the coordinator's completed AutoCAD execution. The reviewer did not run CAD; expected angles derive from the supplied50x0 and40x30 legs and the four selected sectors, not the product's measurement helper."}}
(OUT/("native-angles-ci-artifacts-"+label+".json")).write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"product_sha":args.sha,"passed":True,"ci_files_compared":result["ci_files_compared"],"native_angles":angles}))
