"""Apply the same displayed-dimension boundary to pinned Pro, headless only."""
import asyncio, hashlib, json, pathlib, subprocess, sys
PRO=pathlib.Path(r"D:\Projects\AgentCAD-output\autocad-benchmark-20261030\upstream")
OUT=pathlib.Path(r"D:\Projects\AgentCAD-output\source-capability-100\reviewer-rubric")
SHA="58a05ddfc34a9832c626e82cd88ecdce8e16a62a"
assert subprocess.check_output(["git","-C",str(PRO),"rev-parse","HEAD"],text=True).strip()==SHA
assert not subprocess.check_output(["git","-C",str(PRO),"status","--porcelain","--","backends","engineering"],text=True).strip()
sys.path.insert(0,str(PRO))
import ezdxf
from backends.ezdxf_backend import EzdxfBackend
from engineering.verification.types import FeatureSelector, Requirement, RequirementSet
from engineering.verification.report import verify_requirements
from engineering.verification.artifact import verify_artifact
def requirement(handle):
    return RequirementSet(requirements=(Requirement(id="hole",quantity="diameter",
        target=(("nominal",6.4),("unit","mm")),
        features=(FeatureSelector(kind="dimension",value=(("handle",handle),)),),
        provenance="explicit",source=(("document","independent-review"),)),),units="mm")
async def main():
    results=[]
    for case in ["control","rounded_display","dimension_unused_block"]:
        folder=OUT/("pro-"+case);folder.mkdir(exist_ok=True)
        path=folder/"case.dxf"
        doc=ezdxf.new("R2010",units=4,setup=True)
        msp=doc.modelspace()
        msp.add_circle((50,50),3.2)
        dim=msp.add_diameter_dim(center=(50,50),radius=3.2,angle=45,
            dimstyle="Standard",override={"dimdec":1,"dimrnd":0.1,"dimlfac":1,"dimzin":8})
        dim.render()
        if case=="rounded_display":
            dim.update({"dimdec":0});dim.render()
        elif case=="dimension_unused_block":
            msp.move_to_layout(dim.dimension,doc.blocks.new("UNUSED_REVIEW"))
        handle=dim.dimension.dxf.handle
        doc.saveas(path)
        read=ezdxf.readfile(path)
        d=read.entitydb[handle]
        texts=[e.text if e.dxftype()=="MTEXT" else e.dxf.text for e in read.blocks[d.dxf.geometry] if e.dxftype() in {"MTEXT","TEXT"}]
        backend=EzdxfBackend();await backend.connect()
        try:
            await backend.drawing_open(str(path))
            live=await verify_requirements(backend,requirement(handle))
            saved=await verify_artifact(str(path),requirement(handle),backend=backend)
        finally:await backend.disconnect()
        result={"case":case,"dimension_handle":handle,"actual_rendered_texts":texts,
            "dimension_in_model":any(e.dxf.handle==handle for e in read.modelspace()),
            "in_memory_verification":live,"saved_verification":saved,
            "file_sha256":hashlib.sha256(path.read_bytes()).hexdigest()}
        (folder/"result.json").write_text(json.dumps(result,indent=2,default=str)+"\n",encoding="utf-8")
        results.append(result)
    report={"product_sha":SHA,"python":sys.version,"ezdxf":ezdxf.__version__,
        "scope":"Exact Pro source and its declared dimension-selected verification workflow; headless only. No native CAD launched.",
        "cases":results}
    (OUT/"pro-dimension-boundaries-58a05dd.json").write_text(json.dumps(report,indent=2,default=str)+"\n",encoding="utf-8")
    print(json.dumps({"product_sha":SHA,"cases":[{"case":r["case"],"actual_rendered_texts":r["actual_rendered_texts"],
        "dimension_in_model":r["dimension_in_model"],
        "in_memory_accepted":r["in_memory_verification"].get("accepted"),
        "saved_accepted":r["saved_verification"].get("accepted"),
        "dimension_evidence":[row.get("dimension") for row in r["saved_verification"].get("rows",[])]} for r in results]},default=str))
asyncio.run(main())

