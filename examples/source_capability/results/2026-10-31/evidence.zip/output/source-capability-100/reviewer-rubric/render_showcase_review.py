"""Render existing PDFs for independent review; no CAD application is started."""
import argparse,hashlib,json,pathlib,subprocess
from pypdf import PdfReader
parser=argparse.ArgumentParser();parser.add_argument("sha");args=parser.parse_args()
BASE=pathlib.Path(r"D:\Projects\AgentCAD-output\source-capability-100")
POPPLER=pathlib.Path(r"C:\Users\HUAWEI\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\poppler\Library\bin\pdftoppm.exe")
directory=BASE/("showcase-"+args.sha[:7]);rows=[]
for path in sorted(directory.rglob("*.pdf")):
    reader=PdfReader(path);assert len(reader.pages)==1,path
    name=path.relative_to(directory).as_posix().replace("/","-").removesuffix(".pdf")
    prefix=BASE/"reviewer-rubric"/("visual-"+args.sha[:7]+"-"+name)
    subprocess.run([str(POPPLER),"-scale-to","2000","-png","-singlefile",str(path),str(prefix)],check=True,capture_output=True)
    png=prefix.with_suffix(".png");page=reader.pages[0]
    rows.append({"pdf":path.relative_to(BASE).as_posix(),"pdf_sha256":hashlib.sha256(path.read_bytes()).hexdigest(),
                 "image":png.relative_to(BASE).as_posix(),"image_sha256":hashlib.sha256(png.read_bytes()).hexdigest(),
                 "pages":1,"page_mm":[round(float(page.mediabox.width)*25.4/72,3),round(float(page.mediabox.height)*25.4/72,3)]})
assert len(rows)==7
(BASE/"reviewer-rubric"/("visual-inputs-"+args.sha[:7]+".json")).write_text(json.dumps({"product_sha":args.sha,"renderer":"Poppler pdftoppm; 2000 pixel maximum edge","files":rows},indent=2)+"\n",encoding="utf-8")
print(json.dumps(rows))
