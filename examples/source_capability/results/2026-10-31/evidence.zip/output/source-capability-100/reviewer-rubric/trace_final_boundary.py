import hashlib,json,pathlib,subprocess
R=pathlib.Path(r"D:\Projects\AgentCAD")
O=pathlib.Path(r"D:\Projects\AgentCAD-output\source-capability-100\reviewer-rubric")
OLD="b4c04669238e771a0888114f1af3260d7c371834"
NEW="cd20aac3832aa1133ca475fa0f3802400c5a01fb"
def git(*args): return subprocess.check_output(["git","-C",str(R),*args])
def tree(s):
    return {line.split("\t",1)[1]:line.split("\t",1)[0].split()[2] for line in git("ls-tree","-r",s,"--","src").decode().splitlines()}
before,after=tree(OLD),tree(NEW)
trace=json.loads((O/"boundary-trace-83506bf.json").read_text())
trace["candidate_product_sha"]=NEW
trace["reviewed_intermediate_shas"]=["83506bfa8a7ccc4c7eaf9da84cc8004986af02e3","0cffbf9434a86f1bc0e26d5d6b72da4807467603"]
trace["source_tree"]={"prior_files":len(before),"candidate_files":len(after),
"prior_python_files":sum(p.endswith(".py") for p in before),
"candidate_python_files":sum(p.endswith(".py") for p in after),
"unchanged":sorted(p for p in before.keys()&after.keys() if before[p]==after[p]),
"modified":[{"path":p,"prior_blob":before[p],"candidate_blob":after[p]} for p in sorted(before.keys()&after.keys()) if before[p]!=after[p]],
"added":sorted(after.keys()-before.keys()),"removed":sorted(before.keys()-after.keys())}
new_rules={
"C2":"Manufacturing completeness/display changed. Exact earlier input cases now reject uninserted-block ownership, partial annotation rows and stale DIMDEC. New exact DIMRND and DIMLUNIT controls pass/refuse correctly. Confirmed prior defects' temporary cap lifted; final score awaits complete evidence.",
"C3":"Delivery now recursively snapshots owned extension records/dictionaries with cycle detection. Identical export-corruption input is rejected. Prior false-parity cap lifted; final score awaits complete workflow evidence.",
"B1":"Discovery and AutoCAD backend remain unchanged. FreeCAD process-progress drain changed; use its new deterministic regressions and current native run for that boundary.",
"S2":"File-lock/worker/cancellation code unchanged, but FreeCAD completion previously dropped final progress lines. New code drains completed lines after process exit; require deterministic exit-race controls and real enabled native final run.",
"B3":"Current fixed-SHA CI run41078370487 independently confirmed completed/success in all four lanes. Current local native run and test-ID/skip audit still required.",
}
for item in trace["items"]:
    if item["id"] in new_rules:item["boundary"]=new_rules[item["id"]]
rubric=git("show",NEW+":docs/source-capability-rubric.md")
assert hashlib.sha256(rubric).hexdigest()==trace["frozen_rubric_sha256"]
trace["normal_source_hashes"]={p:hashlib.sha256(git("show",NEW+":"+p)).hexdigest() for p in after}
(O/"boundary-trace-cd20aac.json").write_text(json.dumps(trace,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"source_tree":{k:v for k,v in trace["source_tree"].items() if k!="unchanged"},"unchanged_count":len(trace["source_tree"]["unchanged"]),"rubric_unchanged":True}))

