"""Prepare the new candidate's trace and pending review; never assign a score."""
import argparse,hashlib,json,pathlib,subprocess
parser=argparse.ArgumentParser();parser.add_argument("sha");args=parser.parse_args()
OUT=pathlib.Path(r"D:\Projects\AgentCAD-output\source-capability-100\reviewer-rubric")
REPO=pathlib.Path(r"D:\Projects\AgentCAD")
OLD="b4c04669238e771a0888114f1af3260d7c371834"
def git(*params):return subprocess.check_output(["git","-C",str(REPO),*params])
def tree(sha):
    return {s.split("\t",1)[1]:s.split("\t",1)[0].split()[2] for s in git("ls-tree","-r",sha,"--","src").decode().splitlines()}
before,after=tree(OLD),tree(args.sha)
trace=json.loads((OUT/"boundary-trace-cd20aac.json").read_text(encoding="utf-8"))
trace["candidate_product_sha"]=args.sha
trace["reviewed_intermediate_shas"]=["83506bfa8a7ccc4c7eaf9da84cc8004986af02e3","0cffbf9434a86f1bc0e26d5d6b72da4807467603","cd20aac3832aa1133ca475fa0f3802400c5a01fb","2a68afe1f7d0e6de8acaae683606526b51c4daed","392b7f2ced9686676c804e0d58884afc9cee10c2","760a2c2e9f68908da8377cd3fb30727552b03730","fd6d45f274897cf7e2541d4c70d88113dfb6cb22"]
trace["source_tree"]={"prior_files":len(before),"candidate_files":len(after),
    "prior_python_files":sum(p.endswith(".py") for p in before),"candidate_python_files":sum(p.endswith(".py") for p in after),
    "unchanged":sorted(p for p in before.keys()&after.keys() if before[p]==after[p]),
    "modified":[{"path":p,"prior_blob":before[p],"candidate_blob":after[p]} for p in sorted(before.keys()&after.keys()) if before[p]!=after[p]],
    "added":sorted(after.keys()-before.keys()),"removed":sorted(before.keys()-after.keys())}
updates={
"F1":"Primitive/measure algorithms unchanged, but shared feature extraction now distinguishes geometry/scaled measurement from actual displayed values. Native conversion also changed to binary DXF. Inherit primitive algorithms only; require current common validation and real-backend checks.",
"F4":"Domain records now use owned XRECORD and AutoCAD conversion now uses binary DXF intermediates, normalized to ordinary text workspace commits. Prior layout/block/page implementation is unchanged; require current metadata retention, interoperability and format checks.",
"C2":"Mechanical source/display checks pass the prior fresh-spec controls and reject old tampering. New generic verification now reads actual saved visible text. The exact same Pro input bytes (initial DIMDEC0, one render) are rejected by public verify_dimensions while DIMDEC1 passes; displayed-value requirements independently reject requested6.4 when actual text6, and accept requested6.0. The old generic implementation was unchanged from b4, but this new counterexample invalidated inheriting its score. Its specific cap can be lifted only after this same-input repair/retest; full final evidence remains pending.",
"C3":"Owned XRECORD parity and native binary conversion remain covered by their targeted controls. Shared generic QA now uses rendered-dimension evidence and affects delivery gates, so exact-current delivery/native/full regression is required rather than inheriting all760 results.",
"C4":"Shared records/native import and rendered-dimension evidence changed. Missing, hidden or ambiguous graphics must not invent a displayed value or pass explicit requirements. Existing unknown-unit/entity policies are unchanged, but these new abnormal-input boundaries need current evidence.",
"B1":"Discovery unchanged. AutoCAD conversion now requests binary DXF to preserve doubles; FreeCAD drains final complete progress lines. Both changed backend boundaries need current deterministic contract tests and enabled real native runs.",
"B2":"Fresh native save/read/AUDIT must cover new dimensions/large XRECORDs and binary precision preservation at normal/large coordinates. Older successful ASCII runs cannot establish this new boundary.",
"B3":"Await this fixed candidate's completed four-lane CI and native run/test-ID/skip audit; older completed runs remain historical, not relabeled.",
"E2":"Critical supplied dimensions and two different native-witness examples are readable in preceding candidates. Require this fixed candidate's native-witness PDFs/readback and independent final visual inspection after source-integrity and binary-conversion changes.",
}
if "src/agentcad/setup_gui.py" in after:
    trace["reviewed_merge_inputs"]=[{"commit":"0758cdc","scope":"New local setup HTTP UI, CLI entry and install progress callbacks."},{"commit":"4ce35806db048162d61fd9492f14539280c592ed","scope":"Tolerance provenance/clear, dimension redraw, image-reading note placement and legacy-marker recovery. The unsafe automatic marker deletion was subsequently removed from the candidate."}]
    updates.update({
        "F1":"Primitive/measure algorithms retain prior evidence except two-line angular dimension measurement: the new shared sector helper uses the actual dimension arc point. Shared feature extraction now reads rendered primary values and excludes angles from DIMLFAC. Require current opposing-sector/reversed-leg controls and real AutoCAD reconstruction with old caches removed.",
        "F2":"General edits and identity retain their prior logic. Dimension redraw now uses native zero-increment semantics, angular sectors and merged tolerance-source/clear rules; require current saved edit controls and current full tests.",
        "F3":"Generic creation/redraw now preserves native DIMRND=0 while honoring DIMDEC; public rotated creation and later precision edits are independently checked. New literal/fraction parsing and merged tolerance provenance/clearing require current native and non-native checks; older tolerance evidence alone does not establish the new shared boundary.",
        "F5":"Domain reconstruction is traced separately from new mechanical annotations. Merged image_dimensions only moves the raster uncertainty note to one top-level field and leaves equation/ink analysis un-certified; require current public image-reading tests for that output contract.",
        "C1":"Modern transactions/checkpoints retain their implementation. Runtime.recover now explicitly rejects legacy markers, which are never removed automatically; independent live/exited/invalid marker controls preserve the drawing and marker. Current crash/OS-lock process tests still required.",
        "S1":"Core workspace, read-only, scope and MCP/HTTP defaults are traced to prior evidence. Newly merged setup_gui introduces a separate loopback/token HTTP boundary; its actual HTTP refusal, dry-run and temporary-config tests must complete on this candidate, rather than inheriting all earlier security evidence.",
        "S2":"Modern OS-lock/cancellation/checkpoints retain prior boundaries. FreeCAD drains final progress lines. Newly merged unsafe legacy auto-unlink was removed after an independently reproduced live-writer replacement race; candidate refuses untouched live/exited/invalid legacy markers and directs offline manual handling. Setup progress/error handling is also new. Current process/native tests supplement the targeted refusal/race replay.",
        "T2":"Locked dependencies and evaluator remain explicit, but complete candidate provenance must include the merged setup/installation/static-file and angular/tolerance changes. Full Git src tree identity is traced; runtime/CI Python hashes and actual CI checkout SHA are reported separately.",
    })
    updates["B1"] += " New setup/doctor UI routes use the existing installation/capability detection contract and require current tests with external client commands isolated."
for item in trace["items"]:
    if item["id"] in updates:item["boundary"]=updates[item["id"]]
rubric=git("show",args.sha+":docs/source-capability-rubric.md")
assert hashlib.sha256(rubric).hexdigest()==trace["frozen_rubric_sha256"]
trace["frozen_rubric_sha256_basis"]="SHA256 of LF repository blob content returned by git show <candidate>:docs/source-capability-rubric.md; not the CRLF working-tree file."
trace["normal_source_hashes"]={p:hashlib.sha256(git("show",args.sha+":"+p)).hexdigest() for p in after}
(OUT/("boundary-trace-"+args.sha[:7]+".json")).write_text(json.dumps(trace,indent=2)+"\n",encoding="utf-8")
p=OUT/"assessment.pending.json"
a=json.loads(p.read_text(encoding="utf-8"));agent=a["products"][0];old_sha=agent["product_sha"]
preserved=OUT/("assessment.pending-"+old_sha[:7]+".json")
if not preserved.exists():preserved.write_bytes(p.read_bytes())
agent["product_sha"]=args.sha;agent["source_url"]="https://github.com/lizaixi01/AgentCAD/tree/"+args.sha
a["reviewed_at"]="2026-10-31"
a["method"]["frozen_rubric_sha256_basis"]=trace["frozen_rubric_sha256_basis"]
a["method"]["meaning_of_score"]="A sum of bounded ordinal evidence judgments under this rubric, not a percentage of all CAD functionality, universal correctness, official rank or manufacturing certification."
raw_rubric=pathlib.Path(r"D:\Projects\AgentCAD-wt\source-capability-100\docs\source-capability-rubric.md").read_bytes()
a["method"]["rubric_worktree_raw_sha256"]=hashlib.sha256(raw_rubric).hexdigest()
a["method"]["rubric_line_endings_note"]="Repository LF bytes define the frozen rubric. Windows working-tree CRLF bytes are separately hashed; newline-normalized contents match."
assert raw_rubric.replace(b"\r\n",b"\n")==rubric
for row in agent["items"]:
    for source in row["source"]:source["url"]=source["url"].replace(old_sha,args.sha)
    for i,path in enumerate(row["evidence_paths"]):
        if old_sha[:7] in path and not any(x in path for x in ("agent-generic-initial-precision-760a2c2","full-failure-diagnosis-")):
            updated=path.replace(old_sha[:7],args.sha[:7])
            if (OUT.parent/updated).exists() or path.startswith(("windows-native-","v8-","showcase-","performance-","ci-")):
                row["evidence_paths"][i]=updated
    row["evidence_paths"].append("reviewer-rubric/boundary-trace-"+args.sha[:7]+".json")
    if row["id"] in {"F4","C3","B1","B2"}:
        row["source"].append({"path":"src/agentcad/backends/autocad.py","line":131,"url":"https://github.com/lizaixi01/AgentCAD/blob/"+args.sha+"/src/agentcad/backends/autocad.py#L131"})
    if row["id"]=="C2":
        row.pop("score_upper_bound",None)
        row["resolved_finding"]=row.pop("unresolved_finding",None)
        row["basis"]="Mechanical source/required roles/definitions/graphics are checked separately. Generic verification also reads actual saved visible primary text; the identical Pro initial-rounding input is now rejected with displayed6.0 and dimension_mismatch, while the6.4 control passes. Public displayed-value requirements use the actual graphics value and do not infer a missing value from geometry. Current full native/CI evidence is pending."
        row["evidence_paths"].append("reviewer-rubric/coordinate-source-counterexamples-"+args.sha[:7]+".json")
        row["evidence_paths"].append("reviewer-rubric/all-view-source-counterexamples-"+args.sha[:7]+".json")
        row["evidence_paths"].append("reviewer-rubric/repro_coordinate_source_final.py")
        row["evidence_paths"].append("reviewer-rubric/agent-generic-initial-precision-"+args.sha[:7]+".json")
        row["evidence_paths"].append("reviewer-rubric/generic-requirement-semantics-"+args.sha[:7]+".json")
        for path in ("src/agentcad/dimension_display.py","src/agentcad/validate/features.py","src/agentcad/validate/requirements.py","tests/test_dimension_display.py"):
            row["source"].append({"path":path,"url":"https://github.com/lizaixi01/AgentCAD/blob/"+args.sha+"/"+path})
    if row["id"]=="B1":row["basis"]="Discovery and capability refusals retain their prior boundary. AutoCAD conversion now uses binary DXF intermediates to preserve database doubles and public commits remain text. FreeCAD drains final progress lines; fresh complete native evidence is pending."
    if row["id"]=="C2":
        parsed=OUT/("generic-parser-boundaries-"+args.sha[:7]+".json")
        if parsed.exists() and json.loads(parsed.read_text())["all_expected"]:
            row["evidence_paths"].append("reviewer-rubric/"+parsed.name)
            row["basis"] += " Same-byte r8 suffix/fraction controls pass and all tampered primary values are rejected; the specific new parser cap is lifted after independent replay, with complete final evidence still pending."
        else:
            row["score_upper_bound"]=2
            row["unresolved_finding"]="The new suffix/fraction parsing false-acceptance cases still need exact-current independent replay before lifting their cap."
    if row["id"]=="F3":
        rendered=OUT/("generic-default-render-"+args.sha[:7]+".json")
        if rendered.exists() and json.loads(rendered.read_text())["all_expected"]:
            row["resolved_finding"]=row.pop("unresolved_finding",None)
            row["evidence_paths"].append("reviewer-rubric/"+rendered.name)
            row["basis"] += " The default rotated-DIM failure is now independently repaired: saved45.98 at DIMDEC2 and45.981 after public redraw at DIMDEC3, with native DIMRND0 unchanged."
    if row["id"] in {"S2","C1"}:
        for prefix in ("legacy-lock-race-","legacy-lock-refusal-"):
            evidence=OUT/(prefix+args.sha[:7]+".json")
            if evidence.exists():row["evidence_paths"].append("reviewer-rubric/"+evidence.name)
a["pending_evidence"]=["Exact "+args.sha[:7]+" completed full native run and environment/source binding","Exact "+args.sha[:7]+" completed four-lane CI and skip/test-ID inventory","Exact "+args.sha[:7]+" v8 report","Exact "+args.sha[:7]+" native showcase and independent final visual inspection","Exact "+args.sha[:7]+" same-environment version performance/correctness comparison"]
p.write_text(json.dumps(a,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
assert all(product["total_score"] is None and all(item["score"] is None for item in product["items"]) for product in a["products"])
print(json.dumps({"candidate":args.sha,"source_files":len(after),"unchanged":len(trace["source_tree"]["unchanged"]),"final_totals":[x["total_score"] for x in a["products"]]}))
