import json,pathlib,sys
OUT=pathlib.Path(r"D:\Projects\AgentCAD-output\source-capability-100\reviewer-rubric")
sys.path.insert(0,str(OUT/"snapshot-cd20aac"/"src"))
import agentcad,ezdxf
from agentcad.policy import Policy
from agentcad.service import Runtime
from agentcad.engineering.mechanical_annotations import _rendered
SHA="cd20aac3832aa1133ca475fa0f3802400c5a01fb"
results=[]
for name,damage in [("control",{}),("round_zero",{"dimrnd":0}),("round_micro",{"dimrnd":1e-6}),("fraction_units",{"dimlunit":4})]:
    root=OUT/("precision-cd20aac-"+name);root.mkdir(exist_ok=True)
    rt=Runtime(Policy(root=root))
    assert rt.create_drawing("case.dxf",units="mm")["ok"]
    spec={"parts":[{"name":"precise","at":[135,195],"segments":[{"length":17.12345678,"d_outer":42}]}]}
    created=rt.apply_operations("case.dxf",[{"op":"draw_mechanical_assembly","spec":spec}]);assert created["ok"],created
    read=rt.read_engineering("case.dxf","mechanical");assert read["ok"] and not read["critique"]
    row=next(r for r in read["manufacturing"][0]["annotations"] if r["kind"]=="length.0")
    doc=ezdxf.readfile(root/"case.dxf");dim=doc.entitydb[row["handle"]]
    before=_rendered(doc,dim)
    if damage:
        override=dim.override();override.update(damage);override.commit();doc.saveas(root/"case.dxf")
    checked=rt.read_engineering("case.dxf","mechanical")
    delivered=rt.deliver_drawing("case.dxf","delivery",formats=["dxf"],strict=True)
    result={"case":name,"changed_settings":damage,"original_rendered":before,
        "read":checked,"delivery":delivered}
    assert (delivered["ok"] is True)==(name=="control"),result
    (root/"result.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    results.append(result)
(OUT/"precision-counterexamples-cd20aac.json").write_text(json.dumps({"product_sha":SHA,"imported_from":agentcad.__file__,"cases":results},indent=2)+"\n",encoding="utf-8")
print(json.dumps({"product_sha":SHA,"cases":[{"case":r["case"],"original_rendered":r["original_rendered"],"read_critique":r["read"].get("critique"),"delivery_ok":r["delivery"]["ok"],"delivery_error":r["delivery"].get("error",{}).get("code")} for r in results]}))

