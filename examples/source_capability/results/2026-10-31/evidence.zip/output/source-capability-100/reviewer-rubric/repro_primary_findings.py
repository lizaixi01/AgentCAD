"""Read the independent initial control; distinguish display and metadata failures."""
import argparse,hashlib,json,pathlib,sys
arg=argparse.ArgumentParser();arg.add_argument("sha");args=arg.parse_args()
OUT=pathlib.Path(r"D:\Projects\AgentCAD-output\source-capability-100\reviewer-rubric");label=args.sha[:7]
snapshot=OUT/("snapshot-"+label);sys.path.insert(0,str(snapshot/"src"))
import agentcad,ezdxf
from agentcad.policy import Policy
from agentcad.service import Runtime
assert pathlib.Path(agentcad.__file__).resolve().is_relative_to(snapshot.resolve())
original=OUT/"pro-initial-check-control/case.dxf";cases=[]
for name in ("control","metadata_only","metadata_and_display"):
    root=OUT/("primary-findings-"+label)/name;root.mkdir(parents=True,exist_ok=True)
    doc=ezdxf.readfile(original);dim=doc.modelspace().query("DIMENSION").first
    if name!="control":dim.dxf.text="9.9"
    if name=="metadata_and_display":doc.blocks[dim.dxf.geometry].query("MTEXT").first.text="9.9"
    path=root/"case.dxf";doc.saveas(path);before=path.read_bytes()
    result=Runtime(Policy(root=root)).verify_dimensions("case.dxf",[{"id":"hole","handle":dim.dxf.handle,"value":6.4}])
    expected={"control":[],"metadata_only":["dimension_override_mismatch"],"metadata_and_display":["dimension_mismatch"]}[name]
    row_expected=["dimension_mismatch","dimension_override_mismatch"] if name=="metadata_and_display" else expected
    match=result.get("accepted") is (name=="control") and [r["kind"] for r in result.get("findings",[])]==expected and result.get("rows",[{}])[0].get("findings")==row_expected
    cases.append({"case":name,"path":path.relative_to(OUT.parent).as_posix(),"input_sha256":hashlib.sha256(before).hexdigest(),"input_unchanged":before==path.read_bytes(),"response":result,"all_expected":match})
report={"product_sha":args.sha,"imported_from":agentcad.__file__,"source_control":original.relative_to(OUT.parent).as_posix(),"source_control_sha256":hashlib.sha256(original.read_bytes()).hexdigest(),"cases":cases,"all_expected":all(c["all_expected"] and c["input_unchanged"] for c in cases),"scope":"Public saved verification must retain both row-level causes while emitting one primary display finding; metadata-only contradiction remains separately rejected."}
(OUT/("primary-findings-"+label+".json")).write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"product_sha":args.sha,"all_expected":report["all_expected"],"cases":[{"case":c["case"],"accepted":c["response"].get("accepted"),"primary":c["response"].get("findings")} for c in cases]}))
