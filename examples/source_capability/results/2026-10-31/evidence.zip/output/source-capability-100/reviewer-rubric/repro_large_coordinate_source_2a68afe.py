"""Headless same-source precision check: valid large-coordinate control and altered outline."""
import hashlib,json,math,pathlib,sys
OUT=pathlib.Path(r"D:\Projects\AgentCAD-output\source-capability-100\reviewer-rubric")
sys.path.insert(0,str(OUT/"snapshot-2a68afe"/"src"))
import agentcad,ezdxf
from agentcad.policy import Policy
from agentcad.service import Runtime
SHA="2a68afe1f7d0e6de8acaae683606526b51c4daed"
results=[]
for case in ["control","source_outline_one_ulp"]:
    root=OUT/("large-source-2a68afe-"+case);root.mkdir(exist_ok=True)
    rt=Runtime(Policy(root=root))
    assert rt.create_drawing("case.dxf",units="mm")["ok"]
    nominal=17.12345682
    spec={"parts":[{"name":"large coordinate precision","at":[1e8,190],"segments":[{"length":nominal,"d_outer":40}]}]}
    generated=rt.apply_operations("case.dxf",[{"op":"draw_mechanical_assembly","spec":spec}])
    assert generated["ok"],generated
    before=rt.read_engineering("case.dxf","mechanical")
    assert before["ok"] and not before["critique"],before
    doc=ezdxf.readfile(root/"case.dxf")
    body=doc.entitydb[before["parts"][0]["handle"]]
    points=list(body.get_points("xyseb"));oldmax=max(p[0] for p in points);oldmin=min(p[0] for p in points)
    if case!="control":
        body.set_points([(math.nextafter(p[0],math.inf),*p[1:]) if p[0]==oldmax else p for p in points],format="xyseb")
        doc.saveas(root/"case.dxf")
    read=rt.read_engineering("case.dxf","mechanical")
    delivered=rt.deliver_drawing("case.dxf","delivery",formats=["dxf"],strict=True)
    reread=ezdxf.readfile(root/"case.dxf")
    finalpoints=list(reread.entitydb[body.dxf.handle].get_points("xyseb"))
    actual=max(p[0] for p in finalpoints)-min(p[0] for p in finalpoints)
    result={"case":case,"nominal":nominal,"actual_outline_width":actual,
            "nominal_at_8_decimals":f"{nominal:.8f}","actual_at_8_decimals":f"{actual:.8f}",
            "coordinate_ulp":math.ulp(oldmax),"original_width":oldmax-oldmin,
            "read":read,"delivery":delivered,"file_sha256":hashlib.sha256((root/"case.dxf").read_bytes()).hexdigest()}
    (root/"result.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    results.append(result)
(OUT/"large-coordinate-source-2a68afe.json").write_text(json.dumps({"product_sha":SHA,"imported_from":agentcad.__file__,"cases":results},indent=2)+"\n",encoding="utf-8")
print(json.dumps({"product_sha":SHA,"cases":[{"case":r["case"],"nominal":r["nominal_at_8_decimals"],"actual":r["actual_at_8_decimals"],"critique":r["read"].get("critique"),"delivery_ok":r["delivery"]["ok"]} for r in results]}))
