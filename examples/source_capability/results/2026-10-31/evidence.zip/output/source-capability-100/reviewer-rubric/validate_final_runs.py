"""Independently verify completed native/CI/v8 evidence against pinned Git source."""
import argparse,datetime,hashlib,io,json,pathlib,subprocess,tarfile,xml.etree.ElementTree as ET
parser=argparse.ArgumentParser();parser.add_argument("sha");parser.add_argument("ci_run");parser.add_argument("--native-only",action="store_true");args=parser.parse_args()
BASE=pathlib.Path(r"D:\Projects\AgentCAD-output\source-capability-100")
REPO=pathlib.Path(r"D:\Projects\AgentCAD")
WORK=pathlib.Path(r"D:\Projects\AgentCAD-wt\source-capability-100")
PRO=pathlib.Path(r"D:\Projects\AgentCAD-output\autocad-benchmark-20261030\upstream")
label=args.sha[:7]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def load(path):return json.loads(path.read_text(encoding="utf-8"))
def git(repo,*params):return subprocess.check_output(["git","-C",str(repo),*params])
def junit(path):
    cases={};skips=[]
    for e in ET.parse(path).iter("testcase"):
        key=e.get("classname","")+"::"+e.get("name","");assert key not in cases,key
        failed=e.find("failure") is not None or e.find("error") is not None
        skip=e.find("skipped")
        status="failed" if failed else "skipped" if skip is not None else "passed"
        cases[key]=status
        if skip is not None:skips.append({"id":key,"reason":skip.get("message") or skip.text})
    counts={s:sum(v==s for v in cases.values()) for s in ("passed","skipped","failed")}
    assert counts["failed"]==0
    return {"path":path.relative_to(BASE).as_posix(),"sha256":sha(path),"collected":len(cases),"counts":counts,"skips":skips,"case_status":cases}

env_path=BASE/("windows-native-"+label+".environment.json")
env=load(env_path)
assert env["product_commit"]==args.sha and env["exit_code"]==0 and env["source_unchanged"] is True
native_path=BASE/("windows-native-"+label+".xml")
native=junit(native_path)
for suffix,h in env["artifacts"].items():assert sha(BASE/("windows-native-"+label+suffix))==h
assert all("cadquery" in s["reason"].lower() for s in native["skips"]),native["skips"]
local_v8_path=BASE/("v8-"+label)/"report.json";v8=load(local_v8_path)
assert v8["git_sha"]==v8["manifest"]["server_sha"]==v8["adapter_metadata"]["product_sha"]==args.sha
assert v8["manifest"]["dirty"] is False and v8["adapter_metadata"]["product_dirty"] is False
assert env["source_sha256"]==v8["manifest"]["source_sha256"]==v8["adapter_metadata"]["source_sha256"]
for k in ("ezdxf","mcp","pypdf"):
    assert v8["adapter_metadata"]["server_environment"]["dependencies"][k]==env["dependencies"][k]

archive=git(REPO,"archive",args.sha,"src");blobs={}
with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
    for member in tar.getmembers():
        if member.isfile():
            materialized=tar.extractfile(member).read()
            blob=git(REPO,"show",args.sha+":"+member.name)
            assert materialized==blob or materialized.replace(b"\r\n",b"\n")==blob.replace(b"\r\n",b"\n"),member.name
            blobs[member.name]=blob
expected_python={p for p in blobs if p.endswith(".py")}
assert set(env["source_sha256"])==expected_python
sources=[]
for path,h in env["source_sha256"].items():
    raw=(WORK/path).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==h,path
    assert raw.replace(b"\r\n",b"\n")==blobs[path],path
    sources.append({"path":path,"runtime_raw_sha256":h,"git_lf_content_sha256":hashlib.sha256(blobs[path]).hexdigest(),"identity_after_newline_normalization":True})
adapter=WORK/"examples/autocad_benchmark/run.py"
assert sha(adapter)==v8["manifest"]["adapter_sha256"]
assert adapter.read_bytes().replace(b"\r\n",b"\n")==git(REPO,"show",args.sha+":examples/autocad_benchmark/run.py")
assert sha(WORK/"uv.lock")==env["uv_lock_sha256"]

if args.native_only:
    result={"product_sha":args.sha,"validated_at_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"passed":True,
        "source_binding":{"file_count":len(sources),"files":sources,"note":"Exact runtime bytes checked against environment and local v8 source binding; fixed Git identity checked after CRLF-only normalization."},
        "native_environment_path":env_path.relative_to(BASE).as_posix(),"native_environment_sha256":sha(env_path),"native":native,"skips_are_passes":False,
        "scope":"Completed native full-run and source/dependency provenance only. CI completion, complete v8 evaluator verification, visual/showcase and version performance are still separately required."}
    (BASE/"reviewer-rubric"/("native-run-validation-"+label+".json")).write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({"product_sha":args.sha,"passed":True,"native":native["counts"],"collected":native["collected"],"source_files":len(sources),"scope":"native-only"}))
    raise SystemExit(0)

ci_api=load(BASE/"reviewer-rubric"/("ci-run-"+args.ci_run+".json"))
assert ci_api["run"]["head_sha"]==args.sha and ci_api["run"]["status"]=="completed" and ci_api["run"]["conclusion"]=="success"
assert len(ci_api["jobs"])==4 and all(j["status"]=="completed" and j["conclusion"]=="success" for j in ci_api["jobs"])
lanes=[junit(p) for p in sorted((BASE/("ci-"+label)).glob("*/pytest.xml"))]
assert len(lanes)==4
for lane in lanes:
    lane["same_test_ids_as_native"]=set(lane["case_status"])==set(native["case_status"])
    assert lane["same_test_ids_as_native"]

ci_v8_path=BASE/("ci-"+label)/"evidence-ubuntu-latest-py3.12/v8/report.json"
ci_v8=load(ci_v8_path)
assert ci_v8["manifest"]["adapter_sha256"]==hashlib.sha256(git(REPO,"show",args.sha+":examples/autocad_benchmark/run.py")).hexdigest()
for p,h in ci_v8["manifest"]["source_sha256"].items():assert h==hashlib.sha256(blobs[p]).hexdigest(),p
assert set(ci_v8["manifest"]["source_sha256"])==expected_python
v8_rows=[]
for path,report in ((local_v8_path,v8),(ci_v8_path,ci_v8)):
    assert report["summary"]["attempted"]==report["summary"]["passed"]==31
    assert len(report["results"])==31 and all(r["status"]=="pass" and r["score"]==100 for r in report["results"])
    evaluator=report["manifest"]["evaluator"]
    assert evaluator["server_sha"]=="58a05ddfc34a9832c626e82cd88ecdce8e16a62a" and evaluator["dirty"] is False
    fixtures=[]
    for f in evaluator["fixtures"]:
        local=(PRO/f["path"]).read_bytes()
        fixed=git(PRO,"show",evaluator["server_sha"]+":"+f["path"])
        assert local.replace(b"\r\n",b"\n")==fixed
        assert f["sha256"] in {hashlib.sha256(local).hexdigest(),hashlib.sha256(fixed).hexdigest()}
        fixtures.append({"path":f["path"],"reported_sha256":f["sha256"],"git_lf_content_sha256":hashlib.sha256(fixed).hexdigest(),"matches_pinned_source":True})
    v8_rows.append({"path":path.relative_to(BASE).as_posix(),"sha256":sha(path),"product_git_sha_recorded":report["git_sha"],"source_identity_matches_candidate":True,"summary":report["summary"],"evaluator_fixtures":fixtures,
                    "scope":"Headless MCP stdio; independent adapter; not official leaderboard certification."})

result={"product_sha":args.sha,"validated_at_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"passed":True,
    "source_binding":{"file_count":len(sources),"files":sources,"note":"Runtime hashes are exact local bytes. Git identity is checked after CRLF-to-LF normalization; this does not substitute different source logic."},
    "native_environment_path":env_path.relative_to(BASE).as_posix(),"native_environment_sha256":sha(env_path),"native":native,
    "ci_run_url":ci_api["run"]["html_url"],"ci_lanes":lanes,"v8":v8_rows,"skips_are_passes":False,
    "scope":"Completed test/provenance verification only; final source-capability scoring also requires source review, native showcase and version comparison."}
target=BASE/"reviewer-rubric"/("final-run-validation-"+label+".json")
target.write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"product_sha":args.sha,"passed":True,"native":native["counts"],"collected":native["collected"],"ci":[r["counts"] for r in lanes],"v8_passed":[r["summary"]["passed"] for r in v8_rows]}))
