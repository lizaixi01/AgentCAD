"""Public displayed-value requirements on the same generic DXF inputs used for both products."""
import argparse,hashlib,json,pathlib,sys
parser=argparse.ArgumentParser();parser.add_argument("sha");args=parser.parse_args()
OUT=pathlib.Path(r"D:\Projects\AgentCAD-output\source-capability-100\reviewer-rubric")
sys.path.insert(0,str(OUT/("snapshot-"+args.sha[:7])/"src"))
import agentcad
from agentcad.policy import Policy
from agentcad.service import Runtime
rows=[]
for case,value,expected in [("control",6.4,True),("rounded_at_creation",6.4,False),("rounded_at_creation",6.0,True)]:
    root=OUT/("agent-generic-initial-"+args.sha[:7]+"-"+case)
    path=root/"case.dxf";before=path.read_bytes()
    requirements=[{"type":"dimension","kind":"diameter","value":value}]
    response=Runtime(Policy(root=root)).validate_drawing("case.dxf",requirements=requirements,use_stored_spec=False,detail=True)
    assert response["ok"],response
    actual=response["validation"]["requirements"][0]
    assert (actual["status"]=="pass")==expected,response
    assert path.read_bytes()==before
    rows.append({"case":case,"requested_displayed_value":value,"expected_pass":expected,
        "file_sha256":hashlib.sha256(before).hexdigest(),"response":response})
result={"product_sha":args.sha,"imported_from":agentcad.__file__,"scope":"Public validate_drawing dimension requirement uses displayed value, while verify_dimensions separately binds physical value and flags display disagreement.","cases":rows,"all_expected_behavior":True}
(OUT/("generic-requirement-semantics-"+args.sha[:7]+".json")).write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"product_sha":args.sha,"all_expected_behavior":True,"cases":[{"case":r["case"],"requested_displayed_value":r["requested_displayed_value"],"requirement":r["response"]["validation"]["requirements"][0]} for r in rows]}))
