"""Assemble the independent fixed-version review; never edit product/old results."""
from __future__ import annotations

import copy
import hashlib
import io
import json
import pathlib
import subprocess
import zipfile
from datetime import datetime, timezone

BASE = pathlib.Path(r"D:\Projects\AgentCAD-output\source-capability-100")
OUT = BASE / "reviewer-rubric"
REPO = pathlib.Path(r"D:\Projects\AgentCAD")
PRO_REPO = pathlib.Path(r"D:\Projects\AgentCAD-output\autocad-benchmark-20261030\upstream")
AGENT_SHA = "66991092973496b148da45b1f847ddb1a8b4999d"
PRO_SHA = "58a05ddfc34a9832c626e82cd88ecdce8e16a62a"
OLD_COMMIT = "69c1425a2dd7465f6f8c092033447b608554a8a3"
OLD_PREFIX = "examples/source_capability/results/2026-10-30/"
OLD_ASSESSMENT_SHA = "760521504a260f31472e3b1945a3f40bc72587d13d9ee0bc2c57f6df5f727ddf"
OLD_ZIP_SHA = "1d2889cf18d66faf3c3a4633ef5e49ae0d5ed29a22aa3a7f1d4834683165de3e"
RUBRIC_SHA = "be562004ba7f25c0d131cdf690c9dc4844cd0df9dc3ede467ae2308420d1d52e"


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read(rel: str):
    return json.loads((BASE / rel).read_text(encoding="utf-8-sig"))


def write(path: pathlib.Path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")


_blobs = {}


def blob(repo: pathlib.Path, sha: str, path: str) -> bytes:
    key = (str(repo), sha, path)
    if key not in _blobs:
        _blobs[key] = subprocess.check_output(["git", "-C", str(repo), "show", f"{sha}:{path}"])
    return _blobs[key]


def index_entry(rel: str):
    path = BASE / rel
    assert path.is_file(), rel
    assert path.resolve().is_relative_to(BASE.resolve()), rel
    data = path.read_bytes()
    return {"path": rel, "bytes": len(data), "sha256": digest(data)}


def main():
    pending_path = OUT / "assessment.pending.json"
    pending_raw = pending_path.read_bytes()
    assessment = json.loads(pending_raw.decode("utf-8-sig"))
    stamp = datetime.now(timezone.utc).isoformat()
    run = read("reviewer-rubric/final-run-validation-6699109.json")
    headless = read("reviewer-rubric/independent-headless-validation-6699109.json")
    native_angles = read("reviewer-rubric/native-angles-ci-artifacts-6699109.json")
    show_perf = read("reviewer-rubric/showcase-performance-validation-6699109.json")
    visual = read("reviewer-rubric/visual-review-6699109.json")
    inheritance = read("reviewer-rubric/inherited-boundaries-6699109.json")
    ci = read("reviewer-rubric/ci-run-41101708770.json")
    for report in (run, headless, native_angles, show_perf):
        assert report["passed"] is True and report["product_sha"] == AGENT_SHA
    assert visual["product_sha"] == AGENT_SHA and visual["inspected_all_seven"]
    assert visual["required_elements_readable_within_pages"] and len(visual["observations"]) == 7
    assert run["native"]["counts"] == {"passed": 815, "skipped": 8, "failed": 0}
    assert run["native"]["collected"] == 823
    assert len(run["ci_lanes"]) == 4 and all(x["same_test_ids_as_native"] for x in run["ci_lanes"])
    assert all(x["summary"]["passed"] == 31 and x["source_identity_matches_candidate"] for x in run["v8"])
    assert ci["run"]["conclusion"] == "success" and len(ci["jobs"]) == 4
    assert all(j["conclusion"] == "success" for j in ci["jobs"])
    assert show_perf["performance"]["observations"] == 24 and show_perf["performance"]["all_correctness_passed"]
    assert show_perf["showcase"]["public_runtime_calls"] == 40
    assert all(v == "passed" for v in show_perf["showcase"]["checks"].values())

    rubric = blob(REPO, AGENT_SHA, "docs/source-capability-rubric.md")
    assert digest(rubric) == RUBRIC_SHA
    old_assessment = blob(REPO, OLD_COMMIT, OLD_PREFIX + "assessment.json")
    old_zip = blob(REPO, OLD_COMMIT, OLD_PREFIX + "evidence.zip")
    assert digest(old_assessment) == OLD_ASSESSMENT_SHA and digest(old_zip) == OLD_ZIP_SHA
    old_local = pathlib.Path(r"D:\Projects\AgentCAD-output\source-capability\reviewer-rubric\assessment.json")
    assert digest(old_local.read_bytes()) == OLD_ASSESSMENT_SHA

    assessment["status"] = "final_local_assessment"
    assessment["finalized_at_utc"] = stamp
    assessment["reviewed_at"] = "2026-10-31"
    assessment["review_timezone"] = "Asia/Shanghai"
    assessment["assessor"]["display_name"] = "independent AI reviewer, requested/published by AgentCAD"
    assessment["pending_evidence"] = []
    assessment["method"]["frozen_rubric_sha256_basis"] = (
        "SHA256 of the LF repository blob returned by git show " + AGENT_SHA +
        ":docs/source-capability-rubric.md; not the CRLF working-tree bytes."
    )
    assessment["publication_boundary"]["assessed_revision_only"] = (
        "AgentCAD 66991092973496b148da45b1f847ddb1a8b4999d and Pro " + PRO_SHA +
        ". Later main merges, integration runs and documentation publication commits are not relabeled as the measured product."
    )
    assessment["consistency_notes"].extend([
        "The identical initial-render DIMDEC counterexample was also found in AgentCAD 760a2c2 generic verification. C2 was capped there as well; the final score follows repair and independent same-byte replay, not an exemption for AgentCAD.",
        "Pro's new local 93 happens to equal its historical upstream v1.6.0 self-review 93. They differ in revision, assessor, point anchors and deduction reasons, and remain separate records.",
        "Reaching 5 requires the complete cumulative anchors, not merely documenting a limit or closing a bug. Final native, cross-interface, structurally different non-benchmark and same-version evidence supplies those anchors here.",
        "The historical AgentCAD 98 / Pro 96 assessment and evidence ZIP were rehashed unchanged. Pro's exact source remains the same; the newly reproduced C2 failure changes this round's assessment, not the old record."
    ])
    assessment["review_limitations"].extend([
        "AgentCAD non-decimal angular display formats are explicitly unverifiable without a unit-aware parser. General two-line angular anchor binding remains unsupported; decimal measurement/display checks and cache-independent native regeneration are separately verified.",
        "AgentCAD drawing templates use caller-controlled placement and supplied nominal dimensions. Unspecified tolerances, hole depths, finish and manufacturing process are not inferred. No universal layout or shop-release certification is awarded.",
        "Native witness PDFs are AgentCAD headless renderings of real AutoCAD saved/reopened/activated DXF, not output of Autodesk's PDF plot driver. Inactive viewport activation is an explicit workflow step.",
        "Eight local skips are unavailable CadQuery cases. Installed AutoCAD and FreeCAD paths actually ran; headless CI results do not establish native CAD support on Linux/macOS.",
        "Legacy marker recovery deliberately refuses until old writers are closed and the marker is handled manually offline. Modern OS locking/crash recovery is verified. Trusted opt-in scripts are not a hostile-code sandbox."
    ])

    agent, pro = assessment["products"]
    assert agent["product_sha"] == AGENT_SHA and pro["product_sha"] == PRO_SHA
    ai = {i["id"]: i for i in agent["items"]}
    pi = {i["id"]: i for i in pro["items"]}
    common = ["reviewer-rubric/boundary-trace-6699109.json", "reviewer-rubric/final-run-validation-6699109.json"]
    native = ["windows-native-6699109.xml", "windows-native-6699109.environment.json", "reviewer-rubric/native-run-validation-6699109.json"]
    showcase = ["showcase-6699109/report.json", "reviewer-rubric/showcase-performance-validation-6699109.json", "reviewer-rubric/visual-review-6699109.json", "reviewer-rubric/visual-inputs-6699109.json"]
    current = {
        "F1": ["reviewer-rubric/native-angles-ci-artifacts-6699109.json"] + native,
        "F2": native,
        "F3": ["reviewer-rubric/generic-default-render-6699109.json", "reviewer-rubric/angular-precision-6699109.json", "reviewer-rubric/native-angles-ci-artifacts-6699109.json"] + native + showcase,
        "F4": native + showcase,
        "F5": native + showcase,
        "C1": ["reviewer-rubric/legacy-lock-race-6699109.json", "reviewer-rubric/legacy-lock-refusal-6699109.json"] + native,
        "C2": ["reviewer-rubric/inherited-boundaries-6699109.json", "reviewer-rubric/agent-generic-initial-precision-6699109.json", "reviewer-rubric/generic-requirement-semantics-6699109.json", "reviewer-rubric/generic-parser-boundaries-6699109.json", "reviewer-rubric/angular-precision-6699109.json", "reviewer-rubric/primary-findings-6699109.json", "reviewer-rubric/independent-headless-validation-6699109.json"] + [r["path"] for r in inheritance["inherited_completed_headless_reports"]] + native + showcase,
        "C3": ["reviewer-rubric/inherited-boundaries-6699109.json", "reviewer-rubric/xrecord-parity-counterexample-953c3f0.json"] + native + showcase,
        "C4": native,
        "B1": native,
        "B2": ["reviewer-rubric/native-angles-ci-artifacts-6699109.json"] + native + showcase,
        "B3": ["reviewer-rubric/ci-run-41101708770.json", "reviewer-rubric/ci-checkout-tree-6699109.json", "reviewer-rubric/native-angles-ci-artifacts-6699109.json", "verification-summary-6699109.json", "ci-source-parity-6699109.json"] + native,
        "E1": ["reviewer-standards/standards-review.txt", "reviewer-standards/implementation-review.txt", "reviewer-standards/evidence-manifest.json"] + showcase,
        "E2": ["reviewer-rubric/inherited-boundaries-6699109.json", "reviewer-rubric/all-view-source-counterexamples-953c3f0.json", "reviewer-rubric/coordinate-source-counterexamples-953c3f0.json"] + native + showcase,
        "E3": native + showcase,
        "T1": ["reviewer-rubric/independent-headless-validation-6699109.json", "reviewer-pr44-r10/evidence.json", "reviewer-pr44-r10/headless.xml", "reviewer-pr44-r10/verdict.md"] + native,
        "T2": ["reviewer-rubric/independent-headless-validation-6699109.json", "reviewer-rubric/ci-checkout-tree-6699109.json", "reviewer-rubric/native-angles-ci-artifacts-6699109.json", "ci-source-parity-6699109.json", "v8-6699109/report.json"] + native + showcase,
        "T3": ["reviewer-rubric/ci-run-41101708770.json", "reviewer-rubric/ci-checkout-tree-6699109.json", "reviewer-rubric/native-angles-ci-artifacts-6699109.json", "v8-6699109/report.json", "ci-6699109/evidence-ubuntu-latest-py3.12/v8/report.json", "performance-6699109/report.json", "reviewer-rubric/showcase-performance-validation-6699109.json"],
        "S1": native,
        "S2": ["reviewer-rubric/legacy-lock-race-6699109.json", "reviewer-rubric/legacy-lock-refusal-6699109.json"] + native,
    }
    final_bases = {
        "F1": "Saved geometry is measured independently: analytic arc/bulge lengths and areas, nested HATCH island/style semantics, primitives, offsets and selection predicates have positive and negative cases beyond v8. Final native exchange supplements headless checks. For two-line angular dimensions, a real AutoCAD run regenerated four sectors after removing both cached graphics and actual_measurement; the saved 36.87/143.13 degree displays agree with independent atan2 geometry.",
        "F2": "Transforms, arrays, trims/joins/corners, requirement edits, tagged identity and revision-sensitive previews have saved-file assertions. Stale revision, external change and failed edits preserve the documented file state. The boundary was traced from the prior review and the final fixed-source process/interface/native regression completes its current workflow evidence.",
        "F3": "Real dimensions carry numerical deviations/limits/fits, with precision-loss, nonfinite and fake-nominal refusals. Saved rendered-text checks include independent tolerance edits and final native roundtrip. The default rotated dimension now saves 45.98 at DIMDEC2 and 45.981 after a public redraw at DIMDEC3 while native DIMRND stays zero. Degree precision is independent of linear fractional units. The final seven rendered sheets and cache-independent native angular regeneration confirm actual display, not just style metadata.",
        "F4": "Layers, blocks/attributes, paper/model layouts, viewports/pages and DXF/DWG/print/table exchange have reopened postconditions. Two final A3 mechanical witnesses retain 420 x 297 mm paper, viewport geometry/scale/center and paper-space text through actual AutoCAD save/reopen/activation. Supported metadata is preserved by saved parity checks.",
        "F5": "P&ID graph, mechanical views/BOM, architectural rooms/openings and foreign plant takeoff have public entry points, saved readback, non-benchmark cases and final native examples. Foreign interpretation retains open items/confidence rather than inventing missing lengths or tags. Code-boundary tracing plus the final full run preserves prior foreign-network controls.",
        "C1": "Failed batches, previews, revision conflicts, checkpoints/undo and recovery have saved-document/workspace postconditions. Public interface and real child-process exclusion checks exercise failures beyond in-process happy paths. New legacy-marker refusal preserves both marker and drawing bytes; modern normal writing still succeeds. This corroborates transaction state without double-deducting the former S2 recovery race.",
        "C2": "Mechanical source geometry across every supplied view, required annotation roles, owner spaces, definitions, display settings and saved graphics are checked separately. Prior omission/rounding/geometry/XRECORD boundary failures were kept and replayed after repair. Generic verification reads visible saved primary text: the exact Pro 6.4-versus-rendered-6 bytes are rejected, the genuine 6.4 control passes, and explicit display requirements use their own tolerance. Same-byte numeric-suffix/fraction/tolerance and decimal-angle counterexamples now reject tampering while valid controls pass. Final native and cross-interface runs complete the evidence; unsupported or ambiguous display is not silently inferred from geometry.",
        "C3": "Delivery gates bind source version/hash and read back saved artifacts with explicit format scope. Supported DXF semantic snapshots include entity-owned extension dictionaries/XRECORDs recursively as well as layouts/blocks/styles/root metadata. The injected post-export XRECORD corruption that previously passed now fails parity while the valid control succeeds; source equivalence justifies inheriting that completed mechanical replay. Final native/showcase delivery records corroborate the full workflow. Generic displayed-value defects are assigned to C2, not deducted again here.",
        "C4": "Malformed drawings, unknown units/operations, unsupported entities/features, source mutation and incomplete metadata have behavioral refusals or open items. The previously failing load-without-tag case returns null tag/length and ELECTRICAL_TAG_MISSING. Current generic missing/hidden/ambiguous display and unsupported angular-format cases refuse explicit certification. Final full regression and the traced prior foreign-input boundaries support these outcomes.",
        "B1": "Backend discovery, dependency failures and capability refusals are explicit. AutoCAD binary DXF intermediates preserve database doubles while public workspace commits stay text; final enabled native cases include fine dimensions at large coordinates. FreeCAD completion now drains trailing progress output; deterministic completion-race tests and actual enabled final FreeCAD regression both pass. Distinctive 3D capabilities do not change the category weight.",
        "B2": "Final actual AutoCAD save/read/AUDIT checks cover two mechanical variants, architecture, P&ID and numerical tolerances with recorded zero audit errors. Two A3 witnesses verify paper size, viewport scale/center and paper-space text after native reopening/activation. Independent read-only inspection of fresh native angular output confirms regeneration from inputs without graphics/measurement caches. All seven final PDFs were independently rendered and visually inspected.",
        "B3": "Four completed CI lanes cover Windows3.11, Linux3.10/3.12 and macOS3.12; the local Windows run enables installed AutoCAD and FreeCAD. All five lanes collect the same 823 test IDs, with skips retained explicitly. CI actually checked out merge e26b82c13eae7eacfd3b0464abe3dfd05849acd0, whose complete tree matches assessed 6699109. Artifact ZIP digests match GitHub and all 103 extracted files match the records used.",
        "E1": "The prior M14 gap is closed with GOST12876-67 Figure4/Table4 D=24 and t=15, including the applicable amendment, independently checked against the source table. Code changes depth14.6 to15; the15.5 through hole retains separate ISO273 medium-clearance attribution. Bounded fits/fastener/bearing evidence remains traced. The final variant drawing visibly identifies the mixed nominal references; no complete-standard conformity is inferred.",
        "E2": "The supplied-model drawing now includes every supplied segment/overall length, outer/bore diameter and hole-pattern count/diameter/PCD/spacing/orientation, alongside views/section, frame, BOM and balloons. Two structurally different final mechanical specifications, saved native witnesses, precision/owner/all-view tamper controls and complete final regression were checked. Independent visual inspection of all seven final PDFs confirms legible nominal dimensions/notes and unclipped page content. This supplies the former missing E2 workflow evidence, not merely an added example patch.",
        "E3": "Room areas, P&ID connections, BOM/balloon consistency and foreign quantities are read back from actual drawing content; deletion, movement or disconnection causes failure or uncertainty. Prior independently reproduced ARC/chord and missing-tag failures are repaired, with sweep/endpoint/label controls and unchanged traced foreign-network code. Final native architecture/P&ID/mechanical cases corroborate the domain loop.",
        "T1": "Behavioral evidence covers geometry, public CLI/MCP/HTTP, child-process locks/cancellation, native exchange and adversarial saved delivery/tampering. Final complete fixed-source native/CI runs are supplemented by independent same-byte counterexamples, source inheritance checks and visual review. Earlier failures and harness-development mistakes remain identifiable; a large passing count does not override a demonstrated defect.",
        "T2": "Dependency lock, fixed product/evaluator SHAs, environment/import boundaries, source/harness hashes, raw inputs/responses/logs and generated-documentation checks make the recorded workflows reproducible. Native/local-v8 hashes match the evaluated Python sources, independent snapshot validation covers all75 source/static files, and CI's entire merge tree is equivalent. Four original CI ZIPs match GitHub digests and103 unpacked files. LF Git content versus Windows raw CRLF is recorded explicitly. Old assessment/archive hashes remain unchanged.",
        "T3": "Completed four-lane CI, original v8 local/CI 31-of-31 results and an effective failure gate accompany a fixed-candidate same-interpreter/dependency version comparison. All24 observations, including one excluded warmup and five timed repetitions per version/size, pass saved geometry/count/units/audit checks. The prior 953 v8 failure and interrupted full run remain historical, not silently promoted to passes.",
        "S1": "Default workspace/path, read-only and operation scopes are enforced; dangerous CAD/script execution is opt-in. Actual HTTP requests check authentication, origin/host, framing/input and no-write postconditions, including abrupt Windows reset recovery. Newly merged installation HTTP routes were read and included in final regression; separate boundary tracing prevents inheriting old conclusions blindly.",
        "S2": "Modern OS locks, child-process contention, cancellation, timeouts, checkpoints and crash recovery have saved-state/observable outcomes. The newly merged automatic legacy-marker deletion race was independently reproduced and removed: identical scheduling, live/exited/invalid marker controls now refuse without deleting or writing, while normal modern writes pass. FreeCAD trailing completion events are drained and covered by deterministic plus real native checks. Final fixed-source process/native regression completes this boundary.",
    }
    for item_id, item in ai.items():
        item["basis"] = final_bases[item_id]
        item["score"] = 5
        item["deduction"] = {"points": 0, "reason": "The cumulative 0..5 evidence anchors are met within the stated useful contract; no unresolved serious point-limiting defect was established after the recorded fixes and retests."}
        item["evidence_paths"] = sorted(set(common + current[item_id]))
        item["historical_evidence_use"] = "Prior evidence is corroborating only through the fixed source trace; final changed workflows are supported by current evidence_paths. Historical failures are not counted as passes."
    ai["F3"]["scope_and_limits"] += " Non-decimal angular formats without a unit-aware parser are explicitly unverified; decimal-degree measurement/display and native regeneration are the verified angular boundary."
    ai["C2"]["scope_and_limits"] = "Unsupported/ambiguous binding or display remains refusal/unknown. Generic precision rounding is allowed for ordinary integrity, but an explicit value requirement uses actual displayed text and its own tolerance. General two-line angular anchor binding is not claimed. This does not certify every imported entity's intent."
    ai["E1"]["scope_and_limits"] = "Only the listed nominal dimensions and mixed sources are credited. H14, chamfer, corner radius and other manufacturing clauses are outside the explicitly simplified2D symbol. Unknown/range-excluded rows refuse; no complete GOST/DIN or manufacturing certification is awarded."
    ai["T3"]["scope_and_limits"] = "AgentCAD baseline69c1425a2dd7465f6f8c092033447b608554a8a3 versus candidate6699109, direct Runtime on2000/10000 2D lines with saved validation/DXF reopen. Total medians2.8235252->2.8692118s and53.7182804->48.6221365s; ratios1.0161807 and0.9051320. This is not a Pro, native CAD, MCP or model-latency comparison and establishes no universal speed advantage."
    ai["S2"]["scope_and_limits"] = "Old marker files require closing legacy writers and manual offline handling; no automatic proof of a non-cooperating legacy writer's absence is claimed. Not every thread can be forcibly killed. Timeout/quarantine/recovery behavior is not hostile-process containment."
    ai["E1"]["resolved_finding"] = "Prior E1=4 lacked a verified source for the M14 depth. The source was located and independently checked, the recorded depth was corrected to15, and the final drawing/readback shows the corrected bounded nominal value."
    ai["E2"]["resolved_finding"] = "Prior E2=4 omitted critical dimensions already supplied by the model. The final workflow generates and verifies those dimensions across all supplied views; two distinct native-witness examples and saved tamper controls support the higher anchor. Unspecified manufacturing data remains outside the claim."

    pro_scores = {"F3": 4, "C2": 2, "T3": 4, "S1": 3}
    for item_id, item in pi.items():
        item["score"] = pro_scores.get(item_id, 5)
        item["deduction"] = copy.deepcopy(item["prior_deduction"])
        item["historical_evidence_use"] = "The assessed Pro source remains exactly58a05dd; pinned public source/results and the prior archived independent review retain their boundary. Newly reproduced C2 behavior changes this round's judgment only."
    pi["C2"]["deduction"] = {
        "points": 3,
        "reason": "Serious false-success cap at 2. A 6.4 mm circle with DIMDEC=0 set before the first and only render has actual visible MTEXT %%c6. Both verify_requirements and saved verify_artifact accept it as displayed 6.4 with mismatch=false; DIMDEC=1 / actual %%c6,4 is the passing control. binding._displayed infers measurement * DIMLFAC instead of reading saved rendered text. This is initial-render verification, not the separate F3 post-style-edit rerender gap. The identical byte input exposed the same AgentCAD bug before its repair; the same cap was applied until independent replay passed."
    }
    pi["C2"]["evidence_paths"] += ["reviewer-rubric/agent-generic-initial-precision-760a2c2.json", "reviewer-rubric/agent-generic-initial-precision-6699109.json", "reviewer-rubric/generic-requirement-semantics-6699109.json"]
    pi["C2"]["scope_and_limits"] = "A headless saved-DXF false-success within the declared dimension-selected requirement workflow. No new Pro AutoCAD execution or claim that all requirements fail. Actual6.4 control passes; a dimension in an unused block is correctly rejected. The defect's responsible item is C2; it is not also deducted from C3 or E2."
    pi["F3"]["scope_and_limits"] = "Numeric style edits and explicit rerender_required reporting work. Existing rendered DIMENSION blocks are left unchanged after headless dimstyle_modify, so actual post-edit display completion does not reach5. This does not cause the initial-render C2 counterexample."
    pi["T3"]["scope_and_limits"] = "Published same-host performance evidence is for efd33d0, before17 source-changing commits to the assessed58a05dd. Completed current correctness CI exists, but no performance rerun across the exact final product boundary was found. No speed inferiority is asserted."
    pi["S1"]["scope_and_limits"] = "Configured path/auth/bind guards are credited. Empty default allowed_paths and available raw command/LISP denylist leave default scope incomplete, and located HTTP tests do not demonstrate actual request rejection with saved no-write outcomes. No demonstrated exploit is asserted."

    # Remove stale/duplicated AgentCAD line numbers, then anchor current symbols.
    anchors = {
        "src/agentcad/geom.py": (102, "def angular_sector"),
        "src/agentcad/model.py": (242, "def measure_dimension"),
        "src/agentcad/dimension_display.py": (105, "def read_display"),
        "src/agentcad/verification.py": (31, "def verify_dimensions"),
        "src/agentcad/ops/annotate.py": (99, "def render_dimension"),
        "src/agentcad/tolerances.py": (19, "def apply_tolerance"),
        "src/agentcad/locking.py": (43, "def refuse_legacy_marker"),
    }
    extra_sources = {
        "F1": ["tests/test_generic_native_dimension.py"],
        "F3": ["src/agentcad/ops/edit.py", "src/agentcad/model.py", "tests/test_dimension_display.py"],
        "B1": ["tests/test_freecad_progress.py"],
        "S1": ["src/agentcad/setup_gui.py", "tests/test_setup_gui.py"],
        "S2": ["src/agentcad/locking.py", "tests/test_freecad_progress.py"],
    }
    # Optional test-name additions are only included if they exist in the fixed tree.
    agent_paths = set(subprocess.check_output(["git", "-C", str(REPO), "ls-tree", "-r", "--name-only", AGENT_SHA], text=True).splitlines())
    for item_id, paths in extra_sources.items():
        for path in paths:
            if path in agent_paths:
                ai[item_id]["source"].append({"path": path})
    for product, repo in ((agent, REPO), (pro, PRO_REPO)):
        product["status"] = "final_local_assessment"
        for item in product["items"]:
            sources = {}
            for source in item["source"]:
                source = dict(source)
                path = source["path"]
                data = blob(repo, product["product_sha"], path)
                if product is agent:
                    source.pop("line", None)
                    if path in anchors:
                        line, prefix = anchors[path]
                        assert data.decode("utf-8-sig").splitlines()[line - 1].startswith(prefix)
                        source["line"] = line
                if "line" in source:
                    assert 1 <= source["line"] <= len(data.splitlines())
                source["url"] = f"https://github.com/{product['repository']}/blob/{product['product_sha']}/{path}"
                if "line" in source:
                    source["url"] += f"#L{source['line']}"
                sources[(path, source.get("line"))] = source
            item["source"] = list(sources.values())
            item["evidence_paths"] = sorted(set(item["evidence_paths"]))
            assert item["score"] + item["deduction"]["points"] == 5
        for category in product["categories"]:
            category["score"] = sum(i["score"] for i in product["items"] if i["id"] in category["item_ids"])
            assert category["score"] <= category["weight"]
        product["total_score"] = sum(c["score"] for c in product["categories"])
        assert product["total_score"] == sum(i["score"] for i in product["items"])
    assert [agent["total_score"], pro["total_score"]] == [100, 93]
    assert [c["score"] for c in agent["categories"]] == [25, 20, 15, 15, 15, 10]
    assert [c["score"] for c in pro["categories"]] == [24, 17, 15, 15, 14, 8]

    assessment["evidence_summary"] = {
        "status": "complete_for_the_two_pinned_versions",
        "native": {"report": "reviewer-rubric/final-run-validation-6699109.json", "product_sha": AGENT_SHA, "passed": 815, "skipped": 8, "total": 823, "failures": 0, "errors": 0, "duration_seconds": 702.46, "skip_reason": "CadQuery unavailable", "autocad_and_freecad_enabled": True, "source_unchanged_during_run": True},
        "ci": {"url": run["ci_run_url"], "head_sha": AGENT_SHA, "actual_checkout_sha": "e26b82c13eae7eacfd3b0464abe3dfd05849acd0", "complete_tree_equal_to_assessed_product": True, "lanes": [{"path": x["path"], "counts": x["counts"], "collected": x["collected"], "same_test_ids_as_native": x["same_test_ids_as_native"]} for x in run["ci_lanes"]], "original_artifact_digests_verified_against_github": True, "unpacked_files_compared": 103},
        "v8": {"evaluator_sha": PRO_SHA, "local_passed": 31, "local_total": 31, "ci_passed": 31, "ci_total": 31, "gate_passed": True, "independent_adapter": True, "not_converted_to_source_score": True, "reports": [x["path"] for x in run["v8"]]},
        "showcase": {"report": "showcase-6699109/report.json", "public_runtime_calls": 40, "checks_passed": 7, "pdfs_independently_rendered_and_visually_inspected": 7, "visual_review": "reviewer-rubric/visual-review-6699109.json", "native_pdf_boundary": show_perf["showcase"]["native_pdf_boundary"]},
        "performance": copy.deepcopy(show_perf["performance"]),
        "independent_headless": {"snapshot_source_and_static_files": 75, "report": "reviewer-rubric/independent-headless-validation-6699109.json", "boundary_trace": "reviewer-rubric/boundary-trace-6699109.json", "mechanical_replay_inheritance": "reviewer-rubric/inherited-boundaries-6699109.json", "scope": "Fresh same-byte generic display, requirement, angle, default-render and legacy-lock controls; six completed953 mechanical replays inherited only after exact boundary tracing. No native application launched by this reviewer."},
        "native_angle_independent_readback": "reviewer-rubric/native-angles-ci-artifacts-6699109.json",
        "historical_failure_chain": "reviewer-rubric/REVIEW-STATUS.md",
        "independent_pr_review": "https://github.com/lizaixi01/AgentCAD/pull/44#issuecomment-6529726990",
        "quality_metric_distinction": "Final mechanical/variant/tolerance delivery manifests report quality94 with two VIEWPORT warnings; architecture/PID report100. These separate quality metrics are not source-rubric points. Explicit native paper/viewport witnesses and visual inspection support the assessed layout workflow.",
    }
    assessment["source_recheck_inheritance"]["note"] = "Only the six completed independent953 mechanical reports are inherited through exact source/branch analysis. Fresh669 native/CI/v8/showcase/performance results complete the final evidence. Interrupted953 full regression and its failed30/31 v8 are not relabeled."

    # Preserve the journal; append the final disposition after the historical pending notes.
    journal = OUT / "REVIEW-STATUS.md"
    marker = "## 6699109 最终独立定稿（2026-10-31）"
    journal_text = journal.read_text(encoding="utf-8-sig")
    if marker not in journal_text:
        journal.write_text(journal_text.rstrip() + "\n\n" + marker + "\n\n"
            "最终证据已全部完成并独立核验：本机 815 passed / 8 CadQuery skipped、823 IDs；四 CI lane 与本机的 ID 集合一致；CI 实际 checkout e26b82c 的完整 tree 与 6699109 相同；原始四 ZIP 与 GitHub digest、103 个解压文件逐字节一致。本机与 CI 的原始 v8 均 31/31。正式原生展示 40 次公开 Runtime 调用、7 项检查通过；7 份 PDF 已由本评审独立渲染并逐张目视。24 次同环境性能观测均通过正确性检查，2000 条线中位总时长略增、10000 条线下降，不据此声称全面提速。\n\n"
            "缓存和 measurement 都被移除的两线角度输入经实际 AutoCAD 重新生成 36.87/143.13 度，本评审只读原始 native 作业并以独立 atan2 计算核对。所有已知严重缺陷的同字节或同规格控制组/异常组均有修复后证据；早期失败、中断和 pending 草稿原样保留。\n\n"
            "按冻结 20 项累计标准，最终 AgentCAD 100（25/20/15/15/15/10），Pro 同尺新复评 93（24/17/15/15/14/8）。Pro 扣分为 F3 -1、C2 -3、T3 -1、S1 -2；新 C2 与旧 F3 是不同触发边界，不重复扣分。新 Pro 93 与历史上游 v1.6.0 自评 93 只是数值相同，旧本地 98/96 记录保持不变。\n\n"
            "这是 independent AI reviewer, requested/published by AgentCAD 的限定源码能力评估，不是外部第三方认证或官方榜单。100 表示本冻结量表的已评契约均达到 5 分证据锚点，不是所有 CAD 能力、任意输入正确性或制造放行保证。最终文件为 assessment.json、FINAL-REVIEW.md 和 assessment-validation.json。新主线集成提交不替换此处被评 6699109。\n", encoding="utf-8", newline="\n")

    # Explicit current references, raw witnesses and replay scripts. The full archive
    # additionally preserves historical attempts; no old attempt is deleted here.
    refs = {p for product in assessment["products"] for item in product["items"] for p in item["evidence_paths"]}
    refs.update({
        "reviewer-rubric/REVIEW-STATUS.md", "reviewer-rubric/assessment.pending.json", "reviewer-rubric/finalize_assessment.py",
        "reviewer-rubric/ci-artifacts-api-6699109.json", "reviewer-rubric/ci-checkout-tree-6699109.json",
        "reviewer-rubric/ci-run-41101708770.json", "windows-native-6699109.log", "ci-artifact-integrity-6699109.json",
        "verification-summary-6699109.json", "ci-source-parity-6699109.json", "visual-review-6699109.md", "preview-render-6699109.json",
        "reviewer-rubric/validate_final_runs.py", "reviewer-rubric/validate_headless_provenance.py",
        "reviewer-rubric/validate_native_angles_and_ci_artifacts.py", "reviewer-rubric/validate_showcase_performance.py",
        "reviewer-rubric/render_showcase_review.py", "reviewer-rubric/repro_pro_initial_precision.py", "reviewer-rubric/repro_pro_dimension_boundaries.py",
        "reviewer-rubric/repro_agent_generic_initial_precision.py", "reviewer-rubric/repro_generic_requirement_semantics.py",
        "reviewer-rubric/repro_generic_parser_boundaries.py", "reviewer-rubric/repro_generic_default_render.py",
        "reviewer-rubric/repro_primary_findings.py", "reviewer-rubric/repro_angular_precision.py",
        "reviewer-rubric/repro_legacy_lock_race.py", "reviewer-rubric/recheck_legacy_lock_refusal.py",
        "reviewer-rubric/repro_coordinate_source_final.py", "reviewer-rubric/repro_all_view_sources.py",
        "reviewer-rubric/repro_annotation_boundaries_953c3f0.py", "reviewer-rubric/repro_precision_953c3f0.py",
        "reviewer-rubric/repro_fine_geometry_953c3f0.py", "reviewer-rubric/repro_xrecord_delivery_953c3f0.py",
    })
    refs.update(x["path"] for x in run["ci_lanes"])
    for x in show_perf["visual_inputs"]:
        refs.update((x["pdf"], x["image"]))
    for directory in ("ci-raw-6699109", "reviewer-rubric/native-angular-6699109"):
        refs.update(p.relative_to(BASE).as_posix() for p in (BASE / directory).rglob("*") if p.is_file())
    for directory in OUT.iterdir():
        if directory.is_dir() and (directory.name.startswith("pro-initial-check-") or directory.name.startswith("pro-") or directory.name == "angular-precision-6699109"):
            refs.update(p.relative_to(BASE).as_posix() for p in directory.rglob("*") if p.is_file() and p.suffix.lower() in {".dxf", ".json"})
    # The reports record byte hashes for all saved replay inputs; preserve their
    # full directories through the archive policy, rather than flattening them.
    assessment["archive_requirements"] = {
        "primary_current_files": "Every evidence_index path is relative to evidence_path_base and must be included byte-for-byte.",
        "raw_replay_directories": "Keep reviewer-rubric raw case directories, including failed controls/attempts, with their relative layout. Snapshot source is independently reproducible from the fixed Git SHAs.",
        "old_archive": "The unchanged historical_local_review.evidence_zip is a separate required companion for inherited_evidence. Extract both ZIPs side by side, preserving output/source-capability/ and output/source-capability-100/.",
        "native_angle_witnesses": "Original final angular job input/output/script/result/log are copied under reviewer-rubric/native-angular-6699109/ with exact byte hashes; no native application was launched by the reviewer.",
        "external_current_path_dependencies": [],
    }
    assessment["evidence_index"] = [index_entry(p) for p in sorted(refs)]

    # Verify inherited references in the immutable prior ZIP, not a mutable checkout.
    inherited_checks = []
    with zipfile.ZipFile(io.BytesIO(old_zip)) as z:
        names = set(z.namelist())
        inherited_index = {e["path"]: e for e in assessment["inherited_evidence_index"]}
        for rel in sorted({e["path"] for p in assessment["products"] for i in p["items"] for e in i["inherited_evidence"]}):
            zip_path = "output/source-capability/" + rel
            assert zip_path in names, zip_path
            data = z.read(zip_path)
            if rel in inherited_index:
                assert digest(data) == inherited_index[rel]["sha256"], rel
            inherited_checks.append({"path": rel, "zip_path": zip_path, "sha256": digest(data), "present_in_unchanged_old_zip": True})

    # Current summaries must not retain any pending claim or old performance values.
    for p in assessment["products"]:
        for i in p["items"]:
            assert "pending" not in i["basis"].lower(), (p["name"], i["id"])
            assert "a713426 versus b4c0466" not in i["scope_and_limits"]
    write(OUT / "assessment.json", assessment)
    final_md = make_markdown(assessment)
    (OUT / "FINAL-REVIEW.md").write_text(final_md, encoding="utf-8", newline="\n")
    assert pending_path.read_bytes() == pending_raw, "pending draft was altered"

    validation = {
        "schema": "local-source-review-artifact-validation/v1",
        "validated_at_utc": stamp,
        "passed": True,
        "assessed_product_shas": {"AgentCAD": AGENT_SHA, "AutoCAD MCP Pro": PRO_SHA},
        "totals": {p["name"]: {"score": p["total_score"], "categories": {c["id"]: c["score"] for c in p["categories"]}, "items": len(p["items"]), "integer_score_and_deduction_sums_checked": True} for p in assessment["products"]},
        "frozen_rubric_sha256_git_lf_bytes": digest(rubric),
        "fixed_source_references": {"unique_git_blobs_verified": len(_blobs) - 3, "all_paths_exist_at_declared_sha": True, "new_function_anchors_checked_against_source_lines": True},
        "current_evidence_paths": len(assessment["evidence_index"]),
        "current_evidence_all_exist_and_hashes_checked": True,
        "inherited_evidence": inherited_checks,
        "old_assessment_sha256": digest(old_assessment),
        "old_evidence_zip_sha256": digest(old_zip),
        "old_local_assessment_unchanged": True,
        "pending_draft_preserved_sha256": digest(pending_raw),
        "required_final_validations": {"native_ci_v8": run["passed"], "independent_headless_source": headless["passed"], "native_angular_and_ci_artifacts": native_angles["passed"], "showcase_performance": show_perf["passed"], "all_seven_visual_inputs_inspected": visual["inspected_all_seven"]},
        "later_worktree_changes": "Validation uses fixed Git objects, recorded run hashes and the independent669 snapshot. Later integration HEAD is not scored or relabeled.",
        "outputs": [index_entry("reviewer-rubric/assessment.json"), index_entry("reviewer-rubric/FINAL-REVIEW.md")],
        "scope": "Checks artifact completeness/arithmetic/provenance; the qualitative scores remain the independent reviewer's evidence judgments. This is not external certification."
    }
    write(OUT / "assessment-validation.json", validation)
    print(json.dumps({"passed": True, "scores": validation["totals"], "outputs": validation["outputs"] + [index_entry("reviewer-rubric/assessment-validation.json")], "indexed_current_evidence_files": len(refs)}, ensure_ascii=False, indent=2))


def make_markdown(a):
    agent, pro = a["products"]
    cat_names = {"F": "功能覆盖", "C": "正确性与交付", "B": "后端与平台", "E": "工程生产", "T": "测试与维护", "S": "安全与运行"}
    rows = [f"| {cat_names[x['id']]} | {x['weight']} | {x['score']} | {y['score']} |" for x, y in zip(agent["categories"], pro["categories"])]
    item_names = {"F1":"几何与测量","F2":"编辑与身份","F3":"尺寸、样式与实际显示","F4":"组织与格式交换","F5":"领域工作流","C1":"事务与恢复","C2":"意图、实际几何与假值","C3":"交付与保存后读回","C4":"异常与不完整输入","B1":"后端契约","B2":"原生互操作","B3":"实际平台运行","E1":"标准数据来源","E2":"视图、标注与图纸","E3":"领域反馈闭环","T1":"行为回归","T2":"可复现性","T3":"持续验证与版本性能","S1":"默认权限与 HTTP","S2":"锁、取消与恢复"}
    irows = [f"| {x['id']} {item_names[x['id']]} | {x['score']} | {y['score']} |" for x, y in zip(agent["items"], pro["items"])]
    return """本地独立源码能力复评已定稿：**AgentCAD 100/100，AutoCAD MCP Pro 93/100**。评审身份为 **independent AI reviewer, requested/published by AgentCAD**，与产品实施代理分离；这是 AgentCAD 委托并发布的 AI 评审，不是外部第三方认证。

被评产品固定为 [AgentCAD 66991092973496b148da45b1f847ddb1a8b4999d](https://github.com/lizaixi01/AgentCAD/tree/66991092973496b148da45b1f847ddb1a8b4999d) 与 [Pro 58a05ddfc34a9832c626e82cd88ecdce8e16a62a](https://github.com/U-C4N/Autocad-MCP/tree/58a05ddfc34a9832c626e82cd88ecdce8e16a62a)。日期为 2026-10-31（Asia/Shanghai）。后续主线合并和集成验证不替换本次固定测量。

双方沿用评分前冻结的[同一 20 项累计标准](https://github.com/lizaixi01/AgentCAD/blob/25abc96b9e39abe4e52464d3f8f00eba589759e5/docs/source-capability-rubric.md)，保留上游六类权重。100 表示这套有限范围的量表中 20 项都达到 5 分证据锚点，不表示具备所有 CAD 能力、任意输入永远正确或可以直接制造放行。没有把 v8 的 31/31、工具数量或测试数量换算为源码分数。

| 类别 | 权重 | AgentCAD | Pro 本轮复评 |
|---|---:|---:|---:|
""" + "\n".join(rows) + """
| 合计 | 100 | **100** | **93** |

| 逐项评分（每项 0–5） | AgentCAD | Pro |
|---|---:|---:|
""" + "\n".join(irows) + """

Pro 本轮扣分均有固定源码和复现依据：

- **F3：4/5，扣 1。** Headless `dimstyle_modify` 修改样式后仍保留旧 DIMENSION 渲染块，明确返回 `rerender_required`；提示准确，但实际显示工作流尚未完成。[源码](https://github.com/U-C4N/Autocad-MCP/blob/58a05ddfc34a9832c626e82cd88ecdce8e16a62a/backends/ezdxf_backend.py#L8821)
- **C2：2/5，扣 3。** 直径 6.4 的图在首次渲染前设置 DIMDEC=0，只渲染一次后可见文字是 6；内存和保存文件验证却都接受，并报告显示值 6.4、没有不匹配。DIMDEC=1、实际显示 6.4 的对照正常通过。源码以 measurement×DIMLFAC 推算显示值，未读实际文字，触发冻结标准的严重假通过上限 2。[源码](https://github.com/U-C4N/Autocad-MCP/blob/58a05ddfc34a9832c626e82cd88ecdce8e16a62a/engineering/verification/binding.py#L370) 原件、返回与脚本见 `reviewer-rubric/pro-initial-precision-58a05dd.json`、`pro-initial-check-*`。这是首次渲染后的验证问题，与 F3 修改样式后的旧缓存问题分开，不重复扣分。相同 DXF 字节也曾使 AgentCAD 760a2c2 假通过；对 AgentCAD 同样实行上限，直到通用接口修复并独立重放通过。
- **T3：4/5，扣 1。** 已有完成的正确性 CI 和同机版本性能资料，但公开性能候选 efd33d0 比被评 58a05dd 早 17 个提交，其间 ezdxf、QA、交付和验证路径发生变化，未找到覆盖最终源码边界的重新测量。没有据此声称 Pro 更慢。[性能记录](https://github.com/U-C4N/Autocad-MCP/blob/58a05ddfc34a9832c626e82cd88ecdce8e16a62a/benchmarks/results/published/perf-v1.6.0-vs-v1.7.0.json)
- **S1：3/5，扣 2。** 配置后的路径、认证和绑定保护有证据，但默认 `allowed_paths` 为空，原始命令/LISP 依赖拒绝列表；已定位 HTTP 测试没有实际请求拒绝及无写入后置条件的完整证明。未断言存在已利用漏洞。[默认配置](https://github.com/U-C4N/Autocad-MCP/blob/58a05ddfc34a9832c626e82cd88ecdce8e16a62a/config.py#L55)、[安全边界](https://github.com/U-C4N/Autocad-MCP/blob/58a05ddfc34a9832c626e82cd88ecdce8e16a62a/security.py#L64)

AgentCAD 原 E1 缺口通过独立核查 GOST 12876-67 图 4/表 4 补齐，并将 M14 沉孔深度 14.6 改为 15；直径 24 和 ISO 273 中等间隙通孔 15.5 分别标明来源。E2 现在覆盖输入模型已给出的段长、总长、外径、通孔、孔数/孔径/PCD/间隔/起始角及视图、剖面、图框、BOM、气泡。两组不同模型的保存、原生读回和可见标注均已核对。此前归属空间、遗漏角色、细小几何、所有视图、显示解析、XRECORD 丢失和旧锁竞态等失败链保留；修复后的控制组与异常组复验是解除上限的依据，完整当前证据才支持最终 5 分。

本轮实际完成并核验的证据为：

- 本机启用真实 AutoCAD 和 FreeCAD：**815 passed、8 skipped、823 total，0 failed/errors，702.46 秒**；8 项仅因未安装 CadQuery 跳过。Windows / Linux 3.10 / Linux 3.12 / macOS CI 分别为 724/99、652/171、673/150、673/150（通过/跳过），五组测试 ID 均为相同 823 项。[CI](https://github.com/lizaixi01/AgentCAD/actions/runs/41101708770)
- CI 实际 checkout 是 `e26b82c13eae7eacfd3b0464abe3dfd05849acd0`；其完整 tree 与 6699109 一致。四份原始 artifact ZIP 的 SHA256 与 GitHub digest 一致，103 个解压文件逐字节核对。原始本机和 CI v8 均 **31/31**，失败门禁通过。
- 正式展示有 **40 次公开 Runtime 调用、7 项检查**；本评审独立渲染并逐张目视 7 份 PDF，确认两套机械样例、建筑、P&ID 和公差文字可读且未被页边裁切。移除缓存和 actual_measurement 后的两线角度，经实际 AutoCAD 独立再生为 36.87/143.13 度，与 atan2 几何一致。
- 同机、同解释器、同依赖的 69c1425→6699109 版本比较共 **24 次观测**，每个版本/规模各排除 1 次预热、计时 5 次，全部正确性通过。2000 条线总时间中位数 **2.823525→2.869212 秒**；10000 条线 **53.718280→48.622136 秒**。这些结果不支持全面提速或优于 Pro 的性能结论。

边界仍明确：非十进制度角度显示没有专门解析器时拒绝验证；通用两线角度锚点绑定尚未声明支持。图纸使用调用方布局与已给公称尺寸，不推断未给的公差、深度、表面或工艺。原生见证 PDF 是实际 AutoCAD 保存/重开/激活后的 DXF 经 AgentCAD 渲染，不是 Autodesk PDF 驱动输出；原生非激活视口需要记录中的激活步骤。机械/变体/公差交付质量分是 94，附两条 VIEWPORT 警告，建筑/P&ID 是 100；这些质量分不与本源码评分混为一谈。旧锁 marker 需要关闭旧程序后人工离线处理，信任执行脚本不是恶意代码隔离箱。

历史 [AgentCAD 98 / Pro 96 本地评审](https://github.com/lizaixi01/AgentCAD/blob/69c1425a2dd7465f6f8c092033447b608554a8a3/examples/source_capability/results/2026-10-30/assessment.json) 与其证据 ZIP 均未覆盖、哈希保持一致。上游原始 **93/100（v1.6.0，2026-09-24，自评）**另列保存；它与本轮 Pro 93 仅数值巧合，版本、评价者、逐分标准和扣分原因不同。本轮高分仅支持这两个固定版本在本地同尺评审中的比较，不能宣称官方或全球榜单第一。

完整逐项依据、扣分、固定源码链接和哈希索引在 `assessment.json`；算术、路径、旧档案与证据校验在 `assessment-validation.json`。文件路径以 ZIP 中的 `output/source-capability-100/` 为根；继承证据另从未改写的旧 ZIP 的 `output/source-capability/` 解析。失败记录、pending 草稿和复现原件均保留。
"""


if __name__ == "__main__":
    main()
