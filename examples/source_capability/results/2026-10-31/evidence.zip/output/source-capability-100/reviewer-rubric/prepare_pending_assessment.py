import copy,hashlib,json,pathlib
BASE=pathlib.Path(r"D:\Projects\AgentCAD-output\source-capability")
OUT=pathlib.Path(r"D:\Projects\AgentCAD-output\source-capability-100\reviewer-rubric")
SHA="2a68afe1f7d0e6de8acaae683606526b51c4daed"
oldpath=BASE/"reviewer-rubric/assessment.json"
old=json.loads(oldpath.read_text(encoding="utf-8"))
assert hashlib.sha256(oldpath.read_bytes()).hexdigest()=="760521504a260f31472e3b1945a3f40bc72587d13d9ee0bc2c57f6df5f727ddf"
a=copy.deepcopy(old)
a["schema"]="local-independent-source-capability-review/v2"
a["status"]="pending_final_candidate_evidence"
a.pop("completed_at",None)
a["reviewed_at"]="2026-10-30"
a["evidence_path_base"]="output/source-capability-100/"
a["historical_local_review"]={"agentcad_score":98,"pro_score":96,"agentcad_sha":old["products"][0]["product_sha"],
"pro_sha":old["products"][1]["product_sha"],"assessment_url":"https://github.com/lizaixi01/AgentCAD/blob/69c1425a2dd7465f6f8c092033447b608554a8a3/examples/source_capability/results/2026-10-30/assessment.json",
"assessment_sha256":"760521504a260f31472e3b1945a3f40bc72587d13d9ee0bc2c57f6df5f727ddf",
"evidence_zip_url":"https://github.com/lizaixi01/AgentCAD/blob/69c1425a2dd7465f6f8c092033447b608554a8a3/examples/source_capability/results/2026-10-30/evidence.zip",
"evidence_zip_sha256":"1d2889cf18d66faf3c3a4633ef5e49ae0d5ed29a22aa3a7f1d4834683165de3e",
"evidence_path_base":"output/source-capability/","note":"Historical files preserved. Extract the old and new ZIPs side by side; each keeps its own output root."}
a["evidence_index"]=[]
a["inherited_evidence_index"]=old["evidence_index"]
a["evidence_summary"]={}
a.pop("audit_history",None)
for product in a["products"]:
    is_agent=product["name"]=="AgentCAD"
    if is_agent:
        product["product_sha"]=SHA
        product["source_url"]="https://github.com/lizaixi01/AgentCAD/tree/"+SHA
    product["prior_score"]=product["total_score"];product["total_score"]=None
    product["status"]="pending_final_candidate_evidence" if is_agent else "new_counterexample_under_consistency_review"
    for c in product["categories"]:
        c["prior_score"]=c["score"];c["score"]=None
    for row in product["items"]:
        row["prior_score"]=row["score"];row["score"]=None
        row["prior_deduction"]=row.pop("deduction")
        row["deduction"]={"points":None,"reason":"Final evidence and consistent scoring pending."}
        row["inherited_evidence"]=[{"archive":"historical_local_review","path":p} for p in row.pop("evidence_paths")]
        row["evidence_paths"]=[]
        if is_agent:
            for source in row["source"]:
                source["url"]=source["url"].replace(old["products"][0]["product_sha"],SHA)
agent=a["products"][0]
def row(id):return next(x for x in agent["items"] if x["id"]==id)
def add(id,*paths):
    for path in paths:
        row(id)["source"].append({"path":path,"url":"https://github.com/lizaixi01/AgentCAD/blob/"+SHA+"/"+path})
row("E1")["basis"]="The previous M14 evidence gap is replaced by GOST 12876-67 Figure 4/Table 4 D=24 and t=15, independently checked against the pictured columns and configuration. Code actually changes depth 14.6 to 15; the through hole retains separately attributed ISO 273 medium clearance 15.5. Prior bounded fits/fastener/bearing data evidence remains traced."
row("E1")["scope_and_limits"]="Listed nominal dimensions and mixed references only: not complete GOST/DIN conformity. H14, chamfer, corner radius and other manufacturing clauses are explicitly outside the simplified 2D symbol. Existing drawings and historical claims are not rewritten."
row("E1")["evidence_paths"]=["reviewer-standards/standards-review.txt","reviewer-standards/implementation-review.txt","reviewer-standards/evidence-manifest.json"]
row("E2")["basis"]="The supplied-model drawing now contains segment and overall lengths, outer and bore diameters, hole quantity/diameter/PCD/spacing/orientation, views/section, frame, BOM and balloons. Two different saved native-witness mechanical examples were independently rendered and visually checked; final-candidate exact-source evidence is pending."
row("E2")["scope_and_limits"]="Placement is caller-controlled and examples are nominal drawing templates. Unspecified hole depth, tolerances, finish and process are not inferred. No universal layout or shop-release certification is claimed."
add("F3","src/agentcad/engineering/mechanical_annotations.py","tests/test_mechanical_annotations.py")
add("F4","src/agentcad/engineering/records.py")
add("C2","src/agentcad/engineering/mechanical_annotations.py","tests/test_mechanical_annotations.py")
add("C3","tests/test_w_delivery.py","src/agentcad/engineering/records.py")
add("E2","src/agentcad/engineering/mechanical_annotations.py","tests/test_mechanical_annotations.py")
add("S2","tests/test_freecad_progress.py","src/agentcad/backends/freecad.py")
row("C2")["basis"]="Saved role/value requirements are checked separately from generated annotation entries; actual geometry, Model ownership, dimension definitions, effective display settings, displayed text and declared numerical precision are checked. Earlier false passes are preserved and the identical abnormal inputs now reject at the candidate revision; final native/CI/run evidence is pending."
row("C2")["evidence_paths"]=["reviewer-rubric/annotation-counterexamples-2a68afe.json","reviewer-rubric/precision-counterexamples-2a68afe.json","reviewer-rubric/fine-geometry-counterexamples-2a68afe.json"]
row("C3")["basis"]="DXF readback now compares entity-owned extension dictionaries/XRECORD payloads recursively as well as layouts/blocks/styles/root metadata. The injected post-export corruption that previously passed now fails parity, while valid control delivery succeeds; existing explicit format scopes remain unchanged."
row("C3")["evidence_paths"]=["reviewer-rubric/xrecord-parity-counterexample-83506bf.json","reviewer-rubric/xrecord-parity-counterexample-2a68afe.json"]
row("S2")["basis"]="Prior OS-lock, cancellation and checkpoint evidence applies to unchanged code. FreeCAD's process-completion path now drains complete trailing progress lines; new deterministic completion-race tests and current enabled native regression are required before final assignment."
pro_c2=next(x for x in a["products"][1]["items"] if x["id"]=="C2")
pro_c2["score_upper_bound"]=2
pro_c2["basis"]="Ordinary geometry/requirement binding works, but a new exact-source headless counterexample shows actual rendered diameter text 6 accepted as if it displayed 6.4. Both in-memory and saved-artifact requirement verification return accepted=true, displayed_text=6.4 and mismatch=false."
pro_c2["pending_deduction_reason"]="Frozen serious-false-success rule caps C2 at 2 until repaired. The new case creates DIMDEC=0 before its first and only render; it does not call dimstyle_modify and is independent of F3's missing re-render."
pro_c2["scope_and_limits"]="New counterexample is headless DXF; no fresh Pro AutoCAD run or blanket claim of failure of all requirement checks. The control with actual 6.4 display passes, and the dimension moved into an unused block is correctly rejected."
pro_c2["source"] += [{"path":"engineering/verification/binding.py","line":370,"url":"https://github.com/U-C4N/Autocad-MCP/blob/58a05ddfc34a9832c626e82cd88ecdce8e16a62a/engineering/verification/binding.py#L370"},
{"path":"engineering/verification/binding.py","line":477,"url":"https://github.com/U-C4N/Autocad-MCP/blob/58a05ddfc34a9832c626e82cd88ecdce8e16a62a/engineering/verification/binding.py#L477"}]
pro_c2["evidence_paths"]=["reviewer-rubric/pro-initial-precision-58a05dd.json","reviewer-rubric/pro-dimension-boundaries-58a05dd.json","reviewer-rubric/repro_pro_initial_precision.py","reviewer-rubric/repro_pro_dimension_boundaries.py"]
a["consistency_notes"]=[
"The same frozen anchors and serious-false-success caps apply to both products. No point is assigned to raw tool/test counts or the user's target.",
"The old AgentCAD 98 / Pro 96 scorecard is preserved as historical. Pro source has not changed, but newly demonstrated verification behavior requires revising this round's judgment.",
"Pro F3 and C2 are separate: the former leaves old graphics after dimstyle_modify; the new C2 reproduction performs initial rendering successfully and the verifier still misreports already-rendered text.",
"Prior Pro extra-empty-table deduction remains excluded as an asymmetric optional-feature requirement. Unsupported extra tables receive no capability credit.",
"AgentCAD's earlier owner/partial-record/style/rounding/geometry and XRECORD-output-loss failures are retained and repaired under the corresponding C2 or C3 item, without mechanical duplicate penalties.",
"Old evidence is inherited only with an explicit code/data boundary. Changed shared serialization invalidates assumptions in otherwise unchanged consumers."
]
a["pending_evidence"]=["Exact 2a68afe complete native run and source/environment binding","Exact 2a68afe completed four-lane CI and skip/test-ID inventory","Exact 2a68afe v8 report","Exact 2a68afe native showcase and independent final visual inspection","Exact 2a68afe same-environment version performance/correctness comparison"]
(OUT/"assessment.pending.json").write_text(json.dumps(a,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
print(json.dumps({"status":a["status"],"candidate":SHA,"items":[len(p["items"]) for p in a["products"]],"final_totals":[p["total_score"] for p in a["products"]]}))

