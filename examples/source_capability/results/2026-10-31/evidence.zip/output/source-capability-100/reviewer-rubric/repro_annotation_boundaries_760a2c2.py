"""Independent headless annotation boundaries; fixed Git source, no native CAD."""
from __future__ import annotations
import hashlib, io, json, pathlib, subprocess, sys, zipfile

SHA = "760a2c2e9f68908da8377cd3fb30727552b03730"
REPO = pathlib.Path(r"D:\Projects\AgentCAD")
OUT = pathlib.Path(r"D:\Projects\AgentCAD-output\source-capability-100\reviewer-rubric")
SNAPSHOT = OUT / "snapshot-760a2c2"
OUT.mkdir(parents=True, exist_ok=True)
blob = subprocess.check_output(["git","-C",str(REPO),"archive","--format=zip",SHA,"src"])
with zipfile.ZipFile(io.BytesIO(blob)) as z:
    for entry in z.infolist():
        destination = (SNAPSHOT / entry.filename).resolve()
        assert destination.is_relative_to(SNAPSHOT.resolve())
    z.extractall(SNAPSHOT)
sys.path.insert(0, str(SNAPSHOT / "src"))
import agentcad, ezdxf
from agentcad.policy import Policy
from agentcad.service import Runtime
from agentcad.engineering.records import get, put
from agentcad.engineering.mechanical_annotations import _rendered
assert pathlib.Path(agentcad.__file__).resolve().is_relative_to(SNAPSHOT.resolve())

SPEC = {"parts":[{"name":"review_flange","at":[210,170],"views":["front","side"],
    "segments":[{"length":15.5,"d_outer":80,"d_inner":20}],
    "features":[{"kind":"hole_circle","pcd":60,"diameter":6.4,"count":6,"start_angle":17}]}]}
def ok(r):
    assert r["ok"], r
    return r

results = []
for damage in ["control","dimension_unused_block","note_unused_block","truncated_annotation_record","dimdec_without_render"]:
    work = OUT / ("case-760a2c2-" + damage)
    work.mkdir(exist_ok=True)
    rt = Runtime(Policy(root=work))
    ok(rt.create_drawing("case.dxf", units="mm"))
    ok(rt.apply_operations("case.dxf", [{"op":"draw_mechanical_assembly","spec":SPEC}]))
    before = ok(rt.read_engineering("case.dxf","mechanical"))
    assert before["critique"] == []
    doc = ezdxf.readfile(work / "case.dxf")
    part = before["manufacturing"][0]
    hole = next(a for a in part["annotations"] if a["kind"] == "hole_diameter.0")
    body = doc.entitydb[part["handle"]]
    record = get(body, "mech")
    dim = doc.entitydb[hole["handle"]]
    expected = {"hole_dim_handle":dim.dxf.handle,"original_owner":dim.dxf.owner}
    if damage == "dimension_unused_block":
        unused = doc.blocks.new("REVIEW_UNINSERTED")
        doc.modelspace().move_to_layout(dim, unused)
        expected["new_owner"] = dim.dxf.owner
    elif damage == "note_unused_block":
        note = next(a for a in part["annotations"] if a["kind"] == "pattern_orientation.0")
        unused = doc.blocks.new("REVIEW_UNINSERTED")
        doc.modelspace().move_to_layout(doc.entitydb[note["handle"]], unused)
    elif damage == "truncated_annotation_record":
        record["manufacturing"]["annotations"] = [
            a for a in record["manufacturing"]["annotations"] if a["handle"] != dim.dxf.handle]
        doc.modelspace().delete_entity(dim)
        put(doc, body, "mech", record)
    elif damage == "dimdec_without_render":
        override = dim.override()
        override.update({"dimdec":0})
        override.commit()
        expected["cached_rendered"] = _rendered(doc,dim)
    doc.saveas(work / "case.dxf")
    reopened = ezdxf.readfile(work / "case.dxf")
    model_hole_present = any(e.dxf.handle == hole["handle"] for e in reopened.modelspace())
    checked = rt.read_engineering("case.dxf","mechanical")
    delivery = rt.deliver_drawing("case.dxf", "delivery", formats=["dxf"], strict=True)
    result = {"case":damage,"expected_details":expected,
        "hole_dimension_in_model":model_hole_present,
        "read_ok":checked.get("ok"),"critique":checked.get("critique"),
        "manufacturing":checked.get("manufacturing"),
        "delivery_ok":delivery.get("ok"),"delivery_error":delivery.get("error"),
        "drawing_sha256":hashlib.sha256((work/"case.dxf").read_bytes()).hexdigest()}
    if damage == "dimdec_without_render":
        d = reopened.entitydb[hole["handle"]]
        d.override().render()
        result["after_explicit_headless_rerender"] = _rendered(reopened,d)
        reopened.saveas(work / "after-render.dxf")
    (work / "result.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    results.append(result)
report = {"product_sha":SHA,"imported_from":str(agentcad.__file__),"python":sys.version,
    "ezdxf":ezdxf.__version__,"cases":results,"scope":"Headless only. No AutoCAD/FreeCAD/Claude launch."}
(OUT / "annotation-counterexamples-760a2c2.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"product_sha":SHA,"cases":[{k:r.get(k) for k in ["case","hole_dimension_in_model","critique","delivery_ok","delivery_error","after_explicit_headless_rerender"]} for r in results]}))

