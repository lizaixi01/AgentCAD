# 新一轮独立复评底稿（未签发最终评分）

审查身份：independent AI reviewer, requested/published by AgentCAD。未写产品代码；未启动 AutoCAD、FreeCAD 或 Claude。只运行固定源码的无头反例、读取原生记录并检查图面。

冻结规则仍为 `docs/source-capability-rubric.md`，SHA256 `be562004ba7f25c0d131cdf690c9dc4844cd0df9dc3ede467ae2308420d1d52e`。没有因 100 分目标改变锚点。

旧 AgentCAD 98 / Pro 96 评审及其证据不覆盖。公开历史档案在 AgentCAD commit `69c1425a2dd7465f6f8c092033447b608554a8a3` 的 `examples/source_capability/results/2026-10-30/`；assessment 与本地历史原件逐字节一致。旧 assessment SHA256 为 `760521504a260f31472e3b1945a3f40bc72587d13d9ee0bc2c57f6df5f727ddf`，旧 evidence.zip 为 `1d2889cf18d66faf3c3a4633ef5e49ae0d5ed29a22aa3a7f1d4834683165de3e`。

## 版本与继承边界

- 初始候选：`83506bfa8a7ccc4c7eaf9da84cc8004986af02e3`；修复候选：`0cffbf9434a86f1bc0e26d5d6b72da4807467603`。
- Pro 保持 `58a05ddfc34a9832c626e82cd88ecdce8e16a62a`。
- 初始逐项边界见 `boundary-trace-83506bf.json`。旧到 835 的 `src/` 共 71 → 72 个文件，67 个相同，修改 4 个、新增 1 个。旧运行的 67 个哈希指 Python 文件；这里的完整 Git 树还包括 4 个静态前端文件。
- 虽然 delivery.py 在 835 本身没有改动，共享记录从 XDATA 改为实体 XRECORD 后越过了其旧检查边界，因此不能仅凭 delivery.py 未改动继承满分。
- 0cff 另外修改 FreeCAD 进度尾行读取、交付扩展记录比较、制造标注校验；这些边界要用新证据，不能直接继承旧分。

## AgentCAD 独立反例与修复重验

初始失败：`annotation-counterexamples-83506bf.json`、`xrecord-parity-counterexample-83506bf.json`。固定源码通过 Git archive 单独读取，不导入正在修改的工作树。

1. DIMENSION 或方向 MTEXT 移入未插入块后，Model 缺标注但 read 无 critique、strict DXF delivery 成功。
2. 删除孔径 DIMENSION，并只截去对应 annotation 记录一行，保留 length.0 和其他内容，仍被视为完整。
3. 只改孔径 DIMDEC=0，缓存仍为 6.4 时交付成功；实际重新 render 后变为 6XØ6。
4. 大零件使用实体 XRECORD 后，export 后仅破坏 XRECORD JSON，保持所有句柄不变：结构 audit=0，DXF parity 仍称通过，strict delivery 成功；随后公开读交付物却报 INVALID_DOMAIN_RECORD。

前三项主归 C2，第四项主归 C3；初始版本分别触发严重假通过上限 2。避免在 F3/E2 等处机械重复扣分。

同输入在 0cff 已独立重验：控制组保持通过，所有异常输入均拒绝；扩展记录内容已进入 parity。原始结果为 `annotation-counterexamples-0cffbf9.json` 和 `xrecord-parity-counterexample-0cffbf9.json`。这些具体缺陷的临时上限可以解除，最终等级仍等待完整证据。

## E1/E2 新证据的当前结论

- 已独立查看 GOST Figure 4 与 Table 4 continuation 的图像：M14 的 D=24、t=15，列与无垫圈内六角圆柱头构型相符。实际代码将旧深度 14.6 改为 15，分别注明 ISO 273 通孔与 GOST D/t，未冒称完整 GOST/DIN 符合性。来源审查和公开 API/单位换算测试由 reviewer-standards 留证；仍需最终固定版本验证。
- 已独立查看 835 两份 native-witness 机械图：总长/分段长、各外径、通孔直径、孔径/数量/PCD/等分与首角、BOM 均可读。分数不能从图面漂亮直接得出；新的完整性和交付校验也必须工作。最终版本图面仍待确认。
- 未提供的加工过程、孔深、公差和表面要求不凭空补入，也不以“全部行业要求”另设满分门槛。

## Pro 新证据必须更新本轮判断

把显示精度边界应用于 Pro 的明确 dimension-selector 验证流程，得到 `pro-dimension-boundaries-58a05dd.json`。移入未插入块的尺寸被正确拒绝；实际显示 Ø6 的 6.4 圆却在内存和保存文件验证中都 accepted=true，报告错误声称 displayed_text="6.4"、mismatch=false。

为与旧 F3 缺少重绘问题分开，另建从第一次创建起 DIMDEC=0、仅 render 一次的例子和 DIMDEC=1 控制组：`pro-initial-precision-58a05dd.json`。实际 block MTEXT 分别为 `%%c6` 与 `%%c6,4`，两者都被验证接受。保存的 DXF、原始响应和可复现脚本均保留。

根因在固定 Pro 的 `engineering/verification/binding.py:370–391`：`_displayed` 直接以 measurement × DIMLFAC 生成声称的文字；`bind_dimension` 的 477–501 行使用该推算结果，未检查实际显示精度或渲染文字。正式工具调用链可追到 `server.py:12343` / `12517`。

这不是旧 F3 的 `dimstyle_modify` 没有刷新现有块：新反例根本不调用该操作，渲染已完成。F3 是功能流程没有完成重绘；C2 是面对已经完成但错误显示的图纸仍声称验证通过，两项触发条件与修复位置不同。按同一冻结规则，新一轮 Pro C2 必须受上限 2；不为维持旧 96 而忽略新证据。旧评审仍保留为历史，新的合计等一致性复核后发布。

## 尚待最终材料

修复候选的完整本机原生回归、四 CI lane、v8、同环境版本性能比较和正式出图；精确产品/依赖/输入/输出哈希；FreeCAD 最后进度事件修复的行为和实际运行验证。未完成记录不当作通过。

## 后续固定版本与大坐标边界（仍未签发）

- `cd20aac3832aa1133ca475fa0f3802400c5a01fb` 修复 DIMRND 精确比较和 DIMLUNIT。既有反例均拒绝，真实八位小数 DWG 往返、718 passed / 8 skipped 的完整原生测试、四 lane CI 均有完成记录；但随后在 DIM 定义点 +5e-7 时仍假通过，故这些记录作为历史，不替代后续版本证据。
- `2a68afe1f7d0e6de8acaae683606526b51c4daed` 将几何比较改为 max(1e-9, 4 ULP)，并检查尺寸实际测量按声明精度格式化的值。已独立重验所属空间、部分记录、DIMDEC、DIMRND、单位设置、XRECORD 导出破坏及 +5e-7 定义/轮廓改动，均拒绝，普通控制保持成功。
- 独立代码 reviewer 的 `reviewer-pr44-r5/coordinates.json` 及 `coordinate-diagnostics.json` 证明，at.x=1e8 时部分正常尺寸的相减误差超过短测量值本身的 ULP，即使 source/definition 完全一致、缓存及重新渲染文本正确，也会被误拒。这属于正常输入回归，不套严重假通过的 2 分上限。
- 本评审随后独立发现另一个 **真实假通过**，控制组同样使用 2a 固定快照：at.x=1e8、length=17.12345682，正常控制 read/strict 均通过。仅将轮廓最右边的所有 x 坐标向 +∞ 移动 1 ULP（约 1.49e-8），实际轮廓宽度按八位小数变为 17.12345684，尺寸仍显示 17.12345682；read 无 critique，strict DXF delivery 仍成功。原始文件、返回、哈希见 `large-coordinate-source-2a68afe.json` 和 `large-source-2a68afe-*`；可复现脚本为 `repro_large_coordinate_source_2a68afe.py`。
- 后者证明 source 的 4 ULP 容差可能隐藏已改变声明精度的真实轮廓；仅取消测量值的 `_same` 可解决误拒，但不能解决这个假通过。当前 C2 临时上限为 2，等修复及同输入复验再解除；不在 F3/E2 机械重复扣分。

新 `assessment.pending.json` 只保存证据和旧分，最终 20 项与总分仍为 null。最终评分等待新固定版本完整证据。

## 392b7f2 的复验与新增边界

`392b7f2ced9686676c804e0d58884afc9cee10c2` 使用单独测量的源轮廓跨度/圆径，覆盖两侧长度及重复外径/孔径的两端，并采用 AutoCAD 二进制 DXF 中间文件保持数据库 double。该原生路径改变已纳入 `boundary-trace-392b7f2.json`，不直接继承旧 ASCII 原生互操作证据。

本评审用固定 Git 快照新建原始 spec：旧所属空间/部分记录/DIMDEC、DIMRND/单位、微小几何、XRECORD 导出破坏均按预期；另九项大坐标正常输入、双侧/单侧 1 ULP 轮廓变化、重复外径/孔径末端变化均正确，见 `coordinate-source-counterexamples-392b7f2.json`。72 个源文件与固定 Git 逐字节一致，见 `independent-headless-validation-392b7f2.json`。

随后另一个未写代码的 PR reviewer 在 `reviewer-pr44-r6/additional-evidence.json` 保留两项新证据：50×0.58 或 50×1.1 的总体长度累计浮点误差导致有效输入被误拒；只修改剖视图孔边界 4 ULP（y=1e7），实际孔径按八位从 17.12345678 变为 17.12345679，但 read/strict 仍放行。前者为输入回归，后者仍属于 C2 的源几何检查缺口，主归 C2，不重复扣 F3/E2。当前 C2 上限 2，等待覆盖所有所提供视图的修复及复验。前一批通过结果不被删除，也不覆盖新失败。

## 760a2c2 独立重验（2026-10-31，Asia/Shanghai）

候选 `760a2c2e9f68908da8377cd3fb30727552b03730` 用稳定求和计算名义总长，并把前视、隐藏孔线、剖视两侧和端视圆的实际测量接入标注检查。再次以新建原始规格复验旧所属空间/部分记录/显示设置/细几何/XRECORD反例及九项大坐标控制，均符合预期；另四项累计长度正常交付，section-only bore 4 ULP 变形被明确拒绝。原件见 `all-view-source-counterexamples-760a2c2.json`、`coordinate-source-counterexamples-760a2c2.json` 及其他该 SHA 的反例报告。已知 C2/C3 临时上限在这些修复范围解除，最终等级仍等待完整证据。

独立获取的 GitHub CI run `41087739491` 已完成、四 lane 均 success，固定 head 为该候选。尚不把正在运行的完整本机原生测试或未完成的出图/性能结果记为通过。冻结规则 SHA256 明确对应 Git/LF 内容；CRLF 工作树原始字节的哈希在 pending assessment 中单独记录。

## 通用尺寸验证的对称审查（760a2c2，结论更新）

完成 742 passed / 8 CadQuery skipped / 750 IDs 的原生完整回归与四 CI lane、两次 v8 的独立来源核验后，仍不能据此推断 C2 没有已知缺陷。按主协调者提出的公平性复核，本评审将 **Pro 初始精度反例的相同 DXF 字节** 交给 AgentCAD 的通用 `verify_dimensions`，未使用新机械模板。

`DIMDEC=1` 的实际匿名块文字 `%%c6,4` 正常接受；`DIMDEC=0` 在第一次创建时设置、只 render 一次，实际匿名块文字为 `%%c6`，AgentCAD 仍返回 `accepted=true`、`displayed=6.4000000000000075`、`findings=[]`。内存函数和读取保存文件的公开 Runtime 接口均如此，原件和公开返回保留在 `agent-generic-initial-precision-760a2c2.json`、`agent-generic-initial-760a2c2-*`，复现脚本为 `repro_agent_generic_initial_precision.py`。

根因是 `validate/features.py:173–178` 以 measurement × DIMLFAC 推算 displayed，`verification.py` 沿用该数值，未检查实际显示精度/渲染块文字。它与 Pro 的新 C2 反例是同一个显示/物理数值契约。**AgentCAD C2 也必须受上限 2，直到通用流程修复并用相同输入重验。** 机械模板此前的成功记录保留，但不能替代这个通用路径。旧 AgentCAD 98 / Pro 96 历史评审均不覆盖；新证据更新本轮判断。

## fd6d45f 通用显示修复及完成证据边界

固定产品 `fd6d45f274897cf7e2541d4c70d88113dfb6cb22` 新增对保存 DIMENSION 匿名块中可见 TEXT/MTEXT 的读回，将几何测量、DIMLFAC 缩放值和实际显示值分开。缺失、隐藏或无法确定主值时不以几何推算替代显示证据；通用完整性允许明确精度下的正常舍入，而显式尺寸需求使用其自身数值容差。

本评审重新提交 Pro 初始反例的**相同 DXF 字节**给公开 Runtime：DIMDEC=1 的 `6.4` 正常通过，DIMDEC=0 的实际 `6.0` 被 `verify_dimensions` 和要求 `6.4` 的 `validate_drawing` 拒绝。要求显示 `6.0` 的普通尺寸需求通过，明确区分了显示需求与绑定物理值的验证契约。原始返回在 `agent-generic-initial-precision-fd6d45f.json`、`generic-requirement-semantics-fd6d45f.json` 及相应原件目录。

全部既有归属空间、必需角色、DIMDEC/DIMRND/单位、微小几何、XRECORD、九项大坐标、累计长度和剖视孔变形反例也已在该固定快照重验，控制组通过、异常组拒绝。`independent-headless-validation-fd6d45f.json` 绑定 73 个源文件和八份独立报告。已知通用 C2 反例已修复，可解除该反例的临时上限；这不自动决定最终得分。

该版本完整原生回归已结束，但结果为 **755 passed / 8 skipped / 1 failed**，不是全绿。独立只读检查唯一失败 `test_dimensions_measure_actual_geometry` 的原始 DXF：旋转尺寸 C5 几何值为 `45.98076211353316`，样式 `DIMDEC=2`、`DIMRND=0`，保存匿名块文本却为 `46`，而正常两位显示应为 `45.98`。这不是单纯把未舍入数值当作显示预期；默认显示流程有真实差异，新检查暴露了它。证据为 `full-failure-diagnosis-fd6d45f.json` 和 `inspect_fd_full_failure.py`，输入未改。通用创建仍用 DIMRND=0，与机械流程已处理的 ezdxf 零增量整数舍入问题相符；应修复显示流程并用控制组验证，不能只把测试期望改为 46。

原始 JUnit/log 和 `measurement-stages-fd6d45f.json` 的失败状态保留。这项主归 F3 创建后的实际显示能力，不把已正确拒绝的 C2 验证误判为仍然假通过。需完成最终固定版本验证后才签发评分；不把通过计数或旧版本的完整结果替代本次未完成验证。

## fd6d45f 新显示解析反例：C2 上限重新生效

另一个未写产品代码的 PR reviewer 在 `reviewer-pr44-r8` 留下成对反例，本评审已用 fd 固定快照和**相同 DXF 字节**独立重放，结果为 `generic-parser-boundaries-fd6d45f.json`。`<> 4` 的尾缀在主值 `6.4` 内错误截断，以及 `dimtol=1` 时把公称 `6 1/2` 的第一个叠排分数当作公差起点，都会把实际 6.4 或 6.5 读成 6。物理直径 6 配错误缓存时，公开绑定验证、显示要求和 strict DXF 交付均错误接受；物理值与显示相同的正常对照被误拒。水平 `/` 和合法斜排 `#` 分数加公差的原件均保留。

因此 C2 仍有严重假通过，按冻结规则暂时上限为 2，等待修复及相同输入复验；这是同一主值解析缺口，不在 C3 额外重复扣分。最初 DIMDEC 反例确已修复的证据仍然有效，但不能掩盖这些新边界。斜排无公差的单独输入返回未验证、显式需求拒绝，这属于支持/拒绝边界，不当作错误认证。分数中的 `^` 公差 stack 使用 MTextEditor 生成的有效格式，包含必要空格，避免把无效语法当成合法输入。

## 后续合并主线也进入评估边界

将并入的 `0758cdc` 主线新增本地安装向导 HTTP 服务、CLI 入口和安装进度回调；`4ce35806db048162d61fd9492f14539280c592ed` 又修改公差来源标记与清除、尺寸修改、旧锁恢复及图像量测注释。因此 S1/S2/C1/F3 等不能仅据早期同文件未改而继承结论，最终固定版本需覆盖这些边界。已读新的真实 HTTP 临时配置测试与源码，不运行安装向导或用户客户端。

在单独固定的**合并输入主线** `4ce3580` 上，`legacy-lock-race-4ce3580.json` 证实新 `remove_legacy_marker` 的最终比较与 unlink 之间存在替换竞态。测试只对目标 marker 的第二次读取插桩以确定性调度：一个真实、仍存活的 Python 子进程在该次读取后写入自己的 PID；恢复随后删除新 marker 并声称成功，公开 `apply_operations` 在这个模拟旧写者仍活着时也能写入。子进程只模拟旧锁协议，不修改图纸，不声称已观察到 CAD 数据损坏。原始路径、公开返回和同步脚本 `repro_legacy_lock_race.py` 均保留。

这是新合并代码的 S2 互斥/恢复边界，需要保守处理未知旧写者或真实排他方案；不能简单增加一次读取当作消除竞态。它不是 fd6d45f 已包含的缺陷，故不把失败倒写进 fd 的固定源码评分。最终合并候选等待修复与复验，C1 不机械重复扣分。

## 953c3f0 的修复重验及 v8 失败保留

固定 `953c3f07359970438aac2dee281288f76f5feffd` 的独立重放已完成：r8 原始同字节九例全部符合预期（包括合法水平/斜排分数与公差、数字后缀）；原始 Pro 初次渲染的 6.4 对照通过、实际显示 6 的输入拒绝；通用旋转尺寸首次保存为 45.98，DIMDEC 改为 3 后公开文字高度编辑触发重绘为 45.981，DIMRND 始终为原生 0。全部旧机械归属、角色、设置、几何、XRECORD、大坐标与所有视图反例也均按预期。相关 `*-953c3f0.json` 和原件保留，固定源快照核对 75 个文件。

新合并的旧锁恢复已改为保守拒绝：相同竞态调度在第二次读取前即被拒绝（实际不读取 marker），不会进入删除窗口；活、已退出、无效 PID 三类 marker 与图纸字节均保留，现代正常写入仍通过。证据为 `legacy-lock-race-953c3f0.json`、`legacy-lock-refusal-953c3f0.json`，可解除该新引入的已知互斥问题。合并还改变两线角度扇区测量/重绘和角度 DIMLFAC 处理，要求以真实 AutoCAD 清除缓存后再生的结果核对，不能用同一错误缓存自证。

本轮 v8 实际为 **30/31、96.77**，而不是 31/31。独立读取 `v8-953c3f0/report.json` 确认唯一失败 `dimension_binding`：D2 正确拒绝，但聚合同一 requirement 的 `dimension_mismatch` 和 `dimension_override_mismatch` 两行改变了评估器聚合后的主类型。行内两个原因均已保留；这是公开结果聚合的兼容性问题，不能当作错误接受，也不能称完整 benchmark 已通过。修复应保留实际显示优先的主问题和完整行内原因，元数据单独异常仍需拒绝；不改上游评估器。

`windows-native-953c3f0.interruption.json` 明确保留了这次完整回归中断。该版不继续生成最终出图/性能证据，不能以部分通过替代全量成功。`assessment.pending.json` 当前产品指向 953，所有分数仍为 null，等待下一固定候选的完整证据。

## 6699109 当前候选：已修已知反例，完整证据待定

`f6f3f52196665ddde439a8c9150a1a5e4ebd95a1` 仅调整聚合主 finding，独立三组对照确认未放宽接受条件：只有元数据错误时仍报 override mismatch；实际缓存与元数据都错时行内保留两个原因、聚合用一个 display mismatch；正常图通过。该版本只有定向复验，未宣称完整原生/v8 成功。

r9 随后在 953（f6 该分支未变）发现角度精度受线性分数单位影响：DIMADEC=4、DIMLUNIT=5 的实际 60° 配 60.0100° 缓存，通用检查和 strict 交付却按 0.0625 resolution 通过。此项仍主归 C2，不在 C3 重复扣分。现固定 `66991092973496b148da45b1f847ddb1a8b4999d` 已把角度精度与线性格式分开。

本评审用 r9 原始同字节文件再次检查：DIMLUNIT2/5 的错误缓存均在 resolution=0.0001 下拒绝；只把缓存文本改回 60.0000° 的正常对照均通过。无对应解析器的 DIMAUNIT1/2/3/4 明确返回 `unsupported_angular_format`，显式角度显示需求失败，不把裸数字假认证为度。证据 `angular-precision-6699109.json`。r8 九例、原始 Pro 初次渲染输入、聚合三组、默认 DIMRND0 重绘、旧 marker 竞态/活死无效 PID 控制也均在 669 独立重验正确。

机械源码、交付与其非角度显示分支从 953 至 669 的等价性已逐项追踪，六份已完成的 953 独立机械反例报告继承依据见 `inherited-boundaries-6699109.json`；**不继承** 953 的中断完整测试或失败 v8。`independent-headless-validation-6699109.json` 绑定 75 个固定源码文件。新主线的安装 HTTP、角度重绘、公差来源和保守旧锁拒绝也已进入 `boundary-trace-6699109.json`。

所有新总分和 20 项分数仍为 null。等待 669 的完整本机原生回归、四 lane CI、v8、正式出图/目视及同环境版本性能完成后，再按同一冻结规则签发新评估。

## 6699109 最终独立定稿（2026-10-31）

最终证据已全部完成并独立核验：本机 815 passed / 8 CadQuery skipped、823 IDs；四 CI lane 与本机的 ID 集合一致；CI 实际 checkout e26b82c 的完整 tree 与 6699109 相同；原始四 ZIP 与 GitHub digest、103 个解压文件逐字节一致。本机与 CI 的原始 v8 均 31/31。正式原生展示 40 次公开 Runtime 调用、7 项检查通过；7 份 PDF 已由本评审独立渲染并逐张目视。24 次同环境性能观测均通过正确性检查，2000 条线中位总时长略增、10000 条线下降，不据此声称全面提速。

缓存和 measurement 都被移除的两线角度输入经实际 AutoCAD 重新生成 36.87/143.13 度，本评审只读原始 native 作业并以独立 atan2 计算核对。所有已知严重缺陷的同字节或同规格控制组/异常组均有修复后证据；早期失败、中断和 pending 草稿原样保留。

按冻结 20 项累计标准，最终 AgentCAD 100（25/20/15/15/15/10），Pro 同尺新复评 93（24/17/15/15/14/8）。Pro 扣分为 F3 -1、C2 -3、T3 -1、S1 -2；新 C2 与旧 F3 是不同触发边界，不重复扣分。新 Pro 93 与历史上游 v1.6.0 自评 93 只是数值相同，旧本地 98/96 记录保持不变。

这是 independent AI reviewer, requested/published by AgentCAD 的限定源码能力评估，不是外部第三方认证或官方榜单。100 表示本冻结量表的已评契约均达到 5 分证据锚点，不是所有 CAD 能力、任意输入正确性或制造放行保证。最终文件为 assessment.json、FINAL-REVIEW.md 和 assessment-validation.json。新主线集成提交不替换此处被评 6699109。
