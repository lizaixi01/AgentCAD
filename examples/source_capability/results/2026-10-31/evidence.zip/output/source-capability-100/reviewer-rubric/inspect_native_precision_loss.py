"""Read-only numerical inspection of the author's failed development roundtrip."""
import hashlib,json,pathlib,sys
import ezdxf
base=pathlib.Path(r"D:\Projects\AgentCAD-output\source-capability-100")
root=base/"source-dimensions-native/test_eight_decimal_nominal_dim2"
rows=[]
for name in ["blank.dxf","fine.dxf"]:
    path=root/name
    doc=ezdxf.readfile(path)
    body=doc.entitydb["E0"]
    length=doc.entitydb["E3"]
    line=doc.entitydb["E2"]
    points=list(body.get_points("xy"))
    width=max(p[0] for p in points)-min(p[0] for p in points)
    rows.append({"path":path.relative_to(base).as_posix(),"sha256":hashlib.sha256(path.read_bytes()).hexdigest(),
        "outline_points":points,"actual_width":width,"width_at_8_decimals":f"{width:.8f}",
        "dimension_defpoints":[list(length.dxf.defpoint2),list(length.dxf.defpoint3)],
        "dimension_measurement":length.get_measurement(),"centerline_end":list(line.dxf.end)})
result={"scope":"Read-only numerical artifact inspection. These files were generated during author development from an uncommitted worktree; not final fixed-version verification.",
        "python":sys.version,"ezdxf":ezdxf.__version__,"nominal":17.12345678,"coordinate_origin":1e8,"files":rows,
        "finding":"Reopened ASCII DXF changed source and dimension coordinates enough to change the declared eight-decimal size. Refusing this changed artifact is not a normal-input false rejection; widening integrity tolerance would hide real precision loss."}
(base/"reviewer-rubric/native-precision-loss-development.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"widths":[r["width_at_8_decimals"] for r in rows],"fixed_version_evidence":False}))
