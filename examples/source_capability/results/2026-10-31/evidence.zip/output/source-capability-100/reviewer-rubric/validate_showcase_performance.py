"""Verify recorded showcase/performance identity and arithmetic; no CAD invocation."""
import argparse,datetime,hashlib,json,pathlib,statistics,subprocess
parser=argparse.ArgumentParser();parser.add_argument("sha");args=parser.parse_args()
BASE=pathlib.Path(r"D:\Projects\AgentCAD-output\source-capability-100")
REPO=pathlib.Path(r"D:\Projects\AgentCAD")
label=args.sha[:7]
def load(path):return json.loads(path.read_text(encoding="utf-8"))
def hashbytes(data):return hashlib.sha256(data).hexdigest()
def git(*params):return subprocess.check_output(["git","-C",str(REPO),*params])
def git_hash_matches(commit,path,reported):
    raw=git("show",commit+":"+path);lf=raw.replace(b"\r\n",b"\n")
    assert reported in {hashbytes(raw),hashbytes(lf),hashbytes(lf.replace(b"\n",b"\r\n"))},path
env=load(BASE/("windows-native-"+label+".environment.json"))
sp=BASE/("showcase-"+label)/"report.json";s=load(sp)
assert s["source_commit"]==args.sha and s["native"] is True
assert s["source_sha256"]==env["source_sha256"]
assert all(v=="passed" for v in s["checks"].values())
assert all(c["result"].get("ok") is True for c in s["calls"])
git_hash_matches(args.sha,"examples/source_capability/showcase.py",s["harness_sha256"])
visual=load(BASE/"reviewer-rubric"/("visual-inputs-"+label+".json"))
for row in visual["files"]:
    assert hashbytes((BASE/row["pdf"]).read_bytes())==row["pdf_sha256"]
    assert hashbytes((BASE/row["image"]).read_bytes())==row["image_sha256"]
pp=BASE/("performance-"+label)/"report.json";p=load(pp)
assert p["snapshots"]["candidate"]["commit"]==args.sha
assert set(p["snapshots"]["candidate"]["source_sha256"])==set(env["source_sha256"])
assert p["python"]==env["python"] and p["platform"]==env["platform"]
for role,snapshot in p["snapshots"].items():
    for path,h in snapshot["source_sha256"].items():
        raw=(pp.parent/role/path).read_bytes();assert hashbytes(raw)==h
        assert raw.replace(b"\r\n",b"\n")==git("show",snapshot["commit"]+":"+path)
git_hash_matches(args.sha,"examples/source_capability/compare.py",p["harness_sha256"])
assert p["correctness_passed"] is True and p["repetitions"]==5 and p["warmups_excluded"]==1
assert len(p["measurements"])==24 and all(r["passed"] is True for r in p["measurements"])
for count in (2000,10000):
    group=[r for r in p["measurements"] if r["count"]==count]
    assert len({r["geometry_sha256"] for r in group})==1
    for role in ("baseline","candidate"):
        rows=[r for r in group if r["version"]==role]
        assert sorted(r["repeat"] for r in rows)==[-1,0,1,2,3,4]
        assert all(pathlib.Path(r["imported_from"]).resolve().is_relative_to((pp.parent/role/"src").resolve()) for r in rows)
for summary in p["summary"]:
    for role in ("baseline","candidate"):
        values=[r[summary["metric"]] for r in p["measurements"] if r["version"]==role and r["count"]==summary["count"] and r["repeat"]>=0]
        assert statistics.median(values)==summary["median"][role]
    assert summary["candidate_over_baseline"]==summary["median"]["candidate"]/summary["median"]["baseline"]
result={"product_sha":args.sha,"validated_at_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"passed":True,
    "showcase":{"report":sp.relative_to(BASE).as_posix(),"report_sha256":hashbytes(sp.read_bytes()),"public_runtime_calls":len(s["calls"]),"checks":s["checks"],"all_call_results_ok":True,
        "source_binding":f"All {len(s['source_sha256'])} Python source hashes equal the completed native run; harness matches fixed Git content allowing only CRLF/LF representation.",
        "native_pdf_boundary":"The mechanical native PDFs are AgentCAD headless PDF renderings of actual AutoCAD saved/reopened/activated witness DXF, not Autodesk PDF-driver output."},
    "visual_inputs":visual["files"],
    "performance":{"report":pp.relative_to(BASE).as_posix(),"report_sha256":hashbytes(pp.read_bytes()),"versions":{k:v["commit"] for k,v in p["snapshots"].items()},
        "observations":24,"timed_repeats_per_version_and_size":5,"warmups_excluded_per_version_and_size":1,"all_correctness_passed":True,
        "same_interpreter_platform":True,"snapshot_imports_and_fixed_source_checked":True,"medians_recomputed":True,
        "source_line_endings":"Each snapshot's exact reported raw hash is checked against its imported file, then CRLF-only normalization is checked against fixed Git. Materialized snapshot bytes need not equal an editable worktree's raw newline representation.",
        "summary":p["summary"],"scope":p["scope"],"interpretation":"A reproducible version comparison, not evidence of a large/general speed advantage or a comparison against Pro."}}
(BASE/"reviewer-rubric"/("showcase-performance-validation-"+label+".json")).write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"product_sha":args.sha,"passed":True,"calls":len(s["calls"]),"pdfs":len(visual["files"]),"observations":24,
    "total_medians":[r for r in p["summary"] if r["metric"]=="total_s"]}))
