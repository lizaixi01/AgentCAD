"""Read the completed fd failure drawing without changing it or using native CAD."""
import hashlib,json,pathlib,sys
OUT=pathlib.Path(r"D:\Projects\AgentCAD-output\source-capability-100\reviewer-rubric")
sys.path.insert(0,str(OUT/"snapshot-fd6d45f/src"))
import ezdxf
from agentcad.validate.features import extract
p=OUT.parent/"test-windows-native-fd6d45f/test_dimensions_measure_actual0/blank.dxf"
retained=OUT/"full-failure-fd6d45f/blank.dxf"
if not p.exists():p=retained
before=p.read_bytes()
retained.parent.mkdir(exist_ok=True)
retained.write_bytes(before)
doc=ezdxf.readfile(p)
rows=extract(doc).dimensions
r={"product_sha":"fd6d45f274897cf7e2541d4c70d88113dfb6cb22","original_input_path":p.relative_to(OUT.parent).as_posix(),"input_path":retained.relative_to(OUT.parent).as_posix(),"input_sha256":hashlib.sha256(before).hexdigest(),"dimensions":rows,"raw_dimensions":[{"handle":e.dxf.handle,"attribs":e.dxf.all_existing_dxf_attribs(),"overrides":e.override().dimstyle_attribs,"style":doc.dimstyles.get(e.dxf.dimstyle).dxf.all_existing_dxf_attribs()} for e in doc.modelspace().query("DIMENSION")],"input_unchanged":p.read_bytes()==before,"retained_copy_identical":retained.read_bytes()==before,"scope":"Read-only diagnosis of the sole full-regression failure; no original test or artifact edited; exact-byte DXF retained in reviewer evidence."}
(OUT/"full-failure-diagnosis-fd6d45f.json").write_text(json.dumps(r,indent=2,default=str)+"\n",encoding="utf-8")
print(json.dumps([{k:r.get(k) for k in ('id','kind','measurement','displayed','display_evidence')} for r in rows]))
