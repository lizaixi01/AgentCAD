import importlib.metadata as md, json, platform, sys
from pathlib import Path
names = ("ezdxf", "mcp", "fastmcp", "pypdf", "Pillow", "shapely", "pydantic")
packages = {}
for name in names:
    try: packages[name] = md.version(name)
    except md.PackageNotFoundError: packages[name] = None
data={"python":sys.version,"platform":platform.platform(),"executable":sys.executable,"packages":packages,
      "scope":"Independent headless reproductions only; no native CAD process was launched."}
Path(sys.argv[1]).write_text(json.dumps(data,indent=2)+"\n",encoding="utf-8")
print(json.dumps(data))

