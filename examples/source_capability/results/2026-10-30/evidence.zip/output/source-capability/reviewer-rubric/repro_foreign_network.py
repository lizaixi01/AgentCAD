"""Read-only reproduction against plant.py from pinned AgentCAD 25abc96."""
import json, subprocess, sys, types
import ezdxf
PRODUCT = sys.argv[1] if len(sys.argv) > 1 else "25abc96b9e39abe4e52464d3f8f00eba589759e5"
code = subprocess.check_output(["git", "-C", r"D:\Projects\AgentCAD", "show", PRODUCT + ":src/agentcad/engineering/plant.py"], text=True, encoding="utf-8")
mod = types.ModuleType("agentcad.engineering.plant_pinned_review")
mod.__package__ = "agentcad.engineering"
exec(compile(code, PRODUCT + ":src/agentcad/engineering/plant.py", "exec"), mod.__dict__)
def drawing():
    d=ezdxf.new(units=4)
    d.layers.add("processpipe")
    return d
pid=drawing()
layout=drawing()
points=[("TK-1",(1000,0)),("TK-2",(0,1000)),("TK-3",(2500,500))]
for doc in (pid, layout):
    for tag, point in points:
        doc.modelspace().add_circle(point,25)
        doc.modelspace().add_text(tag,dxfattribs={"insert":point,"height":100})
pid.modelspace().add_arc((0,0),1000,0,90,dxfattribs={"layer":"processpipe"})
pid.modelspace().add_line((500,500),(2500,500),dxfattribs={"layer":"processpipe"})
r=mod.takeoff(pid,layout)
empty=drawing()
empty.layers.add("electrical")
empty.modelspace().add_text("5 kW",dxfattribs={"insert":(0,0),"height":100,"layer":"electrical"})
try:
    no_tags=mod.takeoff(empty,drawing())
except Exception as e:
    no_tags={"exception":type(e).__name__,"message":str(e)}
print(json.dumps({"sha":PRODUCT,"arc_actual_distance_at_line_endpoint":(500**2+500**2)**0.5,
 "arc_radius":1000,"arc_chord_false_tjunction":r,"electrical_without_equipment_tags":no_tags},indent=2))

