"""Independent saved-glyph check after an actual tolerance edit, headless only."""
import hashlib, json, subprocess, sys
from pathlib import Path
import ezdxf
from agentcad.policy import Policy
from agentcad.service import Runtime
from agentcad import service
SHA="b4c04669238e771a0888114f1af3260d7c371834"
repo=Path(service.__file__).resolve().parents[2]
paths=("src/agentcad/ops/annotate.py","src/agentcad/ops/edit.py","src/agentcad/tolerances.py")
checks={}
for path in paths:
    pinned=subprocess.check_output(["git","-C",str(repo),"show",SHA+":"+path])
    local=(repo/path).read_bytes()
    # checkout has CRLF, while git blobs have LF
    checks[path]=hashlib.sha256(pinned).hexdigest()
    assert local.replace(b"\r\n",b"\n")==pinned
root=Path(sys.argv[1])
root.mkdir(parents=True,exist_ok=False)
rt=Runtime(Policy(root=root))
def ok(r):
    assert r["ok"],r
    return r
ok(rt.create_drawing("edited.dxf",units="mm"))
ok(rt.apply_operations("edited.dxf",[
 {"op":"add_circle","center":[0,0],"diameter":35},
 {"op":"add_diameter_dim","target":"$0","tag":"review.tolerance","angle":15,
  "tolerance":{"lower":-0.012,"upper":0.025,"precision":3}}
]))
def glyphs():
    doc=ezdxf.readfile(root/"edited.dxf")
    dim=doc.modelspace().query("DIMENSION").first
    text=[e.dxf.text for e in doc.blocks.get(dim.dxf.geometry).query("TEXT MTEXT")]
    return {"handle":dim.dxf.handle,"geometry":dim.dxf.geometry,"text":text,"measurement":dim.dxf.actual_measurement}
before=glyphs()
ok(rt.apply_operations("edited.dxf",[
 {"op":"modify","target":"tag:review.tolerance","set":{
  "text_height":3.5,"tolerance":{"lower":-0.017,"upper":0.043,"precision":3}}}
]))
after=glyphs()
assert before["text"]!=after["text"]
assert "0.043" in " ".join(after["text"]) and "0.017" in " ".join(after["text"])
assert "0.025" not in " ".join(after["text"]) and "0.012" not in " ".join(after["text"])
assert after["measurement"]==35
report={"sha":SHA,"source_hashes":checks,"before":before,"after":after,"saved_glyphs_updated":True}
(root/"report.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
print(json.dumps(report,indent=2))

