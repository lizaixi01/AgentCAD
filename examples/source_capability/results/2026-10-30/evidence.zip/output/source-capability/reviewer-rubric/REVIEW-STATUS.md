# 独立评估工作底稿（等待最终产品与运行证据）

审查者：source_rubric_review；日期：2026-10-30。此目录由独立源码评估者写入，未修改产品工作树，未发布 PR 评论，未启动 AutoCAD、FreeCAD 或 Claude。只运行了隔离的无头输入复现。

## 版本和规则

- 基线 AgentCAD：`25abc96b9e39abe4e52464d3f8f00eba589759e5`。该版不是最终评分对象；后续已报告 3db102d，plant 修复待完成。
- Pro：`58a05ddfc34a9832c626e82cd88ecdce8e16a62a`。
- 固定规则：AgentCAD 25abc96 的 `docs/source-capability-rubric.md`，20 项、每项 0–5；分类权重 25/20/15/15/15/10。
- Pro 历史自评分 93 指 1.6.0、2026-09-24；与本次 1.7.0 的本地独立逐项复评不同，不能直接当同场榜单、官方名次或精确涨分。
- 未完成的运行、跳过的 native 测试、只存在的工作流定义不当作通过；测试数量不换算分数。
- 每项只对其共同公开且有用的能力契约给分，不要求所有 CAD 行业功能或认证。已知限制不是自动满分，也不是自动扣分，须判断是否影响该项实际流程。

## 已核实的 Pro 证据边界

- 8 份原生 AutoCAD 报告来自 13499fe888120ed929cc0c3b0afe303b1de83a74。精确比较至 58a05dd 的后续两提交只有文档、结果和测试 extras 跳过，没有产品代码变化，所以这些实际结果可以沿用到固定 Pro 版本。完整比较见 pro-compare-live.json。
- 固定依赖 CI 40307188701、发布 40308291799、benchmark 40312179908 都完成成功。见对应 jobs/run JSON。
- 浮动依赖 run 40325975963 的唯一失败是发布报告保存 ezdxf 1.4.4 与新安装 1.4.5 的版本字符串断言。它不是已证明的几何回归，见 pro-floating-failure.txt。
- 已发布性能比较的 head 是 efd33d0da26c7e44ac43413c0d2a1f7a36e8fba8。其后到固定 Pro 的 17 提交改变了 ezdxf/QA/delivery/verification 代码，因此不能自动当作最终 58a05dd 的性能结果。见 pro-compare-perf.json。
- pro-provisional-rows.json 含 20 项暂定分、逐分证据和每项边界；总分保持 null，待最终一致性复核。

## 已复现的 AgentCAD 25abc96 缺陷

1. plant.py:235、297–298：ARC 只保留端点，T 接点用到端点弦的距离。对半径 1000 的 0–90 度圆弧，从 (500,500) 出发的线并不接触弧，却把三个设备合为一个 run、给出 4.0 m 路由估计且 warnings=[]。这是连通关系假阳性；“长度为估计”不能解释它。主归 E3，修复前上限 2，不因同一个缺陷再在 F5/C3 机械重复扣分。
2. plant.py:396：electrical 图层只有“5 kW”而没有设备标签时，min(empty) 抛 ValueError。应将无法绑定设备报告为不完整/开放项。
3. 块内 DIMENSION 公差精度漏检由另一独立 reviewer 复现，主代理已报告在 3db102d 修复；最终评分仍需源码和行为证据。主归 C2，避免在 F3/C3 重复计算同一假通过。

复现脚本和固定源码加载方式见 repro_foreign_network.py，结果见 repro_foreign_network-25abc96.json。该脚本从 git show 固定版本取得 plant.py；依赖的 geom.py 在运行时经 git diff 确认无变化。环境另存 agent-reproduction-environment.json。

同类 ARC/弦反例也对 Pro 固定源码检查：build_network 返回两条独立 run，弧长为 1570.7963，见 repro_pro_arc_network.py 和 repro_pro_arc_network-58a05dd.json。此比较只验证对应拓扑问题，不是全功能性能对比。

## AgentCAD 最终需接收/核实的材料

| 项 | 当前证据与待决条件 |
|---|---|
| F1 | analytic bulges、HATCH nesting/style、曲线/长度的独立输入及保存后测量在 test_t_workflow_guards / common ops；最终全量运行需完成。 |
| F2 | transform/edit/identity、revision guards、foreign edit 和新进程 reopen；保留基线测试并核对新提交无回归。 |
| F3 | tests/test_y_tolerances 的数值显示、编辑、取消公差、fit -> 实际 DIMENSION；需最终图面可读性与修改后的实际渲染。 |
| F4 | 纸空间 PDF、模型/布局、block/attribute 和多格式导出测试；native paper 证据补充中。 |
| F5 | native P&ID/mechanical/architecture，外来网络几何/缺标识；不把仅 v8 fixture 参数变化视为新结构证据。 |
| C1 | failed batch、dry run、checkpoint/recovery、stale preview/revision 和无重叠 writer；等待最终固定版通过记录。 |
| C2 | 已保存规格恢复、tamper、dimension binding；块内精度漏洞需独立复验。 |
| C3 | DXF 全布局/块/属性/样式 parity、真实 JSON/CSV/XLSX readback、PDF/SVG structural scopes；不得称全格式几何等价。 |
| C4 | malformed DXF/unsupported units、unknown operations、external edits/incomplete inputs；无 tag electrical 新缺陷需复验。 |
| B1 | 明确 DXF / AutoCAD exchange / FreeCAD 互补契约，缺依赖和能力拒绝。 |
| B2 | modelspace 四类原生 DWG -> DXF -> AUDIT 流程；待 paper/viewport/page setup/纸空间标注的原生参数及实际可见结果。 |
| B3 | 最终四平台 CI 与 Windows native 结果；headless 与 native 分开说明。 |
| E1 | 全部标准尺寸逐行来源审查与边界；M14 counterbore 仍明确未核验，不能等同来源验证。旧 ISO2306/DIN 全表文字需校正。 |
| E2 | 非 v8 的机械/建筑/P&ID/公差完整图纸，重开后的 PDF 与 DXF 可读性；showcase-2 曾有文字位置/缩小问题，不当最终视觉通过。 |
| E3 | native readback 与删件/移墙/断连反馈已具备；ARC 假连通必须修复并新增正反对照。 |
| T1 | 最终单元/接口/进程/原生/对抗行为运行；测试数量不参与评分。 |
| T2 | 产品/evaluator SHA、锁文件、版本、环境、输出 hashes 与脚本；新结果不可改写历史结果。 |
| T3 | 最终已完成 CI、benchmark 不完整报告失败门、同机同依赖版本性能/正确性比较；暂不把 smoke 当正式版本对照。 |
| S1 | 真实 HTTP 拒绝且无写入、令牌/Origin/Host/framing边界、路径/只读/operation策略、脚本默认禁用；Windows RST 修复重验。 |
| S2 | OS 锁进程存活不能被旧时间戳抢占、死进程自动释放、取消线程保留串行、子进程超时恢复及日志；原生补充结果须分类。 |

审查未完成时，不应把暂定行数累加成 README 的“正式第一名”。

## b4c0466 复核补记

- 当前候选固定为 b4c04669238e771a0888114f1af3260d7c371834。
- 原始 ARC/无 tag 两个输入重跑后修复成立，见 repro_foreign_network-b4c0466.json。
- 独立运行工程/公差用例 59 passed、0 skipped/failure/error，见 recheck-b4c0466.xml。全 entitydb 的块内精度校验已读源码；C2/E3 临时严重缺陷上限解除。
- 另用新的 35 mm、15° 直径标注，修改偏差 -0.012/+0.025 -> -0.017/+0.043，重开读取实际渲染块由 *D1 变为 *D2，文字同步更新，原 measurement=35 保留。见 rendered-edit-b4c0466/report.json。
- 四 lane CI 41049567713 全部完成 success，见 agent-b4c-ci-jobs.json。
- 独立查看四份最终图面，记录见 agent-visual-review-b4c0466.json。B2 原生纸空间缺口已补；机械图面尚缺模型关键直径与孔系标注，E2 保留为 4 分。
- 最终全套 native 与 performance 正式记录仍在等待，不锁最终总分。

## 最终确认（2026-10-30）

- b4c0466 全套 Windows 原生记录已完成并独立核对：685 passed、8 skipped、693 collected、0 failure/error。8 个跳过均缺 CadQuery；AutoCAD/FreeCAD 实际启用的相关用例没有跳过。
- 四个 CI lane 与本机的测试 ID 集合完全一致；源文件指纹逐项一致。独立核验见 final-run-validation-b4c0466.json 与 source-boundary-b4c0466.json。
- performance-b4c0466 的 24 次观测完整，全部正确性检查通过；不把小幅耗时变化称为普遍性能领先。
- 最终同尺复评：AgentCAD 98/100，Pro 当前固定提交 96/100。AgentCAD E1/E2 各扣 1；Pro F3/T3 各扣 1，S1 扣 2。
- Pro 暂定 E1 对额外空表的扣分已撤销：不要求 AgentCAD 的额外可选标准表，不能只向 Pro 提出。最终 E1=5；旧暂定文件保留以便审计。
- 最终逐项文件 assessment.json 与可读摘要 FINAL-REVIEW.md；pending 草稿保留。身份明确为 independent AI reviewer, requested/published by AgentCAD，未声称官方榜单或外部认证。Pro 历史 93 分另列。

