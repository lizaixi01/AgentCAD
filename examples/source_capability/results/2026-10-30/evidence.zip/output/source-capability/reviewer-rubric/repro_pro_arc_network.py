"""The same arc/chord topology counterexample on pinned Pro, without a CAD launch."""
import dataclasses, json, sys
sys.path.insert(0, r"D:\Projects\AgentCAD-output\autocad-benchmark-20261030\upstream")
from engineering.understand.network import build_network
from engineering.understand.snapshot import EntityRecord, Snapshot
records=(
 EntityRecord(handle="A",type="ARC",layer="PRODUCT",space="Model",points=((0.,0.),),radius=1000.,angles=(0.,90.)),
 EntityRecord(handle="B",type="LINE",layer="PRODUCT",space="Model",points=((500.,500.),(2500.,500.))),
)
snap=Snapshot(source="independent-review",insunits=4,extmin=None,extmax=None,
 layers={"PRODUCT":{"color":7,"linetype":"Continuous"}},layouts=(),records=records)
r=build_network(snap)
print(json.dumps({"sha":"58a05ddfc34a9832c626e82cd88ecdce8e16a62a","expected_components":2,"result":r},indent=2,default=lambda o: dataclasses.asdict(o) if dataclasses.is_dataclass(o) else list(o)))

