# Independent incremental review — PR #41

Head: 3db102d09ddae4c3b65ebf8b1d7b5222e4b7ee06
Actual PR base: a713426e1e2f271dd2db068cd165b7d020604700
Reviewer: /root/source_capability_code_review, independent of the author.
Scope: incremental changes since 25abc96b9e39abe4e52464d3f8f00eba589759e5, especially saved tolerance traversal, finite-value/error handling, tolerance text defaults, and showcase.py evidence provenance. Final scores/README and native CAD verification remain outside this review.

## Findings requiring fixes

1. [P2] Non-finite nominal factors still pass in deviations mode (src/agentcad/tolerances.py, the mode == limits branch around lines 40–50). A valid deviations dimension with DIMLFAC changed to NaN or Infinity, then stored inside an inserted block, passes validate_drawing and strict DXF delivery at quality_score 100. The same mutations in limits mode correctly produce INVALID_TOLERANCE. Nominal/factor finiteness needs to apply to both modes. Evidence: recheck-3db102d/deviations-dimlfac-nan.dxf, deviations-dimlfac-inf.dxf, dimlfac-nan-delivery.json and dimlfac-inf-delivery.json.

2. [P2] showcase.py attributes a run to its own repository instead of verifying the imported product (examples/source_capability/showcase.py:69–73). Set PYTHONPATH to snapshot-25abc96/src and run the 3db102d showcase without --native: all four checks pass and source_commit records 3db102d, but tolerance.dxf contains the old defaults (DIMTFAC=1.0, DIMTOLJ=0, DIMGAP=0.625), demonstrating that old code actually ran. Bind execution to the intended source and record/verify that import provenance, as compare.py already does. Evidence: showcase-source-mismatch-3db/report.json, tolerance.dxf and sibling execution log. This is an intentionally mismatched-version negative test, not usable release evidence.

## Verified closures and checks

- The exact earlier inserted-block counterexample is now rejected with DELIVERY_REJECTED. The database traversal visits stored DIMENSION entities once and avoids recursion/duplicate INSERT instances; nested, paper-space and unused-block cases have positive and negative regressions. Evidence: recheck-3db102d/blocked-result.json.
- Invalid lower/upper deviations (NaN / Infinity) are reported as INVALID_TOLERANCE in both display modes. Invalid DIMLFAC is correctly rejected in limits mode.
- 103 directed tests passed from an immutable snapshot of this head, including tolerance storage/editing/delivery, nested block behavior, actual font-outline clearance for deviations and limits, drawing delivery, dimensional library behavior, and workflow guards. Evidence: tests-3db.log and tests-3db.xml.
- The new 0.7 height factor, centered tolerance alignment, and minimum half-text-height gap change presentation defaults without changing deviation values. No additional regression found within the tested headless paths. Actual native rendering requires the separate serial CAD/visual verification being performed by the main task.

No AutoCAD, FreeCAD or Claude was started; no product working tree was edited. Both findings were sent to the author before any PR verdict. Final PR commentary remains deferred at the author's request until the subsequent repair version (which also addresses separately discovered plant-takeoff issues).
