# Independent code review — PR #41, pending one fix

Reviewed head: 25abc96b9e39abe4e52464d3f8f00eba589759e5
Actual PR base at review: a713426e1e2f271dd2db068cd165b7d020604700
Reviewer: independent child agent /root/source_capability_code_review (did not author the changes)
Scope: product changes and verification scripts, particularly edits since 4618f86077f954c2678e71d2a65127300efcdee9; final README and source-review scores excluded.

## Finding

[P2] Saved-file tolerance validation omits DIMENSION entities inside inserted blocks.
Location: src/agentcad/validate/checks.py:374-380, iteration over feats.dimensions.

The previous invalid limits drawing (nominal 1, length_factor 1.234, signed deviations -0.1/+0.1, precision 1) is now correctly rejected in Model. Moving its entities into an ASSEMBLY block and inserting that block into Model, without changing its dimension or rendered text, bypasses that check. Strict delivery returns ok=true, quality_score=100, passed=true, and no issues. The rendered limits remain 1.3/1.1 instead of 1.334/1.134.

Evidence relative to this review directory:
- recheck-25abc96/limits.dxf and model-result.json: the previous model-space counterexample is correctly refused.
- recheck-25abc96/blocked-limits.dxf and block-result.json: identical dimension within an inserted block is incorrectly accepted.

Prior findings for paper-space engineering records, XLSX relationship consistency, and tolerance edits/re-rendering are otherwise fixed in this head.

## Independent verification

A fixed snapshot imported from snapshot-25abc96/src passed 148 directed tests covering tolerance changes, delivery, HTTP refusal behavior, dimensional-library behavior, workflow guards, locking, interfaces, and release gates. Logs: tests-25a.log; JUnit: tests-25a.xml.

examples/source_capability/compare.py was run with baseline a713426e1e2f271dd2db068cd165b7d020604700 and candidate 25abc96b9e39abe4e52464d3f8f00eba589759e5, counts 8 and 31, 3 measured repetitions per version plus one excluded warmup per count/version (16 fresh worker processes total). Independently rechecked the pinned harness SHA, every recorded Python source hash, actual import origins, identical expected geometry hashes, excluded warmups, all 6 median summaries, and candidate/baseline ratios. No blocking issue found within its stated direct Runtime / 2D-line scope. These small cases verify the method; their timings are not performance claims. Evidence: compare-25abc96/report.json and logs.

No AutoCAD, FreeCAD or Claude was started. No product working tree was edited and no PR verdict was posted while the finding remains open. The parent was notified and is preparing the fix.
