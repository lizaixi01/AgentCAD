# Independent product and reproduction-script review — PR #41

Verdict: no blocking findings remain in the reviewed product and reproduction-script scope.
Reviewed head: b4c04669238e771a0888114f1af3260d7c371834
Actual PR base: a713426e1e2f271dd2db068cd165b7d020604700
Reviewer: independent agent /root/source_capability_code_review; this reviewer did not author or edit the product changes.

## Scope and closed findings

Reviewed the actual PR diff and subsequent repair increments, including delivery gates/readback, HTTP request boundaries, interprocess locking, native tolerance metadata and display, installation/MCP compatibility, dimensional-library provenance behavior, plant-network repair, and the version-comparison/showcase scripts.

Previously reproduced findings are now closed:
- Native engineering records outside Model fail explicitly instead of silently passing.
- XLSX package/workbook relationships and the verified worksheet are checked.
- Limits retain their declared precision on creation, modification, redraw and saved-file validation.
- Saved DIMENSION declarations in nested, paper-space and unused blocks are checked without recursive INSERT expansion or duplicate instance errors.
- Non-finite nominal factors are rejected for both deviations and limits. The exact earlier NaN/Infinity counterexample files now produce DELIVERY_REJECTED without changing their bytes.
- Showcase imports are bound to the intended checkout and every loaded agentcad module is checked. An old-source PYTHONPATH no longer changes the measured product; already-loaded foreign modules are refused before output creation.

## Verification performed independently

1. Immutable b4c0466 snapshot: 172 tests passed (tests-b4c.log and tests-b4c.xml), covering tolerance creation/editing/display/storage, engineering workflows, delivery, HTTP/security, standard-library behavior, workflow guards, process locks, interfaces and benchmark release gates.
2. Original saved counterexamples re-run: recheck-b4c0466/prior-counterexamples.json contains the refusal results for NaN, Infinity and the inserted-block limits drawing.
3. Additional plant-curve boundary checks: six cases combining normal/reversed extrusion and wraparound/major/minor arc spans; on-curve points/endpoints have zero distance and points outside the finite span remain separated. Results: recheck-b4c0466/arc-span-boundaries.json. The regression suite covers chord false connections, true T connections, labels on arcs, closed-polyline final segments, arc/chord distinction and missing electrical tags with unknown lengths.
4. The full headless showcase completed with PYTHONPATH deliberately pointing at snapshot-25abc96/src. The report correctly names b4c0466; all recorded module origins belong to the intended checkout; all recorded source hashes and normalized file content match the fixed snapshot. The saved tolerance uses DIMTFAC=0.7, DIMTOLJ=1 and DIMGAP=1.25. Evidence: showcase-bound-source-b4c/report.json, the generated DXF/PDF outputs and sibling log. A separate preloaded-foreign-module check was correctly refused before creating its output directory.
5. compare.py is unchanged since its independent 25abc96 method check: two pinned commits, one interpreter/dependency environment, fresh processes, matching reopened geometry, excluded warmups, and independently recomputed medians/ratios. The small 8/31-line verification establishes the method, not a performance result.

The changes are within the requested capability and reproducibility scope. No further correctness/regression blocker was found in these checks. The new tolerance formatting changes presentation defaults while preserving numeric metadata; its headless font-outline regressions passed.

## Explicit limits

No AutoCAD, FreeCAD or Claude was started in this review. The native activation branch of showcase.py was read but not executed; it activates the actual AutoCAD layout and regenerates before checking the saved witness, rather than rewriting viewport IDs or geometry. Actual native execution and PDF visual review belong to the separate serial verification run.

Final README scores, ranking claims and final evidence archival still require the separate documentation/evidence review. This verdict does not substitute for complete branch CI, the required up-to-date branch checks, or the repository's CI-change merge-approval condition.

No product worktree was edited by the reviewer. Temporary snapshots and verification outputs were kept under D:/Projects/AgentCAD-output/source-capability/reviewer-code.
